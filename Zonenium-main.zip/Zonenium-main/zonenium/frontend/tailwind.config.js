/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        zonenium: {
          primary: '#0084ff',
          secondary: '#42c767', 
          dark: '#1c1e21',
          light: '#f0f2f5',
          gray: '#8a8d91'
        }
      }
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
  ],
}