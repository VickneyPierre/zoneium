import React, { createContext, useContext, useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { useAuth } from './AuthContext';
import toast from 'react-hot-toast';

const SocketContext = createContext();

export const SocketProvider = ({ children }) => {
  const [socket, setSocket] = useState(null);
  const [onlineUsers, setOnlineUsers] = useState(new Set());
  const [typingUsers, setTypingUsers] = useState({}); // chat_id -> Set of user_ids
  const { user, isAuthenticated } = useAuth();

  useEffect(() => {
    if (isAuthenticated && user) {
      // Create socket connection
      const newSocket = io(import.meta.env.VITE_BACKEND_URL || 'http://localhost:8002', {
        transports: ['websocket', 'polling'],
        autoConnect: true,
      });

      // Handle connection events
      newSocket.on('connect', () => {
        console.log('Socket connected:', newSocket.id);
        
        // Authenticate with server
        newSocket.emit('authenticate', {
          user_id: user.id,
          chats: [] // Will be populated with actual chats
        });
      });

      newSocket.on('disconnect', () => {
        console.log('Socket disconnected');
      });

      newSocket.on('error', (error) => {
        console.error('Socket error:', error);
        toast.error('Connection error');
      });

      newSocket.on('authenticated', (data) => {
        console.log('Socket authenticated:', data);
      });

      // Handle real-time events
      newSocket.on('new_message', (messageData) => {
        console.log('New message received:', messageData);
        // Dispatch custom event for components to listen
        window.dispatchEvent(new CustomEvent('newMessage', { detail: messageData }));
      });

      newSocket.on('user_status', (statusData) => {
        console.log('User status update:', statusData);
        setOnlineUsers(prev => {
          const newSet = new Set(prev);
          if (statusData.is_online) {
            newSet.add(statusData.user_id);
          } else {
            newSet.delete(statusData.user_id);
          }
          return newSet;
        });
      });

      newSocket.on('user_typing', (typingData) => {
        console.log('Typing event:', typingData);
        setTypingUsers(prev => {
          const newTypingUsers = { ...prev };
          const chatId = typingData.chat_id;
          const userId = typingData.user_id;
          
          if (!newTypingUsers[chatId]) {
            newTypingUsers[chatId] = new Set();
          }
          
          if (typingData.typing) {
            newTypingUsers[chatId].add(userId);
          } else {
            newTypingUsers[chatId].delete(userId);
            if (newTypingUsers[chatId].size === 0) {
              delete newTypingUsers[chatId];
            }
          }
          
          return newTypingUsers;
        });
      });

      newSocket.on('message_status', (statusData) => {
        console.log('Message status:', statusData);
        // Dispatch custom event for message status updates
        window.dispatchEvent(new CustomEvent('messageStatus', { detail: statusData }));
      });

      setSocket(newSocket);

      return () => {
        newSocket.close();
      };
    } else {
      // Clean up socket when user logs out
      if (socket) {
        socket.close();
        setSocket(null);
      }
      setOnlineUsers(new Set());
      setTypingUsers({});
    }
  }, [isAuthenticated, user]);

  // Socket utility functions
  const joinChat = (chatId) => {
    if (socket) {
      socket.emit('join_chat', { chat_id: chatId });
    }
  };

  const leaveChat = (chatId) => {
    if (socket) {
      socket.emit('leave_chat', { chat_id: chatId });
    }
  };

  const startTyping = (chatId) => {
    if (socket) {
      socket.emit('typing_start', { chat_id: chatId });
    }
  };

  const stopTyping = (chatId) => {
    if (socket) {
      socket.emit('typing_stop', { chat_id: chatId });
    }
  };

  const isUserOnline = (userId) => {
    return onlineUsers.has(userId);
  };

  const getChatTypingUsers = (chatId) => {
    return typingUsers[chatId] ? Array.from(typingUsers[chatId]) : [];
  };

  const value = {
    socket,
    onlineUsers,
    typingUsers,
    joinChat,
    leaveChat,
    startTyping,
    stopTyping,
    isUserOnline,
    getChatTypingUsers
  };

  return (
    <SocketContext.Provider value={value}>
      {children}
    </SocketContext.Provider>
  );
};

export const useSocket = () => {
  const context = useContext(SocketContext);
  if (!context) {
    throw new Error('useSocket must be used within a SocketProvider');
  }
  return context;
};

export default SocketContext;