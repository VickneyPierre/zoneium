import React, { useState, useRef, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Mic, Square, Play, Pause, Trash2 } from 'lucide-react';

const VoiceRecorder = ({ onVoiceRecorded, onCancel, disabled = false }) => {
  const { t } = useTranslation();
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioBlob, setAudioBlob] = useState(null);
  const [audioUrl, setAudioUrl] = useState(null);
  const [duration, setDuration] = useState(0);
  const [recordingTime, setRecordingTime] = useState(0);
  
  const mediaRecorderRef = useRef(null);
  const audioRef = useRef(null);
  const chunksRef = useRef([]);
  const timerRef = useRef(null);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      if (audioUrl) {
        URL.revokeObjectURL(audioUrl);
      }
    };
  }, [audioUrl]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream, {
        mimeType: 'audio/webm;codecs=opus'
      });
      
      chunksRef.current = [];
      
      mediaRecorderRef.current.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };
      
      mediaRecorderRef.current.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm;codecs=opus' });
        setAudioBlob(blob);
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
        
        // Stop all tracks to release microphone
        stream.getTracks().forEach(track => track.stop());
      };
      
      mediaRecorderRef.current.start(100); // Record in 100ms chunks
      setIsRecording(true);
      setRecordingTime(0);
      
      // Start timer
      timerRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
      
    } catch (error) {
      console.error('Error accessing microphone:', error);
      alert('Could not access microphone. Please check permissions.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setDuration(recordingTime);
      
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
  };

  const playAudio = () => {
    if (audioRef.current) {
      audioRef.current.play();
      setIsPlaying(true);
    }
  };

  const pauseAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
    }
  };

  const deleteRecording = () => {
    if (audioUrl) {
      URL.revokeObjectURL(audioUrl);
    }
    setAudioBlob(null);
    setAudioUrl(null);
    setDuration(0);
    setRecordingTime(0);
    setIsPlaying(false);
  };

  const sendVoiceMessage = async () => {
    if (!audioBlob) return;
    
    try {
      // Convert blob to base64
      const reader = new FileReader();
      reader.onload = () => {
        const base64Audio = reader.result.split(',')[1]; // Remove data:audio/webm;base64, prefix
        
        onVoiceRecorded({
          file_data: base64Audio,
          file_name: `voice_message_${Date.now()}.webm`,
          file_type: 'audio/webm',
          file_size: audioBlob.size,
          duration: duration
        });
        
        // Cleanup
        deleteRecording();
      };
      reader.readAsDataURL(audioBlob);
    } catch (error) {
      console.error('Error processing voice message:', error);
      alert('Failed to process voice message');
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="p-4 bg-gray-800 border-t border-gray-700">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-white font-medium">🎤 Voice Message</h3>
        <button
          onClick={onCancel}
          className="text-gray-400 hover:text-white"
          disabled={isRecording}
        >
          <Trash2 className="w-5 h-5" />
        </button>
      </div>

      {!audioBlob ? (
        // Recording Interface
        <div className="flex items-center space-x-4">
          <div className="flex-1">
            <div className="flex items-center space-x-3">
              <button
                onClick={isRecording ? stopRecording : startRecording}
                disabled={disabled}
                className={`p-3 rounded-full transition-colors ${
                  isRecording 
                    ? 'bg-red-600 hover:bg-red-700 animate-pulse' 
                    : 'bg-zonenium-primary hover:bg-blue-700'
                } disabled:bg-gray-600 disabled:cursor-not-allowed`}
              >
                {isRecording ? (
                  <Square className="w-6 h-6 text-white" />
                ) : (
                  <Mic className="w-6 h-6 text-white" />
                )}
              </button>
              
              <div className="text-white">
                {isRecording ? (
                  <div className="flex items-center space-x-2">
                    <span className="w-2 h-2 bg-red-500 rounded-full animate-ping"></span>
                    <span>Recording... {formatTime(recordingTime)}</span>
                  </div>
                ) : (
                  <span>Tap to record</span>
                )}
              </div>
            </div>
          </div>
        </div>
      ) : (
        // Playback Interface
        <div className="space-y-3">
          {/* Audio Element */}
          <audio
            ref={audioRef}
            src={audioUrl}
            onEnded={() => setIsPlaying(false)}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
          />
          
          {/* Playback Controls */}
          <div className="flex items-center space-x-3">
            <button
              onClick={isPlaying ? pauseAudio : playAudio}
              className="p-2 bg-zonenium-primary hover:bg-blue-700 rounded-full text-white"
            >
              {isPlaying ? (
                <Pause className="w-4 h-4" />
              ) : (
                <Play className="w-4 h-4" />
              )}
            </button>
            
            <div className="flex-1">
              <div className="flex items-center space-x-2">
                <span className="text-white text-sm">Voice Message</span>
                <span className="text-gray-400 text-xs">{formatTime(duration)}</span>
              </div>
              <div className="w-full bg-gray-600 rounded-full h-1 mt-1">
                <div className="bg-zonenium-primary h-1 rounded-full w-1/3"></div>
              </div>
            </div>
          </div>
          
          {/* Action Buttons */}
          <div className="flex space-x-2">
            <button
              onClick={deleteRecording}
              className="flex-1 py-2 border border-gray-600 text-gray-300 rounded-md hover:bg-gray-700 transition-colors text-sm"
            >
              Delete
            </button>
            <button
              onClick={sendVoiceMessage}
              disabled={disabled}
              className="flex-1 py-2 bg-zonenium-secondary hover:bg-green-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-md transition-colors text-sm"
            >
              Send Voice Message
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

// Voice Message Display Component
export const VoiceMessage = ({ message }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const audioRef = useRef(null);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const togglePlayback = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      setCurrentTime(0);
    }
  };

  return (
    <div className="flex items-center space-x-3 p-3 bg-gray-600/50 rounded-lg min-w-[200px]">
      <audio
        ref={audioRef}
        src={`data:${message.file_type};base64,${message.content}`}
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onEnded={() => setIsPlaying(false)}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
      />
      
      <button
        onClick={togglePlayback}
        className="p-2 bg-zonenium-primary hover:bg-blue-700 rounded-full text-white flex-shrink-0"
      >
        {isPlaying ? (
          <Pause className="w-4 h-4" />
        ) : (
          <Play className="w-4 h-4" />
        )}
      </button>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between text-xs text-gray-300 mb-1">
          <span>🎤 Voice Message</span>
          <span>{formatTime(message.duration || 0)}</span>
        </div>
        <div className="w-full bg-gray-700 rounded-full h-1">
          <div 
            className="bg-zonenium-primary h-1 rounded-full transition-all duration-200"
            style={{ 
              width: `${audioRef.current && audioRef.current.duration > 0 
                ? (currentTime / audioRef.current.duration) * 100 
                : 0}%` 
            }}
          ></div>
        </div>
      </div>
    </div>
  );
};

export default VoiceRecorder;