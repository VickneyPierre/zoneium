import React, { useState, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { Paperclip, X, Upload, File, Image, FileText, Loader } from 'lucide-react';
import { fileAPI } from '../services/api';
import toast from 'react-hot-toast';

const FileUpload = ({ onFileSelected, onCancel, disabled = false }) => {
  const { t } = useTranslation();
  const [uploading, setUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef(null);

  const handleFiles = async (files) => {
    const file = files[0];
    if (!file) return;

    // Check file size (10MB limit)
    const maxSize = 10 * 1024 * 1024;
    if (file.size > maxSize) {
      toast.error(t('file.fileTooLarge'));
      return;
    }

    setUploading(true);
    try {
      const response = await fileAPI.uploadFile(file);
      onFileSelected({
        file_data: response.file_data,
        file_name: response.file_name,
        file_type: response.file_type,
        file_size: response.file_size
      });
      toast.success(t('file.uploadSuccess'));
    } catch (error) {
      toast.error(t('file.uploadFailed'));
      console.error('Upload error:', error);
    } finally {
      setUploading(false);
    }
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleChange = (e) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      handleFiles(e.target.files);
    }
  };

  const openFileDialog = () => {
    fileInputRef.current?.click();
  };

  const getFileIcon = (fileType) => {
    if (fileType?.startsWith('image/')) return <Image className="w-6 h-6" />;
    if (fileType?.includes('pdf')) return <FileText className="w-6 h-6" />;
    return <File className="w-6 h-6" />;
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="p-4 bg-gray-800 border-t border-gray-700">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-white font-medium">{t('file.uploadFile')}</h3>
        <button
          onClick={onCancel}
          className="text-gray-400 hover:text-white"
          disabled={uploading}
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {uploading ? (
        <div className="flex items-center justify-center py-8">
          <Loader className="w-8 h-8 animate-spin text-zonenium-primary mr-3" />
          <span className="text-white">{t('file.uploading')}</span>
        </div>
      ) : (
        <>
          {/* Drag and Drop Area */}
          <div
            className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
              dragActive
                ? 'border-zonenium-primary bg-zonenium-primary/10'
                : 'border-gray-600 hover:border-gray-500'
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
            <p className="text-white mb-2">{t('file.dragDropFiles')}</p>
            <p className="text-gray-400 text-sm mb-4">{t('file.or')}</p>
            
            <button
              onClick={openFileDialog}
              disabled={disabled}
              className="px-4 py-2 bg-zonenium-primary hover:bg-blue-700 text-white rounded-md transition-colors disabled:opacity-50"
            >
              {t('file.selectFile')}
            </button>
          </div>

          {/* File Input */}
          <input
            ref={fileInputRef}
            type="file"
            onChange={handleChange}
            style={{ display: 'none' }}
            accept="*/*"
          />

          <div className="mt-3 text-xs text-gray-400">
            {t('file.maxFileSize')}: 10MB
          </div>
        </>
      )}
    </div>
  );
};

// File Message Display Component
export const FileMessage = ({ message }) => {
  const { t } = useTranslation();
  
  const getFileIcon = (fileType) => {
    if (fileType?.startsWith('image/')) return <Image className="w-5 h-5" />;
    if (fileType?.includes('pdf')) return <FileText className="w-5 h-5" />;
    return <File className="w-5 h-5" />;
  };

  const formatFileSize = (bytes) => {
    if (!bytes) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleDownload = () => {
    if (message.content && message.file_name) {
      // Create blob from base64 data
      const byteCharacters = atob(message.content);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: message.file_type });
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = message.file_name;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    }
  };

  if (message.message_type === 'file' && message.file_type?.startsWith('image/')) {
    // Display image
    return (
      <div className="max-w-sm">
        <img
          src={`data:${message.file_type};base64,${message.content}`}
          alt={message.file_name}
          className="rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
          onClick={() => window.open(`data:${message.file_type};base64,${message.content}`, '_blank')}
        />
        <p className="text-xs mt-1 opacity-70">{message.file_name}</p>
      </div>
    );
  }

  // Display file attachment
  return (
    <div 
      className="flex items-center space-x-3 p-3 bg-gray-600/50 rounded-lg cursor-pointer hover:bg-gray-600/70 transition-colors"
      onClick={handleDownload}
    >
      <div className="text-zonenium-primary">
        {getFileIcon(message.file_type)}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-white text-sm truncate">{message.file_name}</p>
        <p className="text-gray-400 text-xs">
          {formatFileSize(message.file_size)}
        </p>
      </div>
      <div className="text-gray-400">
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
      </div>
    </div>
  );
};

export default FileUpload;