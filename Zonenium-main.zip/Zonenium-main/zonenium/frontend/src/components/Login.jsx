import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../context/AuthContext';
import { MessageCircle, Loader } from 'lucide-react';
import LanguageSelector from './LanguageSelector';

const Login = () => {
  const { t } = useTranslation();
  const [formData, setFormData] = useState({
    username: '',
    password: ''
  });
  const { login, loading, error } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const result = await login(formData);
    if (result.success) {
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen bg-zonenium-dark flex items-center justify-center px-4">
      <div className="max-w-md w-full space-y-8">
        {/* Language Selector */}
        <div className="flex justify-end">
          <LanguageSelector isDropdown={true} />
        </div>

        {/* Logo and Title */}
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <img 
              src="/images/zonenium-logo.png" 
              alt="Zonenium Logo" 
              className="h-16 w-16 object-contain"
            />
          </div>
          <h2 className="text-3xl font-bold text-white">
            {t('auth.loginTitle')}
          </h2>
          <p className="mt-2 text-zonenium-gray">
            {t('app.tagline')}
          </p>
        </div>

        {/* Login Form */}
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <div className="space-y-4">
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-gray-300">
                {t('auth.username')}
              </label>
              <input
                id="username"
                name="username"
                type="text"
                required
                value={formData.username}
                onChange={handleChange}
                className="mt-1 block w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-zonenium-primary focus:border-transparent"
                placeholder={t('placeholders.enterUsername')}
              />
            </div>
            
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-300">
                {t('auth.password')}
              </label>
              <input
                id="password"
                name="password"
                type="password"
                required
                value={formData.password}
                onChange={handleChange}
                className="mt-1 block w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-zonenium-primary focus:border-transparent"
                placeholder={t('placeholders.enterPassword')}
              />
            </div>
          </div>

          {error && (
            <div className="bg-red-600/20 border border-red-500 text-red-400 px-4 py-2 rounded-md text-sm">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-zonenium-primary hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-zonenium-primary disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? (
              <Loader className="w-4 h-4 animate-spin" />
            ) : (
              <>
                <MessageCircle className="w-4 h-4 mr-2" />
                {t('auth.login')}
              </>
            )}
          </button>

          <div className="text-center">
            <p className="text-sm text-zonenium-gray">
              {t('auth.dontHaveAccount')}{' '}
              <Link
                to="/register"
                className="font-medium text-zonenium-primary hover:text-blue-400"
              >
                {t('auth.signUpHere')}
              </Link>
            </p>
          </div>

          {/* Demo Accounts */}
          <div className="mt-6 p-4 bg-gray-800 rounded-md">
            <p className="text-xs text-gray-400 mb-2">{t('demo.accounts')}</p>
            <div className="space-y-1 text-xs">
              <p className="text-gray-300">{t('demo.account1')}</p>
              <p className="text-gray-300">{t('demo.account2')}</p>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;