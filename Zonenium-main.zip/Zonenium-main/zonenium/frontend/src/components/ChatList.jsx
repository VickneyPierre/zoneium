import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../context/AuthContext';
import { chatAPI } from '../services/api';
import { MessageCircle, Users, Search, Plus, UserPlus } from 'lucide-react';
import LanguageSelector from './LanguageSelector';
import UserSearchModal from './UserSearchModal';
import GroupCreationModal from './GroupCreationModal';
import toast from 'react-hot-toast';

const ChatList = ({ onSelectChat, selectedChatId }) => {
  const { t } = useTranslation();
  const [chats, setChats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [showUserSearch, setShowUserSearch] = useState(false);
  const [showGroupCreation, setShowGroupCreation] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    fetchChats();
  }, []);

  const fetchChats = async () => {
    try {
      setLoading(true);
      const response = await chatAPI.getUserChats();
      setChats(response.chats || []);
    } catch (error) {
      toast.error(t('chat.failedToLoad') + ' chats');
      console.error('Error fetching chats:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredChats = chats.filter(chat => {
    if (!searchQuery) return true;
    return chat.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
           chat.last_message?.toLowerCase().includes(searchQuery.toLowerCase());
  });

  const formatTime = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffHours = Math.ceil(diffTime / (1000 * 60 * 60));
    
    if (diffHours < 24) {
      return date.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: false 
      });
    } else {
      return date.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric' 
      });
    }
  };

  const getChatDisplayName = (chat) => {
    if (chat.chat_type === 'group') {
      return chat.name || t('chat.groupChat');
    } else {
      // For private chats, show the other participant's name
      const otherParticipant = chat.participants?.find(id => id !== user?.id);
      return `${t('chat.user')} ${otherParticipant?.substring(0, 8)}...` || t('chat.privateChat');
    }
  };

  const handleNewChatClick = () => {
    setShowUserSearch(true);
  };

  const handleCreateGroupClick = () => {
    setShowGroupCreation(true);
  };

  const handleUserSearchClose = () => {
    setShowUserSearch(false);
  };

  const handleGroupCreationClose = () => {
    setShowGroupCreation(false);
  };

  const handleChatFromSearch = async (chat) => {
    // Add the new chat to the list if it doesn't exist
    const existingChat = chats.find(c => c.id === chat.id);
    if (!existingChat) {
      setChats(prevChats => [chat, ...prevChats]);
    }
    onSelectChat(chat);
  };

  const handleGroupCreated = async (group) => {
    // Add the new group to the chat list
    setChats(prevChats => [group, ...prevChats]);
    onSelectChat(group);
  };

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-zonenium-gray">
          <MessageCircle className="w-8 h-8 animate-pulse mx-auto mb-2" />
          <p>{t('chat.loadingChats')}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-gray-800">
      {/* Header */}
      <div className="p-4 bg-gray-900 border-b border-gray-700">
        <div className="flex items-center justify-between mb-3">
          <h1 className="text-xl font-semibold text-white flex items-center">
            <img 
              src="/images/zonenium-logo.png" 
              alt="Zonenium" 
              className="h-8 w-8 mr-2"
            />
            {t('app.name')}
          </h1>
          <div className="flex items-center space-x-2">
            <LanguageSelector isDropdown={true} />
            <button 
              onClick={handleCreateGroupClick}
              className="p-2 text-zonenium-gray hover:text-white transition-colors"
              title="Create Group"
            >
              <Users className="w-5 h-5" />
            </button>
            <button 
              onClick={handleNewChatClick}
              className="p-2 text-zonenium-gray hover:text-white transition-colors"
              title="New Chat"
            >
              <UserPlus className="w-5 h-5" />
            </button>
          </div>
        </div>
        
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-zonenium-gray w-4 h-4" />
          <input
            type="text"
            placeholder={t('placeholders.searchChats')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-full text-white placeholder-zonenium-gray focus:outline-none focus:border-zonenium-primary"
          />
        </div>
      </div>

      {/* Chat List */}
      <div className="flex-1 overflow-y-auto">
        {filteredChats.length === 0 ? (
          <div className="p-8 text-center text-zonenium-gray">
            <MessageCircle className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p className="text-lg mb-2">{t('chat.noChats')}</p>
            <p className="text-sm">{t('chat.startConversation')}</p>
          </div>
        ) : (
          filteredChats.map((chat) => (
            <div
              key={chat.id}
              onClick={() => onSelectChat(chat)}
              className={`flex items-center p-4 cursor-pointer hover:bg-gray-700 transition-colors border-b border-gray-700 ${
                selectedChatId === chat.id ? 'bg-gray-700' : ''
              }`}
            >
              {/* Chat Avatar */}
              <div className="flex-shrink-0 mr-3">
                <div className="w-12 h-12 bg-zonenium-primary rounded-full flex items-center justify-center">
                  {chat.chat_type === 'group' ? (
                    <Users className="w-6 h-6 text-white" />
                  ) : (
                    <MessageCircle className="w-6 h-6 text-white" />
                  )}
                </div>
              </div>

              {/* Chat Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <h3 className="text-white font-medium truncate">
                    {getChatDisplayName(chat)}
                  </h3>
                  <span className="text-xs text-zonenium-gray">
                    {formatTime(chat.last_message_at)}
                  </span>
                </div>
                
                <p className="text-zonenium-gray text-sm truncate">
                  {chat.last_message || t('chat.noMessages')}
                </p>
              </div>

              {/* Unread indicator (placeholder) */}
              {/* You can add unread count logic here later */}
            </div>
          ))
        )}
      </div>
      
      {/* User Search Modal */}
      <UserSearchModal 
        isOpen={showUserSearch}
        onClose={handleUserSearchClose}
        onChatSelected={handleChatFromSearch}
      />
      
      {/* Group Creation Modal */}
      <GroupCreationModal
        isOpen={showGroupCreation}
        onClose={handleGroupCreationClose}
        onGroupCreated={handleGroupCreated}
      />
    </div>
  );
};

export default ChatList;