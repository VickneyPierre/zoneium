import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../context/AuthContext';
import ChatList from './ChatList';
import ChatWindow from './ChatWindow';
import { LogOut, Settings } from 'lucide-react';

const Dashboard = () => {
  const { t } = useTranslation();
  const [selectedChat, setSelectedChat] = useState(null);
  const { user, logout } = useAuth();

  const handleSelectChat = (chat) => {
    setSelectedChat(chat);
  };

  const handleLogout = () => {
    logout();
  };

  return (
    <div className="h-screen flex bg-zonenium-dark">
      {/* Sidebar - Chat List */}
      <div className="w-1/3 max-w-sm min-w-[320px] border-r border-gray-700">
        <ChatList 
          onSelectChat={handleSelectChat}
          selectedChatId={selectedChat?.id}
        />
        
        {/* User Profile Footer */}
        <div className="p-4 bg-gray-900 border-t border-gray-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-zonenium-secondary rounded-full flex items-center justify-center mr-3">
                <span className="text-white font-medium">
                  {user?.full_name?.charAt(0) || user?.username?.charAt(0) || 'U'}
                </span>
              </div>
              <div>
                <p className="text-white font-medium text-sm">
                  {user?.full_name || user?.username}
                </p>
                <p className="text-zonenium-gray text-xs">{t('chat.online')}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-1">
              <button className="p-2 text-zonenium-gray hover:text-white transition-colors">
                <Settings className="w-4 h-4" />
              </button>
              <button 
                onClick={handleLogout}
                className="p-2 text-zonenium-gray hover:text-white transition-colors"
                title="Logout"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1">
        <ChatWindow selectedChat={selectedChat} />
      </div>
    </div>
  );
};

export default Dashboard;