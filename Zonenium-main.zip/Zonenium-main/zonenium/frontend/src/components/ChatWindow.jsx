import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import { chatAPI, messageAPI, fileAPI } from '../services/api';
import { Send, MoreVertical, Phone, Video, Paperclip, Mic } from 'lucide-react';
import FileUpload, { FileMessage } from './FileUpload';
import VoiceRecorder, { VoiceMessage } from './VoiceRecorder';
import toast from 'react-hot-toast';

const ChatWindow = ({ selectedChat }) => {
  const { t } = useTranslation();
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [showFileUpload, setShowFileUpload] = useState(false);
  const [showVoiceRecorder, setShowVoiceRecorder] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);
  const typingTimeoutRef = useRef(null);
  const { user } = useAuth();
  const { joinChat, leaveChat, startTyping, stopTyping, getChatTypingUsers } = useSocket();

  useEffect(() => {
    if (selectedChat) {
      fetchMessages();
      joinChat(selectedChat.id);
      
      // Listen for real-time messages
      const handleNewMessage = (event) => {
        const messageData = event.detail;
        if (messageData.chat_id === selectedChat.id) {
          setMessages(prev => {
            // Check if message already exists to avoid duplicates
            const exists = prev.some(msg => msg.id === messageData.id);
            if (!exists) {
              return [...prev, messageData];
            }
            return prev;
          });
        }
      };
      
      window.addEventListener('newMessage', handleNewMessage);
      
      return () => {
        leaveChat(selectedChat.id);
        window.removeEventListener('newMessage', handleNewMessage);
      };
    }
  }, [selectedChat]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const fetchMessages = async () => {
    try {
      setLoading(true);
      const response = await chatAPI.getChatMessages(selectedChat.id);
      setMessages(response.messages || []);
    } catch (error) {
      toast.error(t('chat.failedToLoad') + ' messages');
      console.error('Error fetching messages:', error);
    } finally {
      setLoading(false);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleMessageChange = (e) => {
    setNewMessage(e.target.value);
    
    // Handle typing indicators
    if (selectedChat && e.target.value.trim()) {
      if (!isTyping) {
        setIsTyping(true);
        startTyping(selectedChat.id);
      }
      
      // Reset typing timeout
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      
      typingTimeoutRef.current = setTimeout(() => {
        setIsTyping(false);
        stopTyping(selectedChat.id);
      }, 1000);
    } else if (isTyping) {
      setIsTyping(false);
      stopTyping(selectedChat.id);
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
    }
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || sending) return;

    const messageText = newMessage.trim();
    setNewMessage('');
    setSending(true);

    // Stop typing when sending
    if (isTyping) {
      setIsTyping(false);
      stopTyping(selectedChat.id);
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
    }

    try {
      // Find recipient (other participant in private chat)
      const recipientId = selectedChat.participants.find(id => id !== user.id);
      
      const messageData = {
        content: messageText,
        recipient_id: recipientId,
        chat_id: selectedChat.id,
        message_type: 'text'
      };

      // Send message - real-time update will come via socket
      await messageAPI.sendMessage(messageData);
      
    } catch (error) {
      toast.error(t('chat.failedToSend'));
      console.error('Error sending message:', error);
      // Restore message text on error
      setNewMessage(messageText);
    } finally {
      setSending(false);
    }
  };

  const formatMessageTime = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: false 
    });
  };

  const getChatDisplayName = (chat) => {
    if (chat.chat_type === 'group') {
      return chat.name || t('chat.groupChat');
    } else {
      // For private chats, show the other participant's name
      const otherParticipant = chat.participants?.find(id => id !== user?.id);
      return `${t('chat.user')} ${otherParticipant?.substring(0, 8)}...` || t('chat.privateChat');
    }
  };

  const handleSendFile = async (fileData) => {
    const recipientId = selectedChat.participants.find(id => id !== user._id);
    setSending(true);
    
    try {
      const sentMessage = await fileAPI.sendFileMessage({
        recipient_id: recipientId,
        file_data: fileData.file_data,
        file_name: fileData.file_name,
        file_type: fileData.file_type,
        file_size: fileData.file_size,
        chat_id: selectedChat._id
      });
      
      setMessages(prev => [...prev, sentMessage]);
      setShowFileUpload(false);
      toast.success(t('file.uploadSuccess'));
    } catch (error) {
      toast.error(t('chat.failedToSend'));
      console.error('Error sending file:', error);
    } finally {
      setSending(false);
    }
  };

  const handleFileUploadCancel = () => {
    setShowFileUpload(false);
  };

  const handlePaperclipClick = () => {
    setShowFileUpload(true);
  };

  const handleMicClick = () => {
    setShowVoiceRecorder(true);
  };

  const handleSendVoice = async (voiceData) => {
    const recipientId = selectedChat.participants.find(id => id !== user._id);
    setSending(true);
    
    try {
      const sentMessage = await fileAPI.sendFileMessage({
        recipient_id: recipientId,
        file_data: voiceData.file_data,
        file_name: voiceData.file_name,
        file_type: voiceData.file_type,
        file_size: voiceData.file_size,
        chat_id: selectedChat._id,
        duration: voiceData.duration // For voice messages
      });
      
      setMessages(prev => [...prev, sentMessage]);
      setShowVoiceRecorder(false);
      toast.success(t('voice.sendSuccess'));
    } catch (error) {
      toast.error(t('chat.failedToSend'));
      console.error('Error sending voice message:', error);
    } finally {
      setSending(false);
    }
  };

  const handleVoiceRecorderCancel = () => {
    setShowVoiceRecorder(false);
  };

  if (!selectedChat) {
    return (
      <div className="h-full flex items-center justify-center bg-gray-900">
        <div className="text-center text-zonenium-gray">
          <div className="mb-4">
            <img 
              src="/images/zonenium-logo.png" 
              alt="Zonenium" 
              className="h-16 w-16 mx-auto opacity-50"
            />
          </div>
          <h2 className="text-2xl font-semibold mb-2">{t('app.welcome')}</h2>
          <p>{t('chat.selectChat')}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-gray-900">
      {/* Chat Header */}
      <div className="flex items-center justify-between p-4 bg-gray-800 border-b border-gray-700">
        <div className="flex items-center">
          <div className="w-10 h-10 bg-zonenium-primary rounded-full flex items-center justify-center mr-3">
            <span className="text-white font-medium">
              {getChatDisplayName(selectedChat).charAt(0)}
            </span>
          </div>
          <div>
            <h2 className="text-white font-semibold">
              {getChatDisplayName(selectedChat)}
            </h2>
            <p className="text-zonenium-gray text-sm">
              {selectedChat.participants?.length} {t('chat.participants')}
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button className="p-2 text-zonenium-gray hover:text-white transition-colors">
            <Phone className="w-5 h-5" />
          </button>
          <button className="p-2 text-zonenium-gray hover:text-white transition-colors">
            <Video className="w-5 h-5" />
          </button>
          <button className="p-2 text-zonenium-gray hover:text-white transition-colors">
            <MoreVertical className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 messages-container">
        {loading ? (
          <div className="flex justify-center items-center h-full">
            <div className="text-zonenium-gray">{t('chat.loadingMessages')}</div>
          </div>
        ) : messages.length === 0 ? (
          <div className="flex justify-center items-center h-full">
            <div className="text-center text-zonenium-gray">
              <p className="text-lg mb-2">{t('chat.noMessages')}</p>
              <p className="text-sm">{t('chat.sendFirst')}</p>
            </div>
          </div>
        ) : (
          <>
            <div className="space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.sender_id === user.id ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg message-bubble ${
                      message.sender_id === user.id
                        ? 'bg-zonenium-primary text-white message-sent'
                        : 'bg-gray-700 text-white message-received'
                    }`}
                  >
                    {message.message_type === 'file' && (
                      <FileMessage message={message} />
                    )}
                    {message.message_type === 'voice' && (
                      <VoiceMessage message={message} />
                    )}
                    {message.message_type === 'text' && (
                      <p className="break-words">{message.content}</p>
                    )}
                    {message.message_type === 'image' && (
                      <div>
                        <img 
                          src={`data:${message.file_type};base64,${message.content}`}
                          alt="Shared image"
                          className="max-w-full h-auto rounded"
                        />
                        {message.file_name && (
                          <p className="text-xs mt-1 opacity-70">{message.file_name}</p>
                        )}
                      </div>
                    )}
                    {(message.message_type === 'text' || !message.message_type) && (
                      <>
                        <p className="text-xs mt-1 opacity-70">
                          {formatMessageTime(message.sent_at)}
                        </p>
                      </>
                    )}
                  </div>
                </div>
              ))}
              
              {/* Typing Indicator */}
              {(() => {
                const typingUsers = getChatTypingUsers(selectedChat.id);
                const otherTypingUsers = typingUsers.filter(userId => userId !== user.id);
                
                if (otherTypingUsers.length > 0) {
                  return (
                    <div className="flex justify-start">
                      <div className="max-w-xs lg:max-w-md px-4 py-2 rounded-lg bg-gray-700 text-white">
                        <div className="typing-indicator">
                          <span className="typing-dot"></span>
                          <span className="typing-dot"></span>
                          <span className="typing-dot"></span>
                        </div>
                      </div>
                    </div>
                  );
                }
                return null;
              })()}
              
              <div ref={messagesEndRef} />
            </div>
          </>
        )}
      </div>

      {/* Message Input */}
      <div className="bg-gray-800 border-t border-gray-700">
        {showFileUpload && (
          <FileUpload 
            onFileSelected={handleSendFile}
            onCancel={handleFileUploadCancel}
            disabled={sending}
          />
        )}

        {showVoiceRecorder && (
          <VoiceRecorder
            onVoiceRecorded={handleSendVoice}
            onCancel={handleVoiceRecorderCancel}
            disabled={sending}
          />
        )}
        
        <div className="p-4">
          <form onSubmit={handleSendMessage} className="flex items-center space-x-2">
            <button
              type="button"
              onClick={handlePaperclipClick}
              className="p-2 text-zonenium-gray hover:text-white transition-colors"
              disabled={sending}
            >
              <Paperclip className="w-5 h-5" />
            </button>

            <button
              type="button"
              onClick={handleMicClick}
              className="p-2 text-zonenium-gray hover:text-white transition-colors"
              disabled={sending}
            >
              <Mic className="w-5 h-5" />
            </button>
            
            <div className="flex-1">
              <input
                type="text"
                value={newMessage}
                onChange={handleMessageChange}
                placeholder={t('placeholders.typeMessage')}
                className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-full text-white placeholder-zonenium-gray focus:outline-none focus:border-zonenium-primary"
                disabled={sending}
              />
            </div>
            
            <button
              type="submit"
              disabled={!newMessage.trim() || sending}
              className="p-2 bg-zonenium-primary text-white rounded-full hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-5 h-5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ChatWindow;