import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Search, X, MessageCircle, Loader } from 'lucide-react';
import { userAPI, chatAPI } from '../services/api';
import toast from 'react-hot-toast';

const UserSearchModal = ({ isOpen, onClose, onChatSelected }) => {
  const { t } = useTranslation();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [startingChat, setStartingChat] = useState(null);

  useEffect(() => {
    if (searchQuery.length >= 2) {
      const debounceTimer = setTimeout(() => {
        handleSearch();
      }, 500);
      
      return () => clearTimeout(debounceTimer);
    } else {
      setSearchResults([]);
    }
  }, [searchQuery]);

  const handleSearch = async () => {
    if (searchQuery.length < 2) return;
    
    setSearching(true);
    try {
      const response = await userAPI.searchUsers(searchQuery);
      setSearchResults(response.users || []);
    } catch (error) {
      toast.error(t('chat.failedToLoad') + ' users');
      console.error('Search error:', error);
    } finally {
      setSearching(false);
    }
  };

  const handleStartChat = async (user) => {
    setStartingChat(user._id);
    try {
      const chat = await chatAPI.startNewChat(user._id);
      onChatSelected(chat);
      onClose();
      toast.success(`Started chat with ${user.full_name}`);
    } catch (error) {
      toast.error('Failed to start chat');
      console.error('Start chat error:', error);
    } finally {
      setStartingChat(null);
    }
  };

  const handleClose = () => {
    setSearchQuery('');
    setSearchResults([]);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg w-full max-w-md mx-4">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-lg font-semibold text-white">
            {t('chat.searchUsers')}
          </h2>
          <button
            onClick={handleClose}
            className="text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Input */}
        <div className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder={t('placeholders.searchUsers')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-md text-white placeholder-gray-400 focus:outline-none focus:border-zonenium-primary"
              autoFocus
            />
          </div>
        </div>

        {/* Search Results */}
        <div className="max-h-96 overflow-y-auto">
          {searching && (
            <div className="p-8 text-center">
              <Loader className="w-6 h-6 animate-spin mx-auto mb-2 text-zonenium-primary" />
              <p className="text-gray-400">{t('common.searching')}</p>
            </div>
          )}

          {!searching && searchQuery.length >= 2 && searchResults.length === 0 && (
            <div className="p-8 text-center text-gray-400">
              <Search className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>{t('chat.noUsersFound')}</p>
            </div>
          )}

          {!searching && searchQuery.length < 2 && (
            <div className="p-8 text-center text-gray-400">
              <Search className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>{t('chat.typeToSearch')}</p>
            </div>
          )}

          {searchResults.map((user) => (
            <div
              key={user._id}
              className="flex items-center justify-between p-4 hover:bg-gray-700 border-b border-gray-700 last:border-b-0"
            >
              <div className="flex items-center">
                <div className="w-10 h-10 bg-zonenium-primary rounded-full flex items-center justify-center mr-3">
                  <span className="text-white font-medium">
                    {user.full_name?.charAt(0) || user.username?.charAt(0) || 'U'}
                  </span>
                </div>
                <div>
                  <h3 className="text-white font-medium">{user.full_name}</h3>
                  <p className="text-gray-400 text-sm">@{user.username}</p>
                </div>
              </div>
              
              <button
                onClick={() => handleStartChat(user)}
                disabled={startingChat === user._id}
                className="flex items-center space-x-2 px-3 py-1 bg-zonenium-primary hover:bg-blue-700 text-white rounded-md text-sm transition-colors disabled:opacity-50"
              >
                {startingChat === user._id ? (
                  <Loader className="w-4 h-4 animate-spin" />
                ) : (
                  <MessageCircle className="w-4 h-4" />
                )}
                <span>{t('chat.message')}</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default UserSearchModal;