import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Languages, Check } from 'lucide-react';

const languages = [
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'fr', name: 'Français', flag: '🇫🇷' },
  { code: 'es', name: 'Español', flag: '🇪🇸' },
  { code: 'ht', name: 'Kreyòl Ayisyen', flag: '🇭🇹' },
  { code: 'zh', name: '中文', flag: '🇨🇳' },
  { code: 'pt', name: 'Português', flag: '🇧🇷' }
];

const LanguageSelector = ({ isDropdown = false, onLanguageChange = null }) => {
  const { i18n } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);

  const handleLanguageChange = (langCode) => {
    i18n.changeLanguage(langCode);
    setIsOpen(false);
    if (onLanguageChange) {
      onLanguageChange(langCode);
    }
  };

  const currentLanguage = languages.find(lang => lang.code === i18n.language) || languages[0];

  if (isDropdown) {
    return (
      <div className="relative">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center space-x-2 px-3 py-2 text-sm bg-gray-700 hover:bg-gray-600 rounded-md transition-colors"
        >
          <Languages className="w-4 h-4" />
          <span className="text-lg">{currentLanguage.flag}</span>
          <span className="text-white">{currentLanguage.name}</span>
        </button>

        {isOpen && (
          <div className="absolute top-full right-0 mt-1 w-48 bg-gray-800 border border-gray-600 rounded-md shadow-lg z-50">
            {languages.map((language) => (
              <button
                key={language.code}
                onClick={() => handleLanguageChange(language.code)}
                className="w-full flex items-center space-x-3 px-4 py-3 text-sm text-white hover:bg-gray-700 transition-colors first:rounded-t-md last:rounded-b-md"
              >
                <span className="text-lg">{language.flag}</span>
                <span className="flex-1 text-left">{language.name}</span>
                {i18n.language === language.code && (
                  <Check className="w-4 h-4 text-zonenium-primary" />
                )}
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }

  // Full screen language selection (for initial setup)
  return (
    <div className="min-h-screen bg-zonenium-dark flex items-center justify-center px-4">
      <div className="max-w-md w-full space-y-6">
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <img 
              src="/images/zonenium-logo.png" 
              alt="Zonenium Logo" 
              className="h-16 w-16 object-contain"
            />
          </div>
          <h2 className="text-3xl font-bold text-white mb-2">
            Choose Your Language
          </h2>
          <p className="text-zonenium-gray">
            Select your preferred language to continue
          </p>
        </div>

        <div className="space-y-2">
          {languages.map((language) => (
            <button
              key={language.code}
              onClick={() => handleLanguageChange(language.code)}
              className="w-full flex items-center space-x-4 p-4 bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors border border-gray-700 hover:border-zonenium-primary"
            >
              <span className="text-2xl">{language.flag}</span>
              <span className="text-white text-lg font-medium">{language.name}</span>
              {i18n.language === language.code && (
                <div className="ml-auto">
                  <Check className="w-5 h-5 text-zonenium-primary" />
                </div>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LanguageSelector;