import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { X, Users, Plus, Check, Image as ImageIcon } from 'lucide-react';
import { chatAPI, userAPI } from '../services/api';
import toast from 'react-hot-toast';

const GroupCreationModal = ({ isOpen, onClose, onGroupCreated }) => {
  const { t } = useTranslation();
  const [step, setStep] = useState(1); // 1: Basic info, 2: Add members
  const [groupData, setGroupData] = useState({
    name: '',
    description: '',
    avatar: null
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [searching, setSearching] = useState(false);
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    if (searchQuery.length >= 2) {
      const debounceTimer = setTimeout(() => {
        handleUserSearch();
      }, 500);
      return () => clearTimeout(debounceTimer);
    } else {
      setSearchResults([]);
    }
  }, [searchQuery]);

  const handleUserSearch = async () => {
    if (searchQuery.length < 2) return;
    
    setSearching(true);
    try {
      const response = await userAPI.searchUsers(searchQuery);
      setSearchResults(response.users || []);
    } catch (error) {
      toast.error('Failed to search users');
    } finally {
      setSearching(false);
    }
  };

  const handleUserToggle = (user) => {
    setSelectedUsers(prev => {
      const isSelected = prev.some(u => u.id === user.id);
      if (isSelected) {
        return prev.filter(u => u.id !== user.id);
      } else {
        return [...prev, user];
      }
    });
  };

  const handleImageUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { // 2MB limit
        toast.error('Image must be smaller than 2MB');
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        setGroupData(prev => ({
          ...prev,
          avatar: e.target.result
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCreateGroup = async () => {
    if (!groupData.name.trim()) {
      toast.error('Group name is required');
      return;
    }

    if (selectedUsers.length === 0) {
      toast.error('Please add at least one member');
      return;
    }

    setCreating(true);
    try {
      const createData = {
        name: groupData.name.trim(),
        description: groupData.description.trim(),
        participants: selectedUsers.map(user => user.id),
        avatar: groupData.avatar
      };

      const createdGroup = await chatAPI.createGroup(createData);
      onGroupCreated(createdGroup);
      onClose();
      toast.success(`Group "${groupData.name}" created successfully!`);
      
      // Reset form
      setGroupData({ name: '', description: '', avatar: null });
      setSelectedUsers([]);
      setStep(1);
    } catch (error) {
      toast.error('Failed to create group');
      console.error('Group creation error:', error);
    } finally {
      setCreating(false);
    }
  };

  const handleClose = () => {
    setGroupData({ name: '', description: '', avatar: null });
    setSelectedUsers([]);
    setSearchQuery('');
    setSearchResults([]);
    setStep(1);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg w-full max-w-md mx-4 max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-lg font-semibold text-white">
            {step === 1 ? 'Create Group' : 'Add Members'}
          </h2>
          <button
            onClick={handleClose}
            className="text-gray-400 hover:text-white"
            disabled={creating}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="overflow-y-auto max-h-[calc(90vh-120px)]">
          {step === 1 && (
            <div className="p-4 space-y-4">
              {/* Group Avatar */}
              <div className="flex justify-center">
                <div className="relative">
                  <div className="w-20 h-20 bg-gray-700 rounded-full flex items-center justify-center overflow-hidden">
                    {groupData.avatar ? (
                      <img
                        src={groupData.avatar}
                        alt="Group avatar"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <Users className="w-8 h-8 text-gray-400" />
                    )}
                  </div>
                  <label className="absolute bottom-0 right-0 bg-zonenium-primary rounded-full p-1 cursor-pointer hover:bg-blue-700">
                    <ImageIcon className="w-4 h-4 text-white" />
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              {/* Group Name */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Group Name *
                </label>
                <input
                  type="text"
                  value={groupData.name}
                  onChange={(e) => setGroupData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter group name"
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white placeholder-gray-400 focus:outline-none focus:border-zonenium-primary"
                  maxLength={100}
                />
              </div>

              {/* Group Description */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Description (optional)
                </label>
                <textarea
                  value={groupData.description}
                  onChange={(e) => setGroupData(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="What's this group about?"
                  rows={3}
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white placeholder-gray-400 focus:outline-none focus:border-zonenium-primary resize-none"
                  maxLength={500}
                />
                <p className="text-xs text-gray-400 mt-1">
                  {groupData.description.length}/500
                </p>
              </div>

              <button
                onClick={() => setStep(2)}
                disabled={!groupData.name.trim()}
                className="w-full py-2 bg-zonenium-primary hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-md font-medium transition-colors"
              >
                Next: Add Members
              </button>
            </div>
          )}

          {step === 2 && (
            <div className="p-4">
              {/* Selected Members */}
              {selectedUsers.length > 0 && (
                <div className="mb-4">
                  <p className="text-sm text-gray-300 mb-2">
                    Selected members ({selectedUsers.length})
                  </p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {selectedUsers.map(user => (
                      <div
                        key={user.id}
                        className="flex items-center space-x-2 bg-zonenium-primary/20 px-3 py-1 rounded-full"
                      >
                        <span className="text-sm text-white">{user.full_name}</span>
                        <button
                          onClick={() => handleUserToggle(user)}
                          className="text-gray-300 hover:text-white"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* User Search */}
              <div className="mb-4">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search users to add..."
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white placeholder-gray-400 focus:outline-none focus:border-zonenium-primary"
                />
              </div>

              {/* Search Results */}
              <div className="space-y-2 mb-4 max-h-48 overflow-y-auto">
                {searching && (
                  <div className="text-center py-4 text-gray-400">
                    Searching...
                  </div>
                )}
                
                {!searching && searchQuery.length >= 2 && searchResults.length === 0 && (
                  <div className="text-center py-4 text-gray-400">
                    No users found
                  </div>
                )}

                {searchResults.map(user => {
                  const isSelected = selectedUsers.some(u => u.id === user.id);
                  return (
                    <div
                      key={user.id}
                      onClick={() => handleUserToggle(user)}
                      className="flex items-center justify-between p-3 hover:bg-gray-700 rounded-md cursor-pointer"
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-zonenium-primary rounded-full flex items-center justify-center">
                          <span className="text-white text-sm font-medium">
                            {user.full_name?.charAt(0) || 'U'}
                          </span>
                        </div>
                        <div>
                          <p className="text-white text-sm">{user.full_name}</p>
                          <p className="text-gray-400 text-xs">@{user.username}</p>
                        </div>
                      </div>
                      {isSelected && (
                        <Check className="w-5 h-5 text-zonenium-primary" />
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Action Buttons */}
              <div className="flex space-x-3">
                <button
                  onClick={() => setStep(1)}
                  disabled={creating}
                  className="flex-1 py-2 border border-gray-600 text-gray-300 rounded-md hover:bg-gray-700 transition-colors"
                >
                  Back
                </button>
                <button
                  onClick={handleCreateGroup}
                  disabled={selectedUsers.length === 0 || creating}
                  className="flex-1 py-2 bg-zonenium-secondary hover:bg-green-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-md font-medium transition-colors"
                >
                  {creating ? 'Creating...' : `Create Group`}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default GroupCreationModal;