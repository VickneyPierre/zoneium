import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_BACKEND_URL || 'http://localhost:8002';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Handle response errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      // Only redirect if not already on login/register pages
      if (window.location.pathname !== '/login' && window.location.pathname !== '/register') {
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  register: async (userData) => {
    const response = await api.post('/api/auth/register', userData);
    return response.data;
  },

  login: async (credentials) => {
    const response = await api.post('/api/auth/login', credentials);
    return response.data;
  },

  getCurrentUser: async () => {
    const response = await api.get('/api/auth/me');
    return response.data;
  },

  updateStatus: async (isOnline) => {
    const response = await api.put('/api/users/status', { is_online: isOnline });
    return response.data;
  }
};

// Chat API
export const chatAPI = {
  getUserChats: async () => {
    const response = await api.get('/api/chats');
    return response.data;
  },

  getChat: async (chatId) => {
    const response = await api.get(`/api/chats/${chatId}`);
    return response.data;
  },

  getChatMessages: async (chatId, skip = 0, limit = 50) => {
    const response = await api.get(`/api/chats/${chatId}/messages`, {
      params: { skip, limit }
    });
    return response.data;
  },

  startNewChat: async (recipientId) => {
    const response = await api.post('/api/chats/start', {}, {
      params: { recipient_id: recipientId }
    });
    return response.data;
  },

  // Group management
  createGroup: async (groupData) => {
    const response = await api.post('/api/groups/create', groupData);
    return response.data;
  },

  updateGroup: async (groupId, updateData) => {
    const response = await api.put(`/api/groups/${groupId}`, updateData);
    return response.data;
  },

  manageGroupMember: async (groupId, actionData) => {
    const response = await api.post(`/api/groups/${groupId}/members`, actionData);
    return response.data;
  },

  getGroupMembers: async (groupId) => {
    const response = await api.get(`/api/groups/${groupId}/members`);
    return response.data;
  }
};

// Message API
export const messageAPI = {
  sendMessage: async (messageData) => {
    const response = await api.post('/api/messages', messageData);
    return response.data;
  },

  markMessageRead: async (messageId) => {
    const response = await api.put(`/api/messages/${messageId}/read`);
    return response.data;
  },

  getUnreadCount: async () => {
    const response = await api.get('/api/messages/unread/count');
    return response.data;
  }
};

// User API
export const userAPI = {
  searchUsers: async (query) => {
    const response = await api.get('/api/users/search', {
      params: { query }
    });
    return response.data;
  }
};

// File Upload API
export const fileAPI = {
  uploadFile: async (file) => {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await api.post('/api/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  },

  sendFileMessage: async (messageData) => {
    const response = await api.post('/api/messages/file', messageData);
    return response.data;
  }
};

// Status API
export const statusAPI = {
  checkStatus: async () => {
    const response = await api.get('/api/status');
    return response.data;
  }
};

export default api;