from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime
import uuid

# User Models
class UserBase(BaseModel):
    username: str
    email: str
    full_name: str
    bio: Optional[str] = ""
    avatar: Optional[str] = ""
    phone: Optional[str] = ""

class UserCreate(UserBase):
    password: str

class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    bio: Optional[str] = None
    avatar: Optional[str] = None
    phone: Optional[str] = None

class User(UserBase):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()), alias="_id")
    password: Optional[str] = None  # Include password for database storage
    is_active: bool = True
    is_online: bool = False
    last_seen: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    
    class Config:
        populate_by_name = True

# Message Models
class MessageBase(BaseModel):
    content: str
    message_type: str = "text"  # text, image, file, voice, video
    file_name: Optional[str] = None  # Original filename for file messages
    file_size: Optional[int] = None  # File size in bytes
    file_type: Optional[str] = None  # MIME type
    duration: Optional[int] = None  # Duration in seconds for voice/video messages

class MessageCreate(MessageBase):
    recipient_id: str
    chat_id: Optional[str] = None

class Message(MessageBase):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()), alias="_id")
    sender_id: str
    recipient_id: str
    chat_id: str
    is_read: bool = False
    sent_at: datetime = Field(default_factory=datetime.utcnow)
    delivered_at: Optional[datetime] = None
    read_at: Optional[datetime] = None
    
    class Config:
        populate_by_name = True

# Chat Models
class ChatBase(BaseModel):
    chat_type: str = "private"  # private, group
    name: Optional[str] = None  # For group chats
    description: Optional[str] = None
    avatar: Optional[str] = None

class Chat(ChatBase):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()), alias="_id")
    participants: List[str] = []  # User IDs
    created_by: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    last_message_at: Optional[datetime] = None
    last_message: Optional[str] = None
    
    class Config:
        populate_by_name = True

# Authentication Models
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None

class UserLogin(BaseModel):
    username: str
    password: str

# Response Models
class UserResponse(BaseModel):
    id: str
    username: str
    email: str
    full_name: str
    bio: Optional[str] = ""
    avatar: Optional[str] = ""
    phone: Optional[str] = ""
    is_active: bool = True
    is_online: bool = False
    last_seen: Optional[datetime] = None
    created_at: datetime
    
    @classmethod
    def from_user(cls, user: User):
        return cls(
            id=user.id,
            username=user.username,
            email=user.email,
            full_name=user.full_name,
            bio=user.bio or "",
            avatar=user.avatar or "",
            phone=user.phone or "",
            is_active=user.is_active,
            is_online=user.is_online,
            last_seen=user.last_seen,
            created_at=user.created_at
        )
class StatusCheck(BaseModel):
    status: str = "ok"
    message: str = "Zonenium backend is running"
    timestamp: datetime = Field(default_factory=datetime.utcnow)

# Group Management Models
class GroupCreateRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = Field(None, max_length=500)
    participants: List[str] = Field(..., min_items=1)  # List of user IDs to add
    avatar: Optional[str] = None  # Base64 encoded group avatar

class GroupUpdateRequest(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    description: Optional[str] = Field(None, max_length=500)
    avatar: Optional[str] = None

class GroupMemberAction(BaseModel):
    user_id: str
    action: str = Field(..., pattern="^(add|remove|make_admin|remove_admin)$")

class GroupInfo(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    avatar: Optional[str] = None
    chat_type: str = "group"
    participants: List[str] = []
    admins: List[str] = []  # List of admin user IDs
    created_by: str
    created_at: datetime
    last_message_at: Optional[datetime] = None
    last_message: Optional[str] = None
    member_count: int = 0

class ChatListResponse(BaseModel):
    chats: List[Chat]
    total: int

class MessageListResponse(BaseModel):
    messages: List[Message]
    total: int

class MessageListResponse(BaseModel):
    messages: List[Message]
    total: int