from motor.motor_asyncio import AsyncIOMotorClient
from typing import Optional, List
import os
from datetime import datetime
from models import User, UserCreate, Message, MessageCreate, Chat
import uuid

class ZoneniumDatabase:
    client: Optional[AsyncIOMotorClient] = None
    database = None

    def __init__(self):
        self.mongo_url = os.getenv('MONGO_URL', 'mongodb://localhost:27017/zonenium')
        
    async def connect_to_database(self):
        """Create database connection"""
        self.client = AsyncIOMotorClient(self.mongo_url)
        db_name = self.mongo_url.split('/')[-1] if '/' in self.mongo_url else 'zonenium'
        self.database = self.client[db_name]
        print(f"Connected to MongoDB: {db_name}")

    async def close_database_connection(self):
        """Close database connection"""
        if self.client:
            self.client.close()

    # User Operations
    async def create_user(self, user_data: UserCreate) -> User:
        """Create new user"""
        user_dict = user_data.dict()
        user_dict["_id"] = str(uuid.uuid4())
        user_dict["created_at"] = datetime.utcnow()
        user_dict["is_active"] = True
        user_dict["is_online"] = False
        
        # Hash the password if it's not already hashed
        from passlib.context import CryptContext
        pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
        if 'password' in user_dict:
            user_dict["password"] = pwd_context.hash(user_dict["password"])
        
        result = await self.database.users.insert_one(user_dict)
        created_user = await self.database.users.find_one({"_id": user_dict["_id"]})
        return User(**created_user)

    async def get_user_by_username(self, username: str) -> Optional[User]:
        """Get user by username"""
        user_doc = await self.database.users.find_one({"username": username})
        return User(**user_doc) if user_doc else None

    async def get_user_by_id(self, user_id: str) -> Optional[User]:
        """Get user by ID"""
        user_doc = await self.database.users.find_one({"_id": user_id})
        return User(**user_doc) if user_doc else None

    async def search_users(self, query: str, current_user_id: str, limit: int = 10) -> List[User]:
        """Search users by username or full name"""
        search_filter = {
            "$and": [
                {"_id": {"$ne": current_user_id}},  # Exclude current user
                {
                    "$or": [
                        {"username": {"$regex": query, "$options": "i"}},
                        {"full_name": {"$regex": query, "$options": "i"}}
                    ]
                }
            ]
        }
        
        users_cursor = self.database.users.find(search_filter).limit(limit)
        users = []
        async for user_doc in users_cursor:
            # Don't include password in search results
            user_doc.pop("password", None)
            users.append(User(**user_doc))
        return users

    async def update_user_status(self, user_id: str, is_online: bool):
        """Update user online status"""
        update_data = {
            "is_online": is_online,
            "last_seen": datetime.utcnow() if not is_online else None
        }
        await self.database.users.update_one(
            {"_id": user_id}, 
            {"$set": update_data}
        )

    # Chat Operations
    async def create_chat(self, chat_data: Chat) -> Chat:
        """Create new chat"""
        chat_dict = chat_data.dict()
        chat_dict["_id"] = str(uuid.uuid4())
        chat_dict["created_at"] = datetime.utcnow()
        
        result = await self.database.chats.insert_one(chat_dict)
        created_chat = await self.database.chats.find_one({"_id": chat_dict["_id"]})
        return Chat(**created_chat)

    async def get_user_chats(self, user_id: str) -> List[Chat]:
        """Get all chats for a user"""
        chats_cursor = self.database.chats.find(
            {"participants": {"$in": [user_id]}}
        ).sort("last_message_at", -1)
        
        chats = []
        async for chat_doc in chats_cursor:
            chats.append(Chat(**chat_doc))
        return chats

    async def get_chat_by_id(self, chat_id: str) -> Optional[Chat]:
        """Get chat by ID"""
        chat_doc = await self.database.chats.find_one({"_id": chat_id})
        return Chat(**chat_doc) if chat_doc else None

    async def find_private_chat(self, user1_id: str, user2_id: str) -> Optional[Chat]:
        """Find existing private chat between two users"""
        chat_doc = await self.database.chats.find_one({
            "chat_type": "private",
            "participants": {"$all": [user1_id, user2_id], "$size": 2}
        })
        return Chat(**chat_doc) if chat_doc else None

    # Message Operations
    async def create_message(self, message_data: MessageCreate, sender_id: str) -> Message:
        """Create new message"""
        message_dict = message_data.dict()
        message_dict["_id"] = str(uuid.uuid4())
        message_dict["sender_id"] = sender_id
        message_dict["sent_at"] = datetime.utcnow()
        message_dict["is_read"] = False
        
        # If no chat_id provided, find or create private chat
        if not message_dict.get("chat_id"):
            existing_chat = await self.find_private_chat(sender_id, message_data.recipient_id)
            if existing_chat:
                message_dict["chat_id"] = existing_chat.id
            else:
                # Create new private chat
                new_chat = Chat(
                    chat_type="private",
                    participants=[sender_id, message_data.recipient_id],
                    created_by=sender_id
                )
                created_chat = await self.create_chat(new_chat)
                message_dict["chat_id"] = created_chat.id

        result = await self.database.messages.insert_one(message_dict)
        
        # Update chat last message info
        await self.database.chats.update_one(
            {"_id": message_dict["chat_id"]},
            {
                "$set": {
                    "last_message_at": message_dict["sent_at"],
                    "last_message": message_dict["content"][:50] + "..." if len(message_dict["content"]) > 50 else message_dict["content"]
                }
            }
        )
        
        created_message = await self.database.messages.find_one({"_id": message_dict["_id"]})
        return Message(**created_message)

    async def get_chat_messages(self, chat_id: str, skip: int = 0, limit: int = 50) -> List[Message]:
        """Get messages for a chat"""
        messages_cursor = self.database.messages.find(
            {"chat_id": chat_id}
        ).sort("sent_at", -1).skip(skip).limit(limit)
        
        messages = []
        async for message_doc in messages_cursor:
            messages.append(Message(**message_doc))
        return list(reversed(messages))  # Return in chronological order

    async def mark_message_as_read(self, message_id: str, user_id: str):
        """Mark message as read"""
        await self.database.messages.update_one(
            {"_id": message_id, "recipient_id": user_id},
            {
                "$set": {
                    "is_read": True,
                    "read_at": datetime.utcnow()
                }
            }
        )

    async def get_unread_messages_count(self, user_id: str) -> int:
        """Get count of unread messages for user"""
        count = await self.database.messages.count_documents({
            "recipient_id": user_id,
            "is_read": False
        })
        return count

    async def create_group_chat(self, name: str, description: str, participants: List[str], created_by: str, avatar: Optional[str] = None) -> Chat:
        """Create a new group chat"""
        group_dict = {
            "_id": str(uuid.uuid4()),
            "chat_type": "group",
            "name": name,
            "description": description,
            "avatar": avatar,
            "participants": participants,
            "admins": [created_by],  # Creator is automatically admin
            "created_by": created_by,
            "created_at": datetime.utcnow(),
            "last_message_at": None,
            "last_message": None
        }
        
        await self.database.chats.insert_one(group_dict)
        created_chat = await self.database.chats.find_one({"_id": group_dict["_id"]})
        return Chat(**created_chat)

    async def update_group_info(self, chat_id: str, name: Optional[str] = None, description: Optional[str] = None, avatar: Optional[str] = None):
        """Update group information"""
        update_data = {}
        if name is not None:
            update_data["name"] = name
        if description is not None:
            update_data["description"] = description
        if avatar is not None:
            update_data["avatar"] = avatar
        
        if update_data:
            await self.database.chats.update_one(
                {"_id": chat_id, "chat_type": "group"},
                {"$set": update_data}
            )

    async def add_group_member(self, chat_id: str, user_id: str) -> bool:
        """Add a member to group chat"""
        result = await self.database.chats.update_one(
            {"_id": chat_id, "chat_type": "group"},
            {"$addToSet": {"participants": user_id}}
        )
        return result.modified_count > 0

    async def remove_group_member(self, chat_id: str, user_id: str) -> bool:
        """Remove a member from group chat"""
        result = await self.database.chats.update_one(
            {"_id": chat_id, "chat_type": "group"},
            {
                "$pull": {
                    "participants": user_id,
                    "admins": user_id  # Also remove from admins if they were admin
                }
            }
        )
        return result.modified_count > 0

    async def make_group_admin(self, chat_id: str, user_id: str) -> bool:
        """Make a user admin of the group"""
        result = await self.database.chats.update_one(
            {"_id": chat_id, "chat_type": "group", "participants": user_id},
            {"$addToSet": {"admins": user_id}}
        )
        return result.modified_count > 0

    async def remove_group_admin(self, chat_id: str, user_id: str) -> bool:
        """Remove admin privileges from a user"""
        result = await self.database.chats.update_one(
            {"_id": chat_id, "chat_type": "group"},
            {"$pull": {"admins": user_id}}
        )
        return result.modified_count > 0

    async def get_group_members(self, chat_id: str) -> List[User]:
        """Get all members of a group with their info"""
        chat = await self.get_chat_by_id(chat_id)
        if not chat or chat.chat_type != "group":
            return []
        
        members = []
        for user_id in chat.participants:
            user = await self.get_user_by_id(user_id)
            if user:
                members.append(user)
        return members

    async def is_group_admin(self, chat_id: str, user_id: str) -> bool:
        """Check if user is admin of the group"""
        chat_doc = await self.database.chats.find_one({
            "_id": chat_id, 
            "chat_type": "group",
            "admins": user_id
        })
        return chat_doc is not None

    async def initialize_sample_data(self):
        """Initialize with sample users for testing"""
        # Check if sample data already exists
        existing_users = await self.database.users.count_documents({})
        if existing_users > 0:
            print("Sample data already exists")
            # Clear and recreate with correct format
            await self.database.users.delete_many({})
            await self.database.chats.delete_many({})
            await self.database.messages.delete_many({})
            
        print("Initializing sample data...")
        
        # Create sample users
        sample_users = [
            UserCreate(
                username="demo_user",
                email="demo@zonenium.com",
                full_name="Demo User",
                bio="This is a demo user for testing",
                password="demo123"
            ),
            UserCreate(
                username="test_user",
                email="test@zonenium.com", 
                full_name="Test User",
                bio="Another test user",
                password="test123"
            )
        ]
        
        for user_data in sample_users:
            await self.create_user(user_data)
        
        print("Sample data initialized successfully")

# Global database instance
db = ZoneniumDatabase()