import socketio
from typing import Dict, List, Set
import asyncio
from datetime import datetime

class SocketManager:
    def __init__(self):
        # AsyncServer for Socket.IO
        self.sio = socketio.AsyncServer(
            cors_allowed_origins="*",
            async_mode='asgi'
        )
        
        # Store active connections
        self.active_users: Dict[str, str] = {}  # user_id -> session_id
        self.user_sessions: Dict[str, str] = {}  # session_id -> user_id
        self.typing_users: Dict[str, Set[str]] = {}  # chat_id -> set of user_ids who are typing
        
        # Setup event handlers
        self.setup_event_handlers()

    def setup_event_handlers(self):
        @self.sio.event
        async def connect(sid, environ):
            print(f"Client {sid} connected")

        @self.sio.event
        async def disconnect(sid):
            print(f"Client {sid} disconnected")
            await self.handle_user_disconnect(sid)

        @self.sio.event
        async def authenticate(sid, data):
            """Authenticate user and join their rooms"""
            try:
                user_id = data.get('user_id')
                if not user_id:
                    await self.sio.emit('error', {'message': 'User ID required'}, to=sid)
                    return

                # Store user session
                self.active_users[user_id] = sid
                self.user_sessions[sid] = user_id

                # Join user's personal room
                await self.sio.enter_room(sid, f"user_{user_id}")
                
                # Join all user's chat rooms
                chats = data.get('chats', [])
                for chat_id in chats:
                    await self.sio.enter_room(sid, f"chat_{chat_id}")

                # Notify others that user is online
                await self.broadcast_user_status(user_id, True)
                
                await self.sio.emit('authenticated', {'status': 'success'}, to=sid)
                print(f"User {user_id} authenticated with session {sid}")

            except Exception as e:
                print(f"Authentication error: {e}")
                await self.sio.emit('error', {'message': 'Authentication failed'}, to=sid)

        @self.sio.event
        async def join_chat(sid, data):
            """Join a specific chat room"""
            try:
                chat_id = data.get('chat_id')
                if chat_id:
                    await self.sio.enter_room(sid, f"chat_{chat_id}")
                    print(f"Session {sid} joined chat {chat_id}")
            except Exception as e:
                print(f"Join chat error: {e}")

        @self.sio.event
        async def leave_chat(sid, data):
            """Leave a specific chat room"""
            try:
                chat_id = data.get('chat_id')
                if chat_id:
                    await self.sio.leave_room(sid, f"chat_{chat_id}")
                    print(f"Session {sid} left chat {chat_id}")
            except Exception as e:
                print(f"Leave chat error: {e}")

        @self.sio.event
        async def typing_start(sid, data):
            """Handle typing start event"""
            try:
                chat_id = data.get('chat_id')
                user_id = self.user_sessions.get(sid)
                
                if chat_id and user_id:
                    if chat_id not in self.typing_users:
                        self.typing_users[chat_id] = set()
                    
                    self.typing_users[chat_id].add(user_id)
                    
                    # Broadcast typing status to other users in chat
                    await self.sio.emit('user_typing', {
                        'chat_id': chat_id,
                        'user_id': user_id,
                        'typing': True
                    }, room=f"chat_{chat_id}", skip_sid=sid)
                    
            except Exception as e:
                print(f"Typing start error: {e}")

        @self.sio.event
        async def typing_stop(sid, data):
            """Handle typing stop event"""
            try:
                chat_id = data.get('chat_id')
                user_id = self.user_sessions.get(sid)
                
                if chat_id and user_id:
                    if chat_id in self.typing_users:
                        self.typing_users[chat_id].discard(user_id)
                        if not self.typing_users[chat_id]:
                            del self.typing_users[chat_id]
                    
                    # Broadcast typing status to other users in chat
                    await self.sio.emit('user_typing', {
                        'chat_id': chat_id,
                        'user_id': user_id,
                        'typing': False
                    }, room=f"chat_{chat_id}", skip_sid=sid)
                    
            except Exception as e:
                print(f"Typing stop error: {e}")

    async def handle_user_disconnect(self, sid):
        """Handle user disconnection"""
        try:
            user_id = self.user_sessions.get(sid)
            if user_id:
                # Remove from active users
                if user_id in self.active_users:
                    del self.active_users[user_id]
                del self.user_sessions[sid]

                # Remove from typing users
                for chat_id in list(self.typing_users.keys()):
                    if user_id in self.typing_users[chat_id]:
                        self.typing_users[chat_id].discard(user_id)
                        if not self.typing_users[chat_id]:
                            del self.typing_users[chat_id]

                # Notify others that user is offline
                await self.broadcast_user_status(user_id, False)
                print(f"User {user_id} disconnected and cleaned up")

        except Exception as e:
            print(f"Disconnect error: {e}")

    async def broadcast_user_status(self, user_id: str, is_online: bool):
        """Broadcast user online/offline status"""
        try:
            await self.sio.emit('user_status', {
                'user_id': user_id,
                'is_online': is_online,
                'timestamp': datetime.utcnow().isoformat()
            }, room=f"user_{user_id}")
        except Exception as e:
            print(f"Broadcast status error: {e}")

    async def send_message_to_chat(self, chat_id: str, message_data: dict):
        """Send real-time message to all users in a chat"""
        try:
            await self.sio.emit('new_message', message_data, room=f"chat_{chat_id}")
            print(f"Message sent to chat {chat_id}")
        except Exception as e:
            print(f"Send message error: {e}")

    async def send_message_status(self, message_id: str, status: str, user_ids: List[str]):
        """Send message delivery/read status"""
        try:
            status_data = {
                'message_id': message_id,
                'status': status,  # 'delivered', 'read'
                'timestamp': datetime.utcnow().isoformat()
            }
            
            for user_id in user_ids:
                await self.sio.emit('message_status', status_data, room=f"user_{user_id}")
                
        except Exception as e:
            print(f"Send message status error: {e}")

    def get_online_users(self) -> List[str]:
        """Get list of online user IDs"""
        return list(self.active_users.keys())

    def is_user_online(self, user_id: str) -> bool:
        """Check if user is online"""
        return user_id in self.active_users

# Global socket manager instance
socket_manager = SocketManager()