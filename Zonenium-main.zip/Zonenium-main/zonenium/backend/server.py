from fastapi import FastAPI, HTTPException, Depends, status, File, UploadFile
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import socketio
import os
import base64
from datetime import datetime, timedelta
from typing import Optional, List
from jose import JWTError, jwt
from passlib.context import CryptContext

# Import models and database
from models import (
    StatusCheck, User, UserCreate, UserLogin, Token, TokenData, UserResponse,
    Message, MessageCreate, Chat, ChatListResponse, MessageListResponse,
    GroupCreateRequest, GroupUpdateRequest, GroupMemberAction, GroupInfo
)
from database import db
from socket_manager import socket_manager

# Security setup
SECRET_KEY = os.getenv("SECRET_KEY", "zonenium-secret-key-change-in-production")
ALGORITHM = os.getenv("ALGORITHM", "HS256")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "60"))

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    await db.connect_to_database()
    await db.initialize_sample_data()
    print("Zonenium backend started successfully")
    yield
    # Shutdown
    await db.close_database_connection()
    print("Zonenium backend shutdown complete")

# FastAPI app
app = FastAPI(
    title="Zonenium - WhatsApp Clone API",
    description="A comprehensive messaging application API",
    version="1.0.0",
    lifespan=lifespan
)

# Mount Socket.IO app
socket_app = socketio.ASGIApp(socket_manager.sio, app)

# CORS setup
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Update for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Utility functions
def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
        token_data = TokenData(username=username)
    except JWTError:
        raise credentials_exception
    
    user = await db.get_user_by_username(username=token_data.username)
    if user is None:
        raise credentials_exception
    return user

# API Routes

@app.get("/api/status", response_model=StatusCheck)
async def get_status():
    """Health check endpoint"""
    return StatusCheck()

# Authentication Routes
@app.post("/api/auth/register", response_model=UserResponse)
async def register_user(user_data: UserCreate):
    """Register new user"""
    # Check if username already exists
    existing_user = await db.get_user_by_username(user_data.username)
    if existing_user:
        raise HTTPException(
            status_code=400,
            detail="Username already registered"
        )
    
    # Create user (password will be hashed in database.py)
    created_user = await db.create_user(user_data)
    return UserResponse.from_user(created_user)

@app.post("/api/auth/login", response_model=Token)
async def login_user(user_credentials: UserLogin):
    """Login user and return JWT token"""
    user = await db.get_user_by_username(user_credentials.username)
    if not user or not verify_password(user_credentials.password, user.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.username}, expires_delta=access_token_expires
    )
    
    # Update user status to online
    await db.update_user_status(user.id, True)
    
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/api/auth/me", response_model=UserResponse)
async def get_current_user_info(current_user: User = Depends(get_current_user)):
    """Get current user information"""
    return UserResponse.from_user(current_user)

# User Routes
@app.get("/api/users/search")
async def search_users(query: str, current_user: User = Depends(get_current_user)):
    """Search users by username or full name"""
    if len(query.strip()) < 2:
        return {"users": [], "message": "Query too short"}
    
    users = await db.search_users(query.strip(), current_user.id)
    user_responses = [UserResponse.from_user(user) for user in users]
    return {"users": user_responses, "total": len(user_responses)}

@app.put("/api/users/status")
async def update_user_status(is_online: bool, current_user: User = Depends(get_current_user)):
    """Update user online status"""
    await db.update_user_status(current_user.id, is_online)
    return {"message": "Status updated successfully"}

# Chat Routes
@app.get("/api/chats", response_model=ChatListResponse)
async def get_user_chats(current_user: User = Depends(get_current_user)):
    """Get all chats for current user"""
    chats = await db.get_user_chats(current_user.id)
    return ChatListResponse(chats=chats, total=len(chats))

@app.get("/api/chats/{chat_id}", response_model=Chat)
async def get_chat(chat_id: str, current_user: User = Depends(get_current_user)):
    """Get specific chat details"""
    chat = await db.get_chat_by_id(chat_id)
    if not chat:
        raise HTTPException(status_code=404, detail="Chat not found")
    
    # Check if user is participant
    if current_user.id not in chat.participants:
        raise HTTPException(status_code=403, detail="Access denied")
    
    return chat

# Message Routes
@app.post("/api/messages", response_model=Message)
async def send_message(message_data: MessageCreate, current_user: User = Depends(get_current_user)):
    """Send a new message"""
    # Verify recipient exists
    recipient = await db.get_user_by_id(message_data.recipient_id)
    if not recipient:
        raise HTTPException(status_code=404, detail="Recipient not found")
    
    message = await db.create_message(message_data, current_user.id)
    
    # Broadcast message in real-time
    await socket_manager.send_message_to_chat(message.chat_id, {
        'id': message.id,
        'sender_id': message.sender_id,
        'recipient_id': message.recipient_id,
        'chat_id': message.chat_id,
        'content': message.content,
        'message_type': message.message_type,
        'sent_at': message.sent_at.isoformat(),
        'is_read': message.is_read
    })
    
    return message

@app.get("/api/chats/{chat_id}/messages", response_model=MessageListResponse)
async def get_chat_messages(chat_id: str, skip: int = 0, limit: int = 50, current_user: User = Depends(get_current_user)):
    """Get messages for a specific chat"""
    # Verify user has access to chat
    chat = await db.get_chat_by_id(chat_id)
    if not chat:
        raise HTTPException(status_code=404, detail="Chat not found")
    
    if current_user.id not in chat.participants:
        raise HTTPException(status_code=403, detail="Access denied")
    
    messages = await db.get_chat_messages(chat_id, skip, limit)
    return MessageListResponse(messages=messages, total=len(messages))

@app.put("/api/messages/{message_id}/read")
async def mark_message_read(message_id: str, current_user: User = Depends(get_current_user)):
    """Mark message as read"""
    await db.mark_message_as_read(message_id, current_user.id)
    return {"message": "Message marked as read"}

@app.post("/api/upload", response_model=dict)
async def upload_file(file: UploadFile = File(...), current_user: User = Depends(get_current_user)):
    """Upload a file and return base64 encoded data"""
    try:
        # Check file size (limit to 10MB)
        max_size = 10 * 1024 * 1024  # 10MB
        contents = await file.read()
        
        if len(contents) > max_size:
            raise HTTPException(status_code=400, detail="File too large. Maximum size is 10MB.")
        
        # Encode file content to base64
        file_base64 = base64.b64encode(contents).decode('utf-8')
        
        return {
            "file_data": file_base64,
            "file_name": file.filename,
            "file_type": file.content_type,
            "file_size": len(contents)
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error uploading file: {str(e)}")

@app.post("/api/messages/file", response_model=Message)
async def send_file_message(
    recipient_id: str,
    file_data: str,
    file_name: str,
    file_type: str,
    file_size: int,
    chat_id: Optional[str] = None,
    duration: Optional[int] = None,
    current_user: User = Depends(get_current_user)
):
    """Send a file message"""
    # Verify recipient exists
    recipient = await db.get_user_by_id(recipient_id)
    if not recipient:
        raise HTTPException(status_code=404, detail="Recipient not found")
    
    # Determine message type based on file type
    message_type = "file"
    if file_type.startswith("audio/"):
        message_type = "voice"
    elif file_type.startswith("image/"):
        message_type = "image"
    elif file_type.startswith("video/"):
        message_type = "video"
    
    # Create message data
    message_data = MessageCreate(
        content=file_data,  # Base64 encoded file data
        recipient_id=recipient_id,
        chat_id=chat_id,
        message_type=message_type
    )
    
    message = await db.create_message(message_data, current_user.id)
    
    # Prepare update fields
    update_fields = {
        "file_name": file_name,
        "file_type": file_type,
        "file_size": file_size
    }
    
    # Add duration for voice messages
    if message_type == "voice" and duration:
        update_fields["duration"] = duration
    
    # Update message with file metadata
    await db.database.messages.update_one(
        {"_id": message.id},
        {"$set": update_fields}
    )
    
    # Get updated message
    updated_message = await db.database.messages.find_one({"_id": message.id})
    final_message = Message(**updated_message)
    
    # Broadcast file message in real-time
    broadcast_data = {
        'id': final_message.id,
        'sender_id': final_message.sender_id,
        'recipient_id': final_message.recipient_id,
        'chat_id': final_message.chat_id,
        'content': final_message.content,
        'message_type': final_message.message_type,
        'file_name': file_name,
        'file_type': file_type,
        'file_size': file_size,
        'sent_at': final_message.sent_at.isoformat(),
        'is_read': final_message.is_read
    }
    
    # Add duration for voice messages
    if message_type == "voice" and duration:
        broadcast_data['duration'] = duration
    
    await socket_manager.send_message_to_chat(message.chat_id, broadcast_data)
    
    return final_message

@app.get("/api/messages/unread/count")
async def get_unread_count(current_user: User = Depends(get_current_user)):
    """Get count of unread messages"""
    count = await db.get_unread_messages_count(current_user.id)
    return {"unread_count": count}

@app.post("/api/groups/create", response_model=Chat)
async def create_group(group_data: GroupCreateRequest, current_user: User = Depends(get_current_user)):
    """Create a new group chat"""
    # Verify all participants exist
    all_participants = [current_user.id] + group_data.participants
    for user_id in group_data.participants:
        user = await db.get_user_by_id(user_id)
        if not user:
            raise HTTPException(status_code=404, detail=f"User {user_id} not found")
    
    # Remove duplicates and ensure creator is included
    unique_participants = list(set(all_participants))
    
    group = await db.create_group_chat(
        name=group_data.name,
        description=group_data.description or "",
        participants=unique_participants,
        created_by=current_user.id,
        avatar=group_data.avatar
    )
    
    # Notify all participants via WebSocket about new group
    for participant_id in unique_participants:
        await socket_manager.sio.emit('group_created', {
            'group_id': group.id,
            'group_name': group_data.name,
            'created_by': current_user.full_name,
            'member_count': len(unique_participants)
        }, room=f"user_{participant_id}")
    
    return group

@app.put("/api/groups/{group_id}")
async def update_group(group_id: str, group_data: GroupUpdateRequest, current_user: User = Depends(get_current_user)):
    """Update group information"""
    # Check if user is admin of the group
    if not await db.is_group_admin(group_id, current_user.id):
        raise HTTPException(status_code=403, detail="Only group admins can update group info")
    
    await db.update_group_info(
        chat_id=group_id,
        name=group_data.name,
        description=group_data.description,
        avatar=group_data.avatar
    )
    
    # Broadcast group update to all members
    await socket_manager.sio.emit('group_updated', {
        'group_id': group_id,
        'updated_by': current_user.full_name,
        'changes': {
            'name': group_data.name,
            'description': group_data.description
        }
    }, room=f"chat_{group_id}")
    
    return {"message": "Group updated successfully"}

@app.post("/api/groups/{group_id}/members")
async def manage_group_member(group_id: str, action_data: GroupMemberAction, current_user: User = Depends(get_current_user)):
    """Add/remove members or manage admin privileges"""
    # Check if user is admin of the group
    if not await db.is_group_admin(group_id, current_user.id):
        raise HTTPException(status_code=403, detail="Only group admins can manage members")
    
    # Verify target user exists
    target_user = await db.get_user_by_id(action_data.user_id)
    if not target_user:
        raise HTTPException(status_code=404, detail="User not found")
    
    success = False
    action_message = ""
    
    if action_data.action == "add":
        success = await db.add_group_member(group_id, action_data.user_id)
        action_message = f"{target_user.full_name} was added to the group"
        
        # Join the new member to the chat room
        if success:
            await socket_manager.sio.emit('member_added', {
                'group_id': group_id,
                'user_name': target_user.full_name,
                'added_by': current_user.full_name
            }, room=f"chat_{group_id}")
            
            # Notify the new member
            await socket_manager.sio.emit('added_to_group', {
                'group_id': group_id,
                'added_by': current_user.full_name
            }, room=f"user_{action_data.user_id}")
    
    elif action_data.action == "remove":
        success = await db.remove_group_member(group_id, action_data.user_id)
        action_message = f"{target_user.full_name} was removed from the group"
        
        if success:
            await socket_manager.sio.emit('member_removed', {
                'group_id': group_id,
                'user_name': target_user.full_name,
                'removed_by': current_user.full_name
            }, room=f"chat_{group_id}")
    
    elif action_data.action == "make_admin":
        success = await db.make_group_admin(group_id, action_data.user_id)
        action_message = f"{target_user.full_name} is now an admin"
        
        if success:
            await socket_manager.sio.emit('admin_added', {
                'group_id': group_id,
                'user_name': target_user.full_name,
                'made_admin_by': current_user.full_name
            }, room=f"chat_{group_id}")
    
    elif action_data.action == "remove_admin":
        success = await db.remove_group_admin(group_id, action_data.user_id)
        action_message = f"{target_user.full_name} is no longer an admin"
        
        if success:
            await socket_manager.sio.emit('admin_removed', {
                'group_id': group_id,
                'user_name': target_user.full_name,
                'removed_admin_by': current_user.full_name
            }, room=f"chat_{group_id}")
    
    if not success:
        raise HTTPException(status_code=400, detail="Failed to perform action")
    
    return {"message": action_message}

@app.get("/api/groups/{group_id}/members")
async def get_group_members(group_id: str, current_user: User = Depends(get_current_user)):
    """Get all group members with their roles"""
    # Check if user is member of the group
    chat = await db.get_chat_by_id(group_id)
    if not chat or current_user.id not in chat.participants:
        raise HTTPException(status_code=403, detail="Access denied")
    
    members = await db.get_group_members(group_id)
    members_info = []
    
    for member in members:
        is_admin = await db.is_group_admin(group_id, member.id)
        member_info = {
            "user": UserResponse.from_user(member),
            "is_admin": is_admin,
            "is_creator": member.id == chat.created_by
        }
        members_info.append(member_info)
    
    return {
        "members": members_info,
        "total": len(members_info),
        "group_info": {
            "id": chat.id,
            "name": chat.name,
            "description": chat.description,
            "created_by": chat.created_by,
            "created_at": chat.created_at
        }
    }

@app.post("/api/chats/start", response_model=Chat)
async def start_new_chat(recipient_id: str, current_user: User = Depends(get_current_user)):
    """Start a new private chat with a user"""
    # Verify recipient exists
    recipient = await db.get_user_by_id(recipient_id)
    if not recipient:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Check if private chat already exists
    existing_chat = await db.find_private_chat(current_user.id, recipient_id)
    if existing_chat:
        return existing_chat
    
    # Create new private chat
    new_chat = Chat(
        chat_type="private",
        participants=[current_user.id, recipient_id],
        created_by=current_user.id
    )
    
    created_chat = await db.create_chat(new_chat)
    return created_chat

# Add mention processing to message sending
def process_mentions(message_content: str, chat_participants: List[str]) -> tuple[str, List[str]]:
    """Process @mentions in message content and return mentioned user IDs"""
    import re
    
    # Find all @username patterns
    mention_pattern = r'@(\w+)'
    mentions = re.findall(mention_pattern, message_content)
    mentioned_user_ids = []
    
    for username in mentions:
        # This is a simplified version - in production you'd want to validate usernames
        # For now, we'll just extract the pattern
        pass
    
    return message_content, mentioned_user_ids

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(socket_app, host="0.0.0.0", port=8002, reload=False)