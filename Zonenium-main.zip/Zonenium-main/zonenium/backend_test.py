#!/usr/bin/env python3
"""
Zonenium Backend API Test Suite
Tests voice messaging functionality, authentication, and core messaging APIs
"""

import asyncio
import aiohttp
import json
import base64
import os
import sys
from datetime import datetime
from typing import Dict, Any, Optional

# Test configuration
BASE_URL = "http://localhost:8002"  # Zonenium backend runs on port 8002
API_BASE = f"{BASE_URL}/api"

class ZoneniumAPITester:
    def __init__(self):
        self.session = None
        self.auth_tokens = {}
        self.test_users = {
            "demo_user": {"username": "demo_user", "password": "demo123"},
            "test_user": {"username": "test_user", "password": "test123"}
        }
        self.test_results = []
        self.created_chats = []
        self.created_messages = []

    async def setup_session(self):
        """Initialize HTTP session"""
        self.session = aiohttp.ClientSession()

    async def cleanup_session(self):
        """Close HTTP session"""
        if self.session:
            await self.session.close()

    def log_test(self, test_name: str, success: bool, details: str = ""):
        """Log test result"""
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} {test_name}")
        if details:
            print(f"    {details}")
        
        self.test_results.append({
            "test": test_name,
            "success": success,
            "details": details,
            "timestamp": datetime.now().isoformat()
        })

    async def make_file_upload_request(self, endpoint: str, params: dict, headers: dict) -> tuple[bool, Any]:
        """Make file upload request with query parameters"""
        try:
            url = f"{API_BASE}{endpoint}"
            query_string = "&".join([f"{k}={v}" for k, v in params.items()])
            full_url = f"{url}?{query_string}"
            
            async with self.session.post(full_url, headers=headers) as response:
                success = response.status < 400
                response_data = await response.json()
                return success, response_data
        except Exception as e:
            return False, {"error": str(e)}

    async def make_request(self, method: str, endpoint: str, data: Any = None, 
                          headers: Dict[str, str] = None, files: Any = None, as_form: bool = False) -> tuple[bool, Any]:
        """Make HTTP request and return success status and response data"""
        try:
            url = f"{API_BASE}{endpoint}"
            request_headers = headers or {}
            
            if method.upper() == "GET":
                async with self.session.get(url, headers=request_headers, params=data) as response:
                    response_data = await response.json()
                    return response.status < 400, response_data
            elif method.upper() == "POST":
                if files:
                    # Handle file upload
                    form_data = aiohttp.FormData()
                    for key, value in (data or {}).items():
                        form_data.add_field(key, str(value))
                    if files:
                        for file_key, file_data in files.items():
                            form_data.add_field(file_key, file_data[1], filename=file_data[0])
                    
                    async with self.session.post(url, data=form_data, headers=request_headers) as response:
                        response_data = await response.json()
                        return response.status < 400, response_data
                elif as_form:
                    # Send as form data
                    form_data = aiohttp.FormData()
                    for key, value in (data or {}).items():
                        form_data.add_field(key, str(value))
                    
                    async with self.session.post(url, data=form_data, headers=request_headers) as response:
                        response_data = await response.json()
                        return response.status < 400, response_data
                else:
                    async with self.session.post(url, json=data, headers=request_headers) as response:
                        response_data = await response.json()
                        return response.status < 400, response_data
            elif method.upper() == "PUT":
                async with self.session.put(url, json=data, headers=request_headers) as response:
                    response_data = await response.json()
                    return response.status < 400, response_data
            else:
                return False, {"error": f"Unsupported method: {method}"}
                
        except Exception as e:
            return False, {"error": str(e)}

    async def test_health_check(self):
        """Test API health check endpoint"""
        success, response = await self.make_request("GET", "/status")
        
        if success and response.get("status") == "ok":
            self.log_test("Health Check", True, "API is running and responsive")
        else:
            self.log_test("Health Check", False, f"API health check failed: {response}")

    async def test_user_authentication(self):
        """Test user login with demo accounts"""
        for user_key, credentials in self.test_users.items():
            success, response = await self.make_request("POST", "/auth/login", credentials)
            
            if success and "access_token" in response:
                self.auth_tokens[user_key] = response["access_token"]
                self.log_test(f"Login {user_key}", True, f"Successfully logged in as {credentials['username']}")
            else:
                self.log_test(f"Login {user_key}", False, f"Login failed: {response}")

    async def test_get_current_user(self):
        """Test getting current user information"""
        for user_key, token in self.auth_tokens.items():
            headers = {"Authorization": f"Bearer {token}"}
            success, response = await self.make_request("GET", "/auth/me", headers=headers)
            
            if success and "username" in response:
                expected_username = self.test_users[user_key]["username"]
                if response["username"] == expected_username:
                    self.log_test(f"Get Current User {user_key}", True, f"Retrieved user info for {response['username']}")
                else:
                    self.log_test(f"Get Current User {user_key}", False, f"Username mismatch: expected {expected_username}, got {response['username']}")
            else:
                self.log_test(f"Get Current User {user_key}", False, f"Failed to get user info: {response}")

    async def test_user_search(self):
        """Test user search functionality"""
        if not self.auth_tokens:
            self.log_test("User Search", False, "No authentication tokens available")
            return

        # Use demo_user token to search for test_user
        headers = {"Authorization": f"Bearer {self.auth_tokens['demo_user']}"}
        success, response = await self.make_request("GET", "/users/search", {"query": "test"}, headers)
        
        if success and "users" in response:
            users = response["users"]
            if len(users) > 0 and any(user["username"] == "test_user" for user in users):
                self.log_test("User Search", True, f"Found {len(users)} users matching 'test'")
            else:
                self.log_test("User Search", False, f"Expected to find test_user, got: {users}")
        else:
            self.log_test("User Search", False, f"User search failed: {response}")

    async def test_chat_creation(self):
        """Test creating a new chat between users"""
        if len(self.auth_tokens) < 2:
            self.log_test("Chat Creation", False, "Need at least 2 authenticated users")
            return

        # Get user IDs first
        demo_headers = {"Authorization": f"Bearer {self.auth_tokens['demo_user']}"}
        test_headers = {"Authorization": f"Bearer {self.auth_tokens['test_user']}"}
        
        # Get demo_user info
        success, demo_user = await self.make_request("GET", "/auth/me", headers=demo_headers)
        if not success:
            self.log_test("Chat Creation", False, "Failed to get demo_user info")
            return
            
        # Get test_user info  
        success, test_user = await self.make_request("GET", "/auth/me", headers=test_headers)
        if not success:
            self.log_test("Chat Creation", False, "Failed to get test_user info")
            return

        # Start chat from demo_user to test_user
        success, response = await self.make_request("POST", f"/chats/start?recipient_id={test_user['id']}", headers=demo_headers)
        
        if success and ("id" in response or "_id" in response):
            chat_id = response.get("id") or response.get("_id")
            self.created_chats.append(chat_id)
            self.log_test("Chat Creation", True, f"Created chat {chat_id} between {demo_user['username']} and {test_user['username']}")
        else:
            self.log_test("Chat Creation", False, f"Chat creation failed: {response}")

    async def test_text_messaging(self):
        """Test sending text messages"""
        if not self.created_chats or len(self.auth_tokens) < 2:
            self.log_test("Text Messaging", False, "No chats available or insufficient users")
            return

        # Get user IDs
        demo_headers = {"Authorization": f"Bearer {self.auth_tokens['demo_user']}"}
        test_headers = {"Authorization": f"Bearer {self.auth_tokens['test_user']}"}
        
        success, test_user = await self.make_request("GET", "/auth/me", headers=test_headers)
        if not success:
            self.log_test("Text Messaging", False, "Failed to get test_user info")
            return

        # Send message from demo_user to test_user
        message_data = {
            "content": "Hello from demo_user! This is a test message.",
            "recipient_id": test_user["id"],
            "chat_id": self.created_chats[0],
            "message_type": "text"
        }
        
        success, response = await self.make_request("POST", "/messages", message_data, demo_headers)
        
        if success and ("id" in response or "_id" in response):
            message_id = response.get("id") or response.get("_id")
            self.created_messages.append(message_id)
            self.log_test("Text Messaging", True, f"Sent text message {message_id}")
        else:
            self.log_test("Text Messaging", False, f"Text message failed: {response}")

    async def test_voice_message_file_upload(self):
        """Test voice message functionality with file upload"""
        if not self.created_chats or len(self.auth_tokens) < 2:
            self.log_test("Voice Message Upload", False, "No chats available or insufficient users")
            return

        # Get user IDs
        demo_headers = {"Authorization": f"Bearer {self.auth_tokens['demo_user']}"}
        test_headers = {"Authorization": f"Bearer {self.auth_tokens['test_user']}"}
        
        success, test_user = await self.make_request("GET", "/auth/me", headers=test_headers)
        if not success:
            self.log_test("Voice Message Upload", False, "Failed to get test_user info")
            return

        # Create a mock audio file (webm format)
        mock_audio_data = b"WEBM\x00\x00\x00\x00" + b"mock_audio_data" * 100  # Mock WebM header + data
        audio_base64 = base64.b64encode(mock_audio_data).decode('utf-8')
        
        # Test voice message via file endpoint - send as query parameters
        query_params = {
            "recipient_id": test_user["id"],
            "file_data": audio_base64,
            "file_name": "test_voice_message.webm",
            "file_type": "audio/webm",
            "file_size": len(mock_audio_data),
            "chat_id": self.created_chats[0],
            "duration": 15  # 15 seconds duration
        }
        
        success, response_data = await self.make_file_upload_request("/messages/file", query_params, demo_headers)
        
        if success and ("id" in response_data or "_id" in response_data):
            message_id = response_data.get("id") or response_data.get("_id")
            message_type = response_data.get("message_type")
            
            if message_type == "voice":
                self.created_messages.append(message_id)
                self.log_test("Voice Message Upload", True, f"Successfully uploaded voice message {message_id} with type '{message_type}'")
            else:
                self.log_test("Voice Message Upload", False, f"Expected message_type 'voice', got '{message_type}'")
        else:
            self.log_test("Voice Message Upload", False, f"Voice message upload failed: {response_data}")

    async def test_audio_file_type_detection(self):
        """Test different audio file types are detected as voice messages"""
        if not self.created_chats or len(self.auth_tokens) < 2:
            self.log_test("Audio File Type Detection", False, "No chats available or insufficient users")
            return

        demo_headers = {"Authorization": f"Bearer {self.auth_tokens['demo_user']}"}
        success, test_user = await self.make_request("GET", "/auth/me", headers={"Authorization": f"Bearer {self.auth_tokens['test_user']}"})
        
        if not success:
            self.log_test("Audio File Type Detection", False, "Failed to get test_user info")
            return

        # Test different audio formats
        audio_formats = [
            ("test_audio.mp3", "audio/mp3"),
            ("test_audio.wav", "audio/wav"),
            ("test_audio.ogg", "audio/ogg"),
            ("test_audio.m4a", "audio/m4a")
        ]
        
        passed_tests = 0
        total_tests = len(audio_formats)
        
        for filename, content_type in audio_formats:
            mock_audio_data = b"AUDIO_HEADER" + b"mock_data" * 50
            audio_base64 = base64.b64encode(mock_audio_data).decode('utf-8')
            
            file_data = {
                "recipient_id": test_user["id"],
                "file_data": audio_base64,
                "file_name": filename,
                "file_type": content_type,
                "file_size": len(mock_audio_data),
                "chat_id": self.created_chats[0],
                "duration": 10
            }
            
            success, response = await self.make_file_upload_request("/messages/file", file_data, demo_headers)
            
            if success and response.get("message_type") == "voice":
                passed_tests += 1
                print(f"    ✅ {filename} ({content_type}) detected as voice message")
            else:
                print(f"    ❌ {filename} ({content_type}) failed: {response}")

        if passed_tests == total_tests:
            self.log_test("Audio File Type Detection", True, f"All {total_tests} audio formats correctly detected as voice messages")
        else:
            self.log_test("Audio File Type Detection", False, f"Only {passed_tests}/{total_tests} audio formats detected correctly")

    async def test_image_file_type_detection(self):
        """Test image files are detected correctly"""
        if not self.created_chats or len(self.auth_tokens) < 2:
            self.log_test("Image File Type Detection", False, "No chats available or insufficient users")
            return

        demo_headers = {"Authorization": f"Bearer {self.auth_tokens['demo_user']}"}
        success, test_user = await self.make_request("GET", "/auth/me", headers={"Authorization": f"Bearer {self.auth_tokens['test_user']}"})
        
        if not success:
            self.log_test("Image File Type Detection", False, "Failed to get test_user info")
            return

        # Test image file
        mock_image_data = b"PNG\x00\x00\x00\x00" + b"mock_image_data" * 50
        image_base64 = base64.b64encode(mock_image_data).decode('utf-8')
        
        file_data = {
            "recipient_id": test_user["id"],
            "file_data": image_base64,
            "file_name": "test_image.png",
            "file_type": "image/png",
            "file_size": len(mock_image_data),
            "chat_id": self.created_chats[0]
        }
        
        success, response = await self.make_file_upload_request("/messages/file", file_data, demo_headers)
        
        if success and response.get("message_type") == "image":
            self.log_test("Image File Type Detection", True, f"Image file correctly detected as 'image' message type")
        else:
            self.log_test("Image File Type Detection", False, f"Image detection failed: {response}")

    async def test_regular_file_type_detection(self):
        """Test regular files are detected correctly"""
        if not self.created_chats or len(self.auth_tokens) < 2:
            self.log_test("Regular File Type Detection", False, "No chats available or insufficient users")
            return

        demo_headers = {"Authorization": f"Bearer {self.auth_tokens['demo_user']}"}
        success, test_user = await self.make_request("GET", "/auth/me", headers={"Authorization": f"Bearer {self.auth_tokens['test_user']}"})
        
        if not success:
            self.log_test("Regular File Type Detection", False, "Failed to get test_user info")
            return

        # Test regular file
        mock_file_data = b"PDF-1.4\n" + b"mock_pdf_content" * 100
        file_base64 = base64.b64encode(mock_file_data).decode('utf-8')
        
        file_data = {
            "recipient_id": test_user["id"],
            "file_data": file_base64,
            "file_name": "test_document.pdf",
            "file_type": "application/pdf",
            "file_size": len(mock_file_data),
            "chat_id": self.created_chats[0]
        }
        
        success, response = await self.make_file_upload_request("/messages/file", file_data, demo_headers)
        
        if success and response.get("message_type") == "file":
            self.log_test("Regular File Type Detection", True, f"Regular file correctly detected as 'file' message type")
        else:
            self.log_test("Regular File Type Detection", False, f"Regular file detection failed: {response}")

    async def test_chat_message_retrieval(self):
        """Test retrieving messages from a chat"""
        if not self.created_chats:
            self.log_test("Chat Message Retrieval", False, "No chats available")
            return

        demo_headers = {"Authorization": f"Bearer {self.auth_tokens['demo_user']}"}
        chat_id = self.created_chats[0]
        
        success, response = await self.make_request("GET", f"/chats/{chat_id}/messages", headers=demo_headers)
        
        if success and "messages" in response:
            messages = response["messages"]
            voice_messages = [msg for msg in messages if msg.get("message_type") == "voice"]
            text_messages = [msg for msg in messages if msg.get("message_type") == "text"]
            
            self.log_test("Chat Message Retrieval", True, 
                         f"Retrieved {len(messages)} messages ({len(text_messages)} text, {len(voice_messages)} voice)")
        else:
            self.log_test("Chat Message Retrieval", False, f"Message retrieval failed: {response}")

    async def test_user_chats_list(self):
        """Test getting user's chat list"""
        demo_headers = {"Authorization": f"Bearer {self.auth_tokens['demo_user']}"}
        
        success, response = await self.make_request("GET", "/chats", headers=demo_headers)
        
        if success and "chats" in response:
            chats = response["chats"]
            self.log_test("User Chats List", True, f"Retrieved {len(chats)} chats for demo_user")
        else:
            self.log_test("User Chats List", False, f"Chat list retrieval failed: {response}")

    async def run_all_tests(self):
        """Run all backend tests"""
        print("🚀 Starting Zonenium Backend API Tests")
        print("=" * 50)
        
        await self.setup_session()
        
        try:
            # Core API tests
            await self.test_health_check()
            await self.test_user_authentication()
            await self.test_get_current_user()
            await self.test_user_search()
            
            # Chat and messaging tests
            await self.test_chat_creation()
            await self.test_text_messaging()
            
            # Voice messaging tests (main focus)
            await self.test_voice_message_file_upload()
            await self.test_audio_file_type_detection()
            await self.test_image_file_type_detection()
            await self.test_regular_file_type_detection()
            
            # Message retrieval tests
            await self.test_chat_message_retrieval()
            await self.test_user_chats_list()
            
        finally:
            await self.cleanup_session()

    def print_summary(self):
        """Print test summary"""
        print("\n" + "=" * 50)
        print("📊 TEST SUMMARY")
        print("=" * 50)
        
        passed = sum(1 for result in self.test_results if result["success"])
        total = len(self.test_results)
        success_rate = (passed / total * 100) if total > 0 else 0
        
        print(f"Total Tests: {total}")
        print(f"Passed: {passed}")
        print(f"Failed: {total - passed}")
        print(f"Success Rate: {success_rate:.1f}%")
        
        if total - passed > 0:
            print("\n❌ FAILED TESTS:")
            for result in self.test_results:
                if not result["success"]:
                    print(f"  • {result['test']}: {result['details']}")
        
        print("\n🎯 VOICE MESSAGING TESTS:")
        voice_tests = [r for r in self.test_results if "voice" in r["test"].lower() or "audio" in r["test"].lower() or "file type" in r["test"].lower()]
        voice_passed = sum(1 for r in voice_tests if r["success"])
        print(f"Voice/Audio Tests: {voice_passed}/{len(voice_tests)} passed")
        
        return success_rate >= 80  # Consider 80%+ success rate as good

async def main():
    """Main test runner"""
    tester = ZoneniumAPITester()
    
    try:
        await tester.run_all_tests()
        success = tester.print_summary()
        
        # Exit with appropriate code
        sys.exit(0 if success else 1)
        
    except Exception as e:
        print(f"❌ Test execution failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main())