# 🌟 **Create Your AfroBelleza Website - 3 Simple Files**

## 📁 **FILE 1: index.html** (Main website file)

**Create this file and save as "index.html":**

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AfroBelleza - Luxury Hair & Nails Salon</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { font-family: 'Inter', sans-serif; }
        .hero-bg { background: linear-gradient(135deg, #ff8c19 0%, #fa551e 100%); }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <div class="flex-shrink-0 flex items-center">
                    <img src="logo.png" alt="AfroBelleza Logo" class="w-20 h-20 object-contain mr-4">
                    <h1 class="text-3xl font-bold text-gray-900">
                        Afro<span class="text-orange-500">Belleza</span>
                    </h1>
                </div>
                <nav class="hidden md:flex items-center space-x-8">
                    <a href="#home" class="text-gray-700 hover:text-orange-500 font-medium">Home</a>
                    <a href="#services" class="text-gray-700 hover:text-orange-500 font-medium">Services</a>
                    <a href="#about" class="text-gray-700 hover:text-orange-500 font-medium">About</a>
                    <a href="#contact" class="text-gray-700 hover:text-orange-500 font-medium">Contact</a>
                </nav>
                <a href="#booking" class="px-6 py-2 bg-orange-500 text-white rounded-lg font-medium hover:bg-orange-600">Book Now</a>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section id="home" class="hero-bg min-h-screen flex items-center pt-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
            <h1 class="text-6xl md:text-8xl font-bold mb-4">AfroBelleza</h1>
            <h2 class="text-2xl md:text-3xl mb-6">Luxury Hair & Nails Salon</h2>
            <p class="text-lg mb-8 max-w-3xl mx-auto">Celebrating Afro heritage with premium hair braiding and nail services. Experience elegance, tradition, and modern luxury.</p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="#booking" class="px-8 py-4 bg-white text-orange-600 font-semibold rounded-full hover:bg-gray-100">Book Now</a>
                <a href="#services" class="px-8 py-4 border-2 border-white text-white font-semibold rounded-full hover:bg-white hover:text-orange-600">Our Services</a>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="py-16 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12">
                <h2 class="text-4xl font-bold text-gray-900 mb-4">Our Services</h2>
                <div class="w-24 h-1 bg-gradient-to-r from-orange-400 to-red-400 mx-auto"></div>
            </div>
            
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                <!-- Service 1: Braid Women -->
                <div class="bg-white rounded-2xl shadow-lg p-6">
                    <div class="h-48 bg-gradient-to-br from-orange-100 to-red-100 rounded-xl mb-6 flex items-center justify-center">
                        <span class="text-4xl">💇‍♀️</span>
                    </div>
                    <h3 class="text-xl font-bold mb-3">Braid Women</h3>
                    <p class="text-gray-600 mb-4">Elegant braiding styles for women</p>
                    <div class="flex justify-between items-center">
                        <span class="text-2xl font-bold text-orange-600">120 pesos</span>
                        <span class="text-sm text-gray-500">3-4 hours</span>
                    </div>
                </div>

                <!-- Service 2: Braid Male -->
                <div class="bg-white rounded-2xl shadow-lg p-6">
                    <div class="h-48 bg-gradient-to-br from-orange-100 to-red-100 rounded-xl mb-6 flex items-center justify-center">
                        <span class="text-4xl">💇‍♂️</span>
                    </div>
                    <h3 class="text-xl font-bold mb-3">Braid Male</h3>
                    <p class="text-gray-600 mb-4">Professional braiding for men</p>
                    <div class="flex justify-between items-center">
                        <span class="text-2xl font-bold text-orange-600">85 pesos</span>
                        <span class="text-sm text-gray-500">2-3 hours</span>
                    </div>
                </div>

                <!-- Service 3: Braid Kids -->
                <div class="bg-white rounded-2xl shadow-lg p-6">
                    <div class="h-48 bg-gradient-to-br from-orange-100 to-red-100 rounded-xl mb-6 flex items-center justify-center">
                        <span class="text-4xl">👶</span>
                    </div>
                    <h3 class="text-xl font-bold mb-3">Braid Kids</h3>
                    <p class="text-gray-600 mb-4">Fun protective braids for children</p>
                    <div class="flex justify-between items-center">
                        <span class="text-2xl font-bold text-orange-600">65 pesos</span>
                        <span class="text-sm text-gray-500">1-2 hours</span>
                    </div>
                </div>

                <!-- Service 4: Twist -->
                <div class="bg-white rounded-2xl shadow-lg p-6">
                    <div class="h-48 bg-gradient-to-br from-orange-100 to-red-100 rounded-xl mb-6 flex items-center justify-center">
                        <span class="text-4xl">🌀</span>
                    </div>
                    <h3 class="text-xl font-bold mb-3">Twist</h3>
                    <p class="text-gray-600 mb-4">Modern twist hairstyles</p>
                    <div class="flex justify-between items-center">
                        <span class="text-2xl font-bold text-orange-600">95 pesos</span>
                        <span class="text-sm text-gray-500">2-3 hours</span>
                    </div>
                </div>

                <!-- Service 5: Manicure -->
                <div class="bg-white rounded-2xl shadow-lg p-6">
                    <div class="h-48 bg-gradient-to-br from-orange-100 to-red-100 rounded-xl mb-6 flex items-center justify-center">
                        <span class="text-4xl">💅</span>
                    </div>
                    <h3 class="text-xl font-bold mb-3">Manicure (Simple)</h3>
                    <p class="text-gray-600 mb-4">Professional nail care and design</p>
                    <div class="flex justify-between items-center">
                        <span class="text-2xl font-bold text-orange-600">200 pesos</span>
                        <span class="text-sm text-gray-500">1 hour</span>
                    </div>
                </div>

                <!-- Service 6: Pedicure -->
                <div class="bg-white rounded-2xl shadow-lg p-6">
                    <div class="h-48 bg-gradient-to-br from-orange-100 to-red-100 rounded-xl mb-6 flex items-center justify-center">
                        <span class="text-4xl">🦶</span>
                    </div>
                    <h3 class="text-xl font-bold mb-3">Pedicure (Simple)</h3>
                    <p class="text-gray-600 mb-4">Relaxing foot care treatment</p>
                    <div class="flex justify-between items-center">
                        <span class="text-2xl font-bold text-orange-600">200 pesos</span>
                        <span class="text-sm text-gray-500">1.5 hours</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="py-16 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12">
                <h2 class="text-4xl font-bold text-gray-900 mb-4">Contact Us</h2>
                <div class="w-24 h-1 bg-gradient-to-r from-orange-400 to-red-400 mx-auto"></div>
            </div>

            <div class="grid lg:grid-cols-2 gap-12">
                <div class="space-y-8">
                    <div class="flex items-start space-x-4">
                        <div class="bg-green-100 rounded-full p-3">📱</div>
                        <div>
                            <h4 class="font-semibold text-gray-900 mb-1">WhatsApp</h4>
                            <a href="https://wa.me/5296244704847" class="text-gray-600 hover:text-green-600">+52 962-447-0847</a>
                        </div>
                    </div>

                    <div class="flex items-start space-x-4">
                        <div class="bg-red-100 rounded-full p-3">📞</div>
                        <div>
                            <h4 class="font-semibold text-gray-900 mb-1">Phone</h4>
                            <p class="text-gray-600">+52 962 447 0847</p>
                        </div>
                    </div>

                    <div class="flex items-start space-x-4">
                        <div class="bg-pink-100 rounded-full p-3">✉️</div>
                        <div>
                            <h4 class="font-semibold text-gray-900 mb-1">Email</h4>
                            <p class="text-gray-600">afrobelleza@qualityservice.com</p>
                        </div>
                    </div>

                    <div class="flex items-start space-x-4">
                        <div class="bg-yellow-100 rounded-full p-3">📍</div>
                        <div>
                            <h4 class="font-semibold text-gray-900 mb-1">Address</h4>
                            <p class="text-gray-600">San Augustín SN, Los Naranjos, Las Palmeras, Chis, 30785. Casa amarilla, reja café. Frente al kinder Rosario Roldan.</p>
                        </div>
                    </div>

                    <!-- Social Media -->
                    <div>
                        <h3 class="text-2xl font-bold text-gray-900 mb-6">Follow Us</h3>
                        <div class="grid grid-cols-2 gap-4">
                            <a href="https://instagram.com/Afrobelleza7" class="flex items-center space-x-3 p-4 bg-gradient-to-r from-pink-100 to-purple-100 rounded-xl hover:from-pink-200 hover:to-purple-200">
                                <span class="text-2xl">📷</span>
                                <div>
                                    <p class="font-semibold">Instagram</p>
                                    <p class="text-sm text-gray-600">@Afrobelleza7</p>
                                </div>
                            </a>
                            <a href="https://facebook.com/AfroBelleza" class="flex items-center space-x-3 p-4 bg-blue-100 rounded-xl hover:bg-blue-200">
                                <span class="text-2xl">👥</span>
                                <div>
                                    <p class="font-semibold">Facebook</p>
                                    <p class="text-sm text-gray-600">@AfroBelleza</p>
                                </div>
                            </a>
                            <a href="https://tiktok.com/@AfroBelleza" class="flex items-center space-x-3 p-4 bg-gray-100 rounded-xl hover:bg-gray-200">
                                <span class="text-2xl">🎵</span>
                                <div>
                                    <p class="font-semibold">TikTok</p>
                                    <p class="text-sm text-gray-600">@AfroBelleza</p>
                                </div>
                            </a>
                            <a href="https://wa.me/5296244704847" class="flex items-center space-x-3 p-4 bg-green-100 rounded-xl hover:bg-green-200">
                                <span class="text-2xl">💬</span>
                                <div>
                                    <p class="font-semibold">WhatsApp</p>
                                    <p class="text-sm text-gray-600">+52 962-447-0847</p>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Booking Form -->
                <div id="booking" class="bg-gradient-to-br from-gray-50 to-orange-50 rounded-2xl p-8">
                    <h3 class="text-2xl font-bold text-gray-900 mb-6">Book Appointment</h3>
                    <form class="space-y-6">
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-3">Service *</label>
                            <select class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500">
                                <option>Choose a service...</option>
                                <option>Braid Women - 120 pesos (3-4 hours)</option>
                                <option>Braid Male - 85 pesos (2-3 hours)</option>
                                <option>Braid Kids - 65 pesos (1-2 hours)</option>
                                <option>Twist - 95 pesos (2-3 hours)</option>
                                <option>Manicure (Simple) - 200 pesos (1 hour)</option>
                                <option>Pedicure (Simple) - 200 pesos (1.5 hours)</option>
                            </select>
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-3">Full Name *</label>
                            <input type="text" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500" placeholder="Your full name">
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-3">Phone *</label>
                            <input type="tel" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500" placeholder="Your phone number">
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-3">Email *</label>
                            <input type="email" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500" placeholder="your.email@example.com">
                        </div>

                        <button type="submit" class="w-full px-8 py-4 bg-gradient-to-r from-orange-500 to-red-500 text-white font-bold rounded-xl hover:from-orange-600 hover:to-red-600">
                            Book Appointment
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center">
                <div class="mb-6 flex items-center justify-center">
                    <img src="logo.png" alt="AfroBelleza Logo" class="w-24 h-24 object-contain mr-6">
                    <div>
                        <h3 class="text-3xl font-bold mb-3">Afro<span class="text-orange-500">Belleza</span></h3>
                        <p class="text-gray-400">Celebrating Afro heritage with premium hair braiding and nail services.</p>
                    </div>
                </div>
                
                <div class="border-t border-gray-800 pt-6">
                    <p class="text-gray-400">© 2024 AfroBelleza. All rights reserved.</p>
                </div>
            </div>
        </div>
    </footer>

    <script>
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });
    </script>
</body>
</html>
```

---

## 🚀 **HOW TO UPLOAD TO NETLIFY:**

1. **Copy the HTML code above** and save as "index.html"
2. **Add your logo image** - save as "logo.png" in same folder
3. **Go to**: https://app.netlify.com/drop
4. **Drag both files** (index.html + logo.png) to upload area
5. **Website goes LIVE instantly!** 🎉

## 📱 **Your Logo:**
- **Download your logo** from the server
- **Save as "logo.png"**
- **Upload with the HTML file**

**This gives you a beautiful, working AfroBelleza website with all your info!** ✨