# 🌟 AfroBelleza Website - Easy Editing Guide

## 📱 Quick Changes You Can Make Anytime

### 🔥 CHANGE PRICES INSTANTLY

**File to Edit**: `/app/backend/database.py`
**Lines to Change**: 200-290

```python
# Find these lines and change the price numbers:
"price": 200,  # ← Manicure price (currently 200 pesos)
"price": 200,  # ← Pedicure price (currently 200 pesos)
"price": 85,   # ← Braid Male price
"price": 120,  # ← Braid Women price
"price": 65,   # ← Braid Kids price
"price": 95,   # ← Twist price
```

**After changing prices, run**: `sudo supervisorctl restart backend`

---

### 📞 CHANGE CONTACT INFORMATION

**File to Edit**: `/app/frontend/src/components/Contact.js`
**Lines to Change**: 8-25

```javascript
// Change these values:
phone: "+52 962 447 0847",                    // ← Your phone
whatsapp: "+52 962-447-0847",                // ← Your WhatsApp  
email: "afrobelleza@qualityservice.com",     // ← Your email
address: "Your new address here...",          // ← Your address

// Social Media
instagram: "Afrobelleza7",                    // ← Your Instagram
facebook: "@AfroBelleza",                     // ← Your Facebook  
tiktok: "AfroBelleza",                       // ← Your TikTok
```

**After changing contact info, run**: `sudo supervisorctl restart frontend`

---

### 🎨 CHANGE WEBSITE TEXT/CONTENT

**Files to Edit**:
1. **Homepage Hero**: `/app/frontend/src/mock.js` (lines 10-20)
2. **Service Names**: `/app/backend/database.py` (lines 200-290)
3. **About Section**: `/app/frontend/src/components/About.js`

---

## 🚀 STEP-BY-STEP: How to Change Prices

1. **Open file**: `/app/backend/database.py`
2. **Find line ~260**: Look for "Manicure" section
3. **Change**: `"price": 200,` to your new price
4. **Find line ~280**: Look for "Pedicure" section  
5. **Change**: `"price": 200,` to your new price
6. **Save file**
7. **Run command**: `sudo supervisorctl restart backend`
8. **Done!** ✅ New prices are live

---

## 🚀 STEP-BY-STEP: How to Change Contact Info

1. **Open file**: `/app/frontend/src/components/Contact.js`
2. **Find line ~8**: Look for `contactInfo = {`
3. **Change your info**:
   - Phone number
   - Email address  
   - Physical address
   - Social media handles
4. **Save file**
5. **Run command**: `sudo supervisorctl restart frontend`
6. **Done!** ✅ New contact info is live

---

## 🔄 RESTART COMMANDS

**Restart Backend** (after price changes):
```bash
sudo supervisorctl restart backend
```

**Restart Frontend** (after contact/design changes):
```bash
sudo supervisorctl restart frontend
```

**Restart Everything**:
```bash
sudo supervisorctl restart all
```

---

## 📱 YOUR CURRENT SOCIAL MEDIA LINKS

✅ **Instagram**: https://instagram.com/Afrobelleza7
✅ **Facebook**: https://facebook.com/AfroBelleza  
✅ **TikTok**: https://tiktok.com/@AfroBelleza
✅ **WhatsApp**: https://wa.me/5296244704847

---

## 💡 TIPS

- **Always save files** after making changes
- **Always restart** the appropriate service after changes
- **Test your website** after making changes  
- **Keep backups** of your original files

---

## ❓ NEED HELP?

If you get stuck:
1. Check if you saved the file
2. Check if you restarted the service  
3. Check the website at: http://localhost:3000

**Your website is at**: http://localhost:3000 🌟