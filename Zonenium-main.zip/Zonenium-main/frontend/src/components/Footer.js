import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { MapPin, Phone, Mail, Clock, Instagram, Facebook, Twitter, Scissors, Sparkles, Star } from 'lucide-react';

// Real AfroBelleza contact information and social media
const contactInfo = {
  phone: "+52 962 447 0847",
  whatsapp: "+52 962-447-0847",
  email: "afrobelleza@qualityservice.com",
  address: "San Augustín SN, Los Naranjos, Las Palmeras, Chis, 30785. Casa amarilla, reja café. Frente al kinder Rosario Roldan.",
  hours: {
    en: "Mon-Sat: 9AM-7PM, Sun: 10AM-5PM",
    fr: "Lun-Sam: 9h-19h, Dim: 10h-17h", 
    es: "Lun-Sáb: 9AM-7PM, Dom: 10AM-5PM"
  },
  social: {
    instagram: "Afrobelleza7",
    facebook: "@AfroBelleza", 
    tiktok: "AfroBelleza",
    whatsappLink: "https://wa.me/5296244704847"
  }
};

const Footer = () => {
  const { t, currentLanguage, changeLanguage, languages } = useLanguage();

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const socialLinks = [
    { 
      icon: Instagram, 
      href: `https://instagram.com/${contactInfo.social.instagram}`, 
      name: 'Instagram',
      handle: `@${contactInfo.social.instagram}`
    },
    { 
      icon: Facebook, 
      href: `https://facebook.com/${contactInfo.social.facebook.replace('@', '')}`, 
      name: 'Facebook',
      handle: contactInfo.social.facebook
    },
    { 
      icon: Twitter, 
      href: `https://tiktok.com/@${contactInfo.social.tiktok}`, 
      name: 'TikTok',
      handle: `@${contactInfo.social.tiktok}`
    }
  ];

  const quickLinks = [
    { key: 'home', section: 'home' },
    { key: 'services', section: 'services' },
    { key: 'about', section: 'about' },
    { key: 'gallery', section: 'gallery' },
    { key: 'testimonials', section: 'testimonials' },
    { key: 'contact', section: 'contact' }
  ];

  return (
    <footer className="bg-gray-900 text-white">
      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand & About */}
          <div className="lg:col-span-1">
            <div className="mb-6 flex items-center">
              {/* Logo */}
              <img 
                src="/images/afrobelleza-logo.png" 
                alt="AfroBelleza Logo" 
                className="w-24 h-24 object-contain mr-6"
              />
              <div>
                <h3 className="text-3xl font-bold mb-3">
                  Afro<span className="text-orange-500">Belleza</span>
                </h3>
                <p className="text-gray-400 leading-relaxed mb-4">
                  {currentLanguage === 'en' && 'Celebrating Afro heritage with premium hair braiding and nail services. Experience elegance, tradition, and modern luxury.'}
                  {currentLanguage === 'fr' && 'Célébrant l\'héritage afro avec des services de tressage et d\'ongles premium. Découvrez l\'élégance, la tradition et le luxe moderne.'}
                  {currentLanguage === 'es' && 'Celebrando la herencia afro con servicios premium de trenzado y uñas. Experimenta elegancia, tradición y lujo moderno.'}
                </p>
                <div className="flex space-x-4">
                  {socialLinks.map((social, index) => (
                    <div key={index} className="text-center">
                      <a
                        href={social.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-gray-800 hover:bg-orange-500 p-3 rounded-full transition-colors block mb-2"
                        aria-label={social.name}
                      >
                        <social.icon className="w-5 h-5" />
                      </a>
                      <span className="text-xs text-gray-400">{social.handle}</span>
                    </div>
                  ))}
                  <div className="text-center">
                    <a
                      href={contactInfo.social.whatsappLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-green-600 hover:bg-green-700 p-3 rounded-full transition-colors block mb-2"
                      aria-label="WhatsApp"
                    >
                      <Phone className="w-5 h-5" />
                    </a>
                    <span className="text-xs text-gray-400">WhatsApp</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <button
                    onClick={() => scrollToSection(link.section)}
                    className="text-gray-400 hover:text-orange-500 transition-colors"
                  >
                    {t(link.key)}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-semibold mb-6">{t('services')}</h4>
            <ul className="space-y-3 text-gray-400">
              <li className="flex items-center">
                <Scissors className="w-4 h-4 mr-2 text-orange-500" />
                {currentLanguage === 'en' && 'Hair Braiding'}
                {currentLanguage === 'fr' && 'Tressage Cheveux'}
                {currentLanguage === 'es' && 'Trenzado de Cabello'}
              </li>
              <li className="flex items-center">
                <Scissors className="w-4 h-4 mr-2 text-orange-500" />
                {currentLanguage === 'en' && 'Twist Styles'}
                {currentLanguage === 'fr' && 'Styles Torsadés'}
                {currentLanguage === 'es' && 'Estilos de Giros'}
              </li>
              <li className="flex items-center">
                <Sparkles className="w-4 h-4 mr-2 text-red-500" />
                {currentLanguage === 'en' && 'Manicure'}
                {currentLanguage === 'fr' && 'Manucure'}
                {currentLanguage === 'es' && 'Manicura'}
              </li>
              <li className="flex items-center">
                <Sparkles className="w-4 h-4 mr-2 text-red-500" />
                {currentLanguage === 'en' && 'Pedicure'}
                {currentLanguage === 'fr' && 'Pédicure'}
                {currentLanguage === 'es' && 'Pedicura'}
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-6">{t('contactTitle')}</h4>
            <div className="space-y-4 text-gray-400">
              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-orange-500 mt-0.5" />
                <p className="text-sm">{contactInfo.address}</p>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-orange-500" />
                <p className="text-sm">{contactInfo.phone}</p>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-orange-500" />
                <p className="text-sm">{contactInfo.email}</p>
              </div>
              <div className="flex items-start space-x-3">
                <Clock className="w-5 h-5 text-orange-500 mt-0.5" />
                <p className="text-sm">{contactInfo.hours[currentLanguage]}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            {/* Copyright */}
            <div className="text-gray-400 text-sm">
              © 2024 AfroBelleza. {currentLanguage === 'en' && 'All rights reserved.'}
              {currentLanguage === 'fr' && 'Tous droits réservés.'}
              {currentLanguage === 'es' && 'Todos los derechos reservados.'}
            </div>

            {/* Language Selector */}
            <div className="flex items-center space-x-4">
              <span className="text-gray-400 text-sm">Language:</span>
              <div className="flex space-x-2">
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => changeLanguage(lang.code)}
                    className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                      currentLanguage === lang.code
                        ? 'bg-orange-500 text-white'
                        : 'text-gray-400 hover:text-white hover:bg-gray-800'
                    }`}
                  >
                    {lang.flag} {lang.code.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>

            {/* Back to Top */}
            <button
              onClick={() => scrollToSection('home')}
              className="text-gray-400 hover:text-orange-500 transition-colors text-sm font-medium"
            >
              Back to Top ↑
            </button>
          </div>
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute bottom-0 left-0 w-32 h-32 bg-gradient-to-br from-orange-500/10 to-transparent rounded-full -translate-x-16 translate-y-16"></div>
      <div className="absolute bottom-0 right-0 w-24 h-24 bg-gradient-to-bl from-red-500/10 to-transparent rounded-full translate-x-12 translate-y-12"></div>
    </footer>
  );
};

export default Footer;