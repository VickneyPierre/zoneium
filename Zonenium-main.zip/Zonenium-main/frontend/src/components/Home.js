import React, { useEffect, useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { servicesAPI, handleAPIError } from '../services/api';
import { Star, Calendar, Scissors, Sparkles } from 'lucide-react';

const Home = () => {
  const { t, currentLanguage } = useLanguage();
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const response = await servicesAPI.getAll();
        setServices(response.data);
      } catch (error) {
        console.error('Error fetching services:', error);
        // Use empty array if API fails to prevent breaking the page
        setServices([]);
      } finally {
        setLoading(false);
      }
    };
    
    fetchServices();
  }, []);

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const featuredServices = services.slice(0, 3);

  return (
    <div id="home" className="min-h-screen bg-gradient-to-br from-orange-50 via-red-50 to-yellow-50">
      {/* Hero Section */}
      <section className="relative pt-20 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <div className="mb-8">
              <h1 className="text-6xl md:text-8xl font-bold text-gray-900 mb-4">
                {t('heroTitle')}
              </h1>
              <div className="w-24 h-1 bg-gradient-to-r from-orange-400 to-red-400 mx-auto mb-6"></div>
              <h2 className="text-2xl md:text-3xl text-gray-700 font-light mb-6">
                {t('heroSubtitle')}
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto mb-8 leading-relaxed">
                {t('heroDescription')}
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <button
                onClick={() => scrollToSection('booking')}
                className="px-8 py-4 bg-gradient-to-r from-orange-500 to-red-500 text-white font-semibold rounded-full hover:from-orange-600 hover:to-red-600 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
              >
                <Calendar className="inline-block w-5 h-5 mr-2" />
                {t('bookNow')}
              </button>
              <button
                onClick={() => scrollToSection('services')}
                className="px-8 py-4 border-2 border-orange-400 text-orange-600 font-semibold rounded-full hover:bg-orange-50 transition-all duration-300"
              >
                <Sparkles className="inline-block w-5 h-5 mr-2" />
                {t('services')}
              </button>
            </div>
          </div>
        </div>

        {/* Decorative Elements */}
        <div className="absolute top-20 left-10 text-6xl opacity-20 rotate-12">
          <Scissors className="text-orange-400" />
        </div>
        <div className="absolute bottom-20 right-10 text-4xl opacity-20 -rotate-12">
          <Sparkles className="text-red-400" />
        </div>
      </section>

      {/* Featured Services Preview */}
      <section className="py-16 bg-white/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Featured Services</h3>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Experience our most popular hair braiding and nail care services
            </p>
          </div>

          {loading ? (
            <div className="text-center">
              <div className="animate-pulse">
                <div className="grid md:grid-cols-3 gap-8">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="bg-gray-200 rounded-2xl h-80"></div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <>
              <div className="grid md:grid-cols-3 gap-8">
                {featuredServices.map((service) => (
                  <div key={service.id} className="group cursor-pointer" onClick={() => scrollToSection('services')}>
                    <div className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden">
                      <div className="h-48 bg-gradient-to-br from-orange-100 to-red-100 flex items-center justify-center">
                        <div className="text-6xl opacity-30">
                          {service.category === 'nails' ? <Sparkles /> : <Scissors />}
                        </div>
                      </div>
                      <div className="p-6">
                        <h4 className="text-xl font-semibold text-gray-900 mb-2 group-hover:text-orange-600 transition-colors">
                          {service.name[currentLanguage]}
                        </h4>
                        <p className="text-gray-600 mb-4">
                          {service.description[currentLanguage]}
                        </p>
                        <div className="flex justify-between items-center">
                          <span className="text-2xl font-bold text-orange-600">
                            ${service.price} pesos
                          </span>
                          <span className="text-sm text-gray-500">
                            {service.duration}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="text-center mt-12">
                <button
                  onClick={() => scrollToSection('services')}
                  className="px-8 py-3 bg-orange-500 text-white font-semibold rounded-full hover:bg-orange-600 transition-colors"
                >
                  View All Services
                </button>
              </div>
            </>
          )}
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-gradient-to-r from-orange-500 via-red-500 to-pink-500 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold mb-4">Why Choose AfroBelleza?</h3>
            <p className="text-lg opacity-90 max-w-2xl mx-auto">
              Experience the perfect blend of tradition, luxury, and modern techniques
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div className="group">
              <div className="mb-4">
                <Star className="w-12 h-12 mx-auto mb-3 group-hover:scale-110 transition-transform" />
                <h4 className="text-xl font-semibold mb-2">Premium Quality</h4>
                <p className="opacity-90">Only the finest products and techniques</p>
              </div>
            </div>
            <div className="group">
              <div className="mb-4">
                <Scissors className="w-12 h-12 mx-auto mb-3 group-hover:scale-110 transition-transform" />
                <h4 className="text-xl font-semibold mb-2">Expert Stylists</h4>
                <p className="opacity-90">Trained professionals with years of experience</p>
              </div>
            </div>
            <div className="group">
              <div className="mb-4">
                <Sparkles className="w-12 h-12 mx-auto mb-3 group-hover:scale-110 transition-transform" />
                <h4 className="text-xl font-semibold mb-2">Luxury Experience</h4>
                <p className="opacity-90">Pamper yourself in our elegant salon</p>
              </div>
            </div>
            <div className="group">
              <div className="mb-4">
                <Calendar className="w-12 h-12 mx-auto mb-3 group-hover:scale-110 transition-transform" />
                <h4 className="text-xl font-semibold mb-2">Easy Booking</h4>
                <p className="opacity-90">Convenient online appointment scheduling</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;