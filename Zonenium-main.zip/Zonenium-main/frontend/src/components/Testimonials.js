import React, { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { testimonialsAPI, handleAPIError } from '../services/api';
import { Star, ChevronLeft, ChevronRight, Quote, Loader } from 'lucide-react';

const Testimonials = () => {
  const { t, currentLanguage } = useLanguage();
  const [testimonials, setTestimonials] = useState([]);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchTestimonials = async () => {
      try {
        setLoading(true);
        const response = await testimonialsAPI.getAll();
        setTestimonials(response.data);
      } catch (error) {
        console.error('Error fetching testimonials:', error);
        setError(handleAPIError(error, 'Failed to load testimonials'));
        // Use default testimonials if API fails
        setTestimonials([]);
      } finally {
        setLoading(false);
      }
    };
    
    fetchTestimonials();
  }, []);

  // Auto-rotate testimonials
  useEffect(() => {
    if (testimonials.length > 0) {
      const timer = setInterval(() => {
        setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
      }, 5000);
      
      return () => clearInterval(timer);
    }
  }, [testimonials]);

  const nextTestimonial = () => {
    setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentTestimonial((prev) => prev === 0 ? testimonials.length - 1 : prev - 1);
  };

  const goToTestimonial = (index) => {
    setCurrentTestimonial(index);
  };

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-5 h-5 ${
          i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
        }`}
      />
    ));
  };

  return (
    <section id="testimonials" className="py-16 bg-gradient-to-r from-orange-500 via-red-500 to-pink-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">
            {t('testimonialsTitle')}
          </h2>
          <div className="w-24 h-1 bg-white mx-auto"></div>
        </div>

        {loading ? (
          <div className="text-center">
            <Loader className="w-12 h-12 animate-spin text-white mx-auto mb-4" />
            <p className="text-white">Loading testimonials...</p>
          </div>
        ) : error ? (
          <div className="text-center">
            <p className="text-white bg-white/20 rounded-lg p-6 max-w-md mx-auto">
              Unable to load testimonials at this time.
            </p>
          </div>
        ) : testimonials.length === 0 ? (
          <div className="text-center">
            <p className="text-white bg-white/20 rounded-lg p-6 max-w-md mx-auto">
              No testimonials available yet.
            </p>
          </div>
        ) : (
          <>
            {/* Main Testimonial Display */}
            <div className="relative">
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 md:p-12 text-white">
                <div className="relative">
                  {/* Quote Icon */}
                  <Quote className="absolute -top-4 -left-4 w-12 h-12 text-white/20" />
                  
                  {/* Testimonial Content */}
                  <div className="text-center">
                    <div className="flex justify-center mb-6">
                      {renderStars(testimonials[currentTestimonial].rating)}
                    </div>
                    
                    <blockquote className="text-xl md:text-2xl font-light leading-relaxed mb-8 max-w-4xl mx-auto">
                      "{testimonials[currentTestimonial].comment[currentLanguage]}"
                    </blockquote>
                    
                    <div className="flex items-center justify-center space-x-4">
                      <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                        <div className="w-12 h-12 bg-orange-400 rounded-full flex items-center justify-center">
                          <span className="text-white font-bold text-lg">
                            {testimonials[currentTestimonial].name.charAt(0)}
                          </span>
                        </div>
                      </div>
                      <div className="text-left">
                        <h4 className="text-xl font-semibold">
                          {testimonials[currentTestimonial].name}
                        </h4>
                        <p className="text-white/80">
                          {testimonials[currentTestimonial].service}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Navigation Buttons */}
              <button
                onClick={prevTestimonial}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/10 backdrop-blur-sm rounded-full p-3 text-white hover:bg-white/20 transition-colors"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              
              <button
                onClick={nextTestimonial}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/10 backdrop-blur-sm rounded-full p-3 text-white hover:bg-white/20 transition-colors"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>

            {/* Dots Indicator */}
            <div className="flex justify-center space-x-3 mt-8">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToTestimonial(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    index === currentTestimonial 
                      ? 'bg-white scale-125' 
                      : 'bg-white/40 hover:bg-white/60'
                  }`}
                />
              ))}
            </div>

            {/* All Testimonials Grid (Mobile/Tablet) */}
            <div className="mt-16 grid md:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <div
                  key={testimonial.id}
                  className={`bg-white/10 backdrop-blur-md rounded-xl p-6 text-white transition-all duration-300 cursor-pointer ${
                    index === currentTestimonial 
                      ? 'ring-2 ring-white scale-105' 
                      : 'hover:bg-white/20'
                  }`}
                  onClick={() => goToTestimonial(index)}
                >
                  {/* Stars */}
                  <div className="flex justify-center mb-4">
                    {renderStars(testimonial.rating)}
                  </div>
                  
                  {/* Comment */}
                  <blockquote className="text-sm leading-relaxed mb-4 text-center line-clamp-3">
                    "{testimonial.comment[currentLanguage]}"
                  </blockquote>
                  
                  {/* Author */}
                  <div className="text-center">
                    <div className="w-10 h-10 bg-white/20 rounded-full mx-auto mb-2 flex items-center justify-center">
                      <span className="text-white font-bold text-sm">
                        {testimonial.name.charAt(0)}
                      </span>
                    </div>
                    <h5 className="font-semibold text-sm">{testimonial.name}</h5>
                    <p className="text-white/80 text-xs">{testimonial.service}</p>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {/* Call to Action */}
        <div className="text-center mt-12">
          <h3 className="text-2xl font-bold text-white mb-4">
            Ready to Join Our Happy Clients?
          </h3>
          <button
            onClick={() => {
              const element = document.getElementById('booking');
              if (element) {
                element.scrollIntoView({ behavior: 'smooth' });
              }
            }}
            className="px-8 py-3 bg-white text-orange-600 font-bold rounded-full hover:bg-gray-100 transition-colors transform hover:scale-105"
          >
            {t('bookNow')}
          </button>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;