import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Menu, X, ChevronDown } from 'lucide-react';

const Header = () => {
  const { t, changeLanguage, currentLanguage, languages } = useLanguage();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isLangOpen, setIsLangOpen] = useState(false);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  const toggleLang = () => setIsLangOpen(!isLangOpen);

  const handleLanguageChange = (langCode) => {
    changeLanguage(langCode);
    setIsLangOpen(false);
  };

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  const currentLang = languages.find(lang => lang.code === currentLanguage);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center">
            <img 
              src="/images/afrobelleza-logo.png" 
              alt="AfroBelleza Logo" 
              className="w-20 h-20 object-contain mr-4"
            />
            <h1 className="text-3xl font-bold text-gray-900 cursor-pointer"
                onClick={() => scrollToSection('home')}>
              Afro<span className="text-orange-500">Belleza</span>
            </h1>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <button onClick={() => scrollToSection('home')} 
                    className="text-gray-700 hover:text-orange-500 font-medium transition-colors">
              {t('home')}
            </button>
            <button onClick={() => scrollToSection('services')} 
                    className="text-gray-700 hover:text-orange-500 font-medium transition-colors">
              {t('services')}
            </button>
            <button onClick={() => scrollToSection('about')} 
                    className="text-gray-700 hover:text-orange-500 font-medium transition-colors">
              {t('about')}
            </button>
            <button onClick={() => scrollToSection('gallery')} 
                    className="text-gray-700 hover:text-orange-500 font-medium transition-colors">
              {t('gallery')}
            </button>
            <button onClick={() => scrollToSection('testimonials')} 
                    className="text-gray-700 hover:text-orange-500 font-medium transition-colors">
              {t('testimonials')}
            </button>
            <button onClick={() => scrollToSection('contact')} 
                    className="text-gray-700 hover:text-orange-500 font-medium transition-colors">
              {t('contact')}
            </button>
          </nav>

          {/* Language Selector & Book Now - Desktop */}
          <div className="hidden md:flex items-center space-x-4">
            <div className="relative">
              <button
                onClick={toggleLang}
                className="flex items-center space-x-2 px-3 py-2 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors"
              >
                <span className="text-lg">{currentLang?.flag}</span>
                <span className="text-sm font-medium">{currentLang?.code.toUpperCase()}</span>
                <ChevronDown className="h-4 w-4" />
              </button>
              
              {isLangOpen && (
                <div className="absolute right-0 mt-2 w-40 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => handleLanguageChange(lang.code)}
                      className={`w-full flex items-center space-x-3 px-4 py-2 text-left hover:bg-gray-50 first:rounded-t-lg last:rounded-b-lg ${
                        currentLanguage === lang.code ? 'bg-orange-50 text-orange-600' : 'text-gray-700'
                      }`}
                    >
                      <span className="text-lg">{lang.flag}</span>
                      <span className="text-sm font-medium">{lang.name}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
            
            <button
              onClick={() => scrollToSection('booking')}
              className="px-6 py-2 bg-orange-500 text-white rounded-lg font-medium hover:bg-orange-600 transition-colors"
            >
              {t('bookNow')}
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button onClick={toggleMenu} className="text-gray-700 hover:text-orange-500">
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 bg-white border-t border-gray-200">
              <button onClick={() => scrollToSection('home')} 
                      className="block px-3 py-2 text-gray-700 hover:text-orange-500 font-medium w-full text-left">
                {t('home')}
              </button>
              <button onClick={() => scrollToSection('services')} 
                      className="block px-3 py-2 text-gray-700 hover:text-orange-500 font-medium w-full text-left">
                {t('services')}
              </button>
              <button onClick={() => scrollToSection('about')} 
                      className="block px-3 py-2 text-gray-700 hover:text-orange-500 font-medium w-full text-left">
                {t('about')}
              </button>
              <button onClick={() => scrollToSection('gallery')} 
                      className="block px-3 py-2 text-gray-700 hover:text-orange-500 font-medium w-full text-left">
                {t('gallery')}
              </button>
              <button onClick={() => scrollToSection('testimonials')} 
                      className="block px-3 py-2 text-gray-700 hover:text-orange-500 font-medium w-full text-left">
                {t('testimonials')}
              </button>
              <button onClick={() => scrollToSection('contact')} 
                      className="block px-3 py-2 text-gray-700 hover:text-orange-500 font-medium w-full text-left">
                {t('contact')}
              </button>
              
              {/* Language Selector - Mobile */}
              <div className="border-t border-gray-200 pt-3">
                <div className="px-3 py-2">
                  <div className="text-sm font-medium text-gray-500 mb-2">Language</div>
                  <div className="space-y-1">
                    {languages.map((lang) => (
                      <button
                        key={lang.code}
                        onClick={() => handleLanguageChange(lang.code)}
                        className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left ${
                          currentLanguage === lang.code 
                            ? 'bg-orange-50 text-orange-600' 
                            : 'text-gray-700 hover:bg-gray-50'
                        }`}
                      >
                        <span className="text-lg">{lang.flag}</span>
                        <span className="text-sm font-medium">{lang.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              
              <button
                onClick={() => scrollToSection('booking')}
                className="w-full mt-4 mx-3 px-6 py-2 bg-orange-500 text-white rounded-lg font-medium hover:bg-orange-600 transition-colors"
                style={{ width: 'calc(100% - 1.5rem)' }}
              >
                {t('bookNow')}
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;