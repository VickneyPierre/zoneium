import React, { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { servicesAPI, appointmentsAPI, timeSlotsAPI, handleAPIError } from '../services/api';
import { Calendar, Clock, User, Mail, Phone, Check, Loader, AlertCircle } from 'lucide-react';

const Booking = () => {
  const { t, currentLanguage } = useLanguage();
  const [services, setServices] = useState([]);
  const [availableTimeSlots, setAvailableTimeSlots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({
    service: '',
    date: '',
    time: '',
    name: '',
    email: '',
    phone: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    fetchServices();
  }, []);

  useEffect(() => {
    if (formData.date) {
      fetchAvailableTimeSlots(formData.date, formData.service || null);
    } else {
      setAvailableTimeSlots([]);
    }
  }, [formData.date, formData.service]);

  const fetchServices = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await servicesAPI.getAll();
      setServices(response.data);
    } catch (error) {
      console.error('Error fetching services:', error);
      setError(handleAPIError(error, 'Failed to load services'));
    } finally {
      setLoading(false);
    }
  };

  const fetchAvailableTimeSlots = async (date, serviceId) => {
    try {
      const response = await timeSlotsAPI.getAvailability(date, serviceId);
      setAvailableTimeSlots(response.data.available_times);
    } catch (error) {
      console.error('Error fetching time slots:', error);
      setAvailableTimeSlots([]);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));

    // Clear time when date or service changes
    if (name === 'date' || name === 'service') {
      setFormData(prev => ({
        ...prev,
        time: ''
      }));
    }
  };

  const handleTimeSelection = (time) => {
    setFormData(prev => ({
      ...prev,
      time
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      setSubmitting(true);
      setError(null);

      const appointmentData = {
        service: formData.service,
        date: formData.date,
        time: formData.time,
        name: formData.name,
        email: formData.email,
        phone: formData.phone
      };

      await appointmentsAPI.create(appointmentData);
      
      setIsSubmitted(true);
      
      // Reset form after 5 seconds
      setTimeout(() => {
        setIsSubmitted(false);
        setFormData({
          service: '',
          date: '',
          time: '',
          name: '',
          email: '',
          phone: ''
        });
        setAvailableTimeSlots([]);
      }, 5000);
      
    } catch (error) {
      console.error('Error creating appointment:', error);
      setError(handleAPIError(error, 'Failed to book appointment'));
    } finally {
      setSubmitting(false);
    }
  };

  const selectedService = services.find(s => s.id === formData.service);

  // Generate available dates (next 30 days)
  const generateAvailableDates = () => {
    const dates = [];
    const today = new Date();
    for (let i = 1; i <= 30; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      // Skip Sundays (assuming closed on Sundays)
      if (date.getDay() !== 0) {
        dates.push(date.toISOString().split('T')[0]);
      }
    }
    return dates;
  };

  const availableDates = generateAvailableDates();

  if (loading) {
    return (
      <section id="booking" className="py-16 bg-gradient-to-br from-gray-50 to-orange-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Loader className="w-12 h-12 animate-spin text-orange-500 mx-auto mb-4" />
          <p className="text-gray-600">Loading booking form...</p>
        </div>
      </section>
    );
  }

  if (isSubmitted) {
    return (
      <section id="booking" className="py-16 bg-gradient-to-br from-green-50 to-emerald-50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <div className="mb-6">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="w-10 h-10 text-green-600" />
              </div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Booking Confirmed!
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                Thank you for choosing AfroBelleza. We'll contact you shortly to confirm your appointment.
              </p>
              {selectedService && (
                <div className="bg-gray-50 rounded-xl p-4 text-left max-w-md mx-auto">
                  <h3 className="font-semibold text-gray-900 mb-2">Booking Details:</h3>
                  <p className="text-sm text-gray-600">Service: {selectedService.name[currentLanguage]}</p>
                  <p className="text-sm text-gray-600">Date: {new Date(formData.date).toLocaleDateString()}</p>
                  <p className="text-sm text-gray-600">Time: {formData.time}</p>
                  <p className="text-sm text-gray-600">Name: {formData.name}</p>
                  <p className="text-sm text-gray-600">Price: ${selectedService.price}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="booking" className="py-16 bg-gradient-to-br from-gray-50 to-orange-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            {t('bookingTitle')}
          </h2>
          <p className="text-xl text-gray-600">
            Choose your service and preferred time
          </p>
          <div className="w-24 h-1 bg-gradient-to-r from-orange-400 to-red-400 mx-auto mt-6"></div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-8">
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start">
              <AlertCircle className="w-5 h-5 text-red-500 mr-3 mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="text-red-800 font-semibold">Booking Error</h3>
                <p className="text-red-700 mt-1">{error}</p>
              </div>
            </div>
          </div>
        )}

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Booking Form */}
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Service Selection */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  {t('selectService')} *
                </label>
                <select
                  name="service"
                  value={formData.service}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-colors"
                >
                  <option value="">Choose a service...</option>
                  {services.map((service) => (
                    <option key={service.id} value={service.id}>
                      {service.name[currentLanguage]} - ${service.price} pesos ({service.duration})
                    </option>
                  ))}
                </select>
              </div>

              {/* Date Selection */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  {t('selectDate')} *
                </label>
                <select
                  name="date"
                  value={formData.date}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-colors"
                >
                  <option value="">Select a date...</option>
                  {availableDates.map((date) => (
                    <option key={date} value={date}>
                      {new Date(date).toLocaleDateString('en-US', {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </option>
                  ))}
                </select>
              </div>

              {/* Time Selection */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  {t('selectTime')} *
                </label>
                {formData.date && availableTimeSlots.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Clock className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p>No available times for selected date</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-3 gap-3">
                    {availableTimeSlots.map((time) => (
                      <button
                        key={time}
                        type="button"
                        onClick={() => handleTimeSelection(time)}
                        className={`px-4 py-2 rounded-lg font-medium transition-all ${
                          formData.time === time
                            ? 'bg-orange-500 text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-orange-100'
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Personal Information */}
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">
                    {t('name')} *
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-3.5 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder={t('name')}
                      required
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">
                    Phone *
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3.5 w-5 h-5 text-gray-400" />
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder={t('phonePlaceholder')}
                      required
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-colors"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  Email *
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3.5 w-5 h-5 text-gray-400" />
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder={t('emailPlaceholder')}
                    required
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-colors"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full px-8 py-4 bg-gradient-to-r from-orange-500 to-red-500 text-white font-bold rounded-xl hover:from-orange-600 hover:to-red-600 transition-all duration-300 transform hover:scale-105 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
              >
                {submitting ? (
                  <>
                    <Loader className="inline-block w-5 h-5 mr-2 animate-spin" />
                    Booking...
                  </>
                ) : (
                  <>
                    <Calendar className="inline-block w-5 h-5 mr-2" />
                    {t('submit')}
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Booking Summary */}
          <div className="space-y-8">
            {/* Selected Service Details */}
            {selectedService && (
              <div className="bg-white rounded-2xl shadow-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">Service Details</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Service:</span>
                    <span className="font-medium">{selectedService.name[currentLanguage]}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Duration:</span>
                    <span className="font-medium">{selectedService.duration}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Price:</span>
                    <span className="font-bold text-orange-600 text-xl">${selectedService.price} pesos</span>
                  </div>
                  <div className="border-t pt-3 mt-3">
                    <p className="text-sm text-gray-600">{selectedService.description[currentLanguage]}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Contact Information */}
            <div className="bg-gradient-to-r from-orange-500 to-red-500 rounded-2xl p-6 text-white">
              <h3 className="text-xl font-bold mb-4">Need Help?</h3>
              <div className="space-y-2 text-sm">
                <p><Phone className="inline w-4 h-4 mr-2" />+52 962 447 0847</p>
                <p><Mail className="inline w-4 h-4 mr-2" />afrobelleza@qualityservice.com</p>
                <p><Clock className="inline w-4 h-4 mr-2" />Mon-Sat: 9AM-7PM</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Booking;