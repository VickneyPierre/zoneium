import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { Award, Heart, Users, Sparkles, Scissors, Star } from 'lucide-react';

const About = () => {
  const { t, currentLanguage } = useLanguage();

  const stats = [
    { icon: Users, number: "500+", label: { en: "Happy Clients", fr: "Clients Satisfaits", es: "Clientes Felices" } },
    { icon: Award, number: "8+", label: { en: "Years Experience", fr: "Années d'Expérience", es: "Años de Experiencia" } },
    { icon: Scissors, number: "1000+", label: { en: "Braids Created", fr: "Tresses Réalisées", es: "Trenzas Creadas" } },
    { icon: Star, number: "5.0", label: { en: "Average Rating", fr: "Note Moyenne", es: "Calificación Promedio" } }
  ];

  const values = [
    {
      icon: Heart,
      title: { en: "Passion", fr: "Passion", es: "Pasión" },
      description: { 
        en: "We love celebrating Afro heritage through beautiful hairstyles",
        fr: "Nous aimons célébrer l'héritage afro à travers de belles coiffures",
        es: "Nos encanta celebrar la herencia afro a través de hermosos peinados"
      }
    },
    {
      icon: Award,
      title: { en: "Excellence", fr: "Excellence", es: "Excelencia" },
      description: { 
        en: "We strive for perfection in every service we provide",
        fr: "Nous visons la perfection dans chaque service que nous fournissons",
        es: "Nos esforzamos por la perfección en cada servicio que brindamos"
      }
    },
    {
      icon: Sparkles,
      title: { en: "Innovation", fr: "Innovation", es: "Innovación" },
      description: { 
        en: "Combining traditional techniques with modern luxury",
        fr: "Combinant techniques traditionnelles et luxe moderne",
        es: "Combinando técnicas tradicionales con lujo moderno"
      }
    }
  ];

  return (
    <section id="about" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            {t('aboutTitle')}
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-orange-400 to-red-400 mx-auto"></div>
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Left Side - Image */}
          <div className="relative">
            <div className="aspect-w-4 aspect-h-3 rounded-2xl overflow-hidden bg-gradient-to-br from-orange-100 to-red-100">
              <div className="flex items-center justify-center h-80">
                <div className="text-center">
                  <Scissors className="w-24 h-24 text-orange-400 mx-auto mb-4 opacity-30" />
                  <Sparkles className="w-16 h-16 text-red-400 mx-auto opacity-30" />
                </div>
              </div>
            </div>
            {/* Decorative Elements */}
            <div className="absolute -top-4 -right-4 w-20 h-20 bg-orange-400 rounded-full opacity-20"></div>
            <div className="absolute -bottom-6 -left-6 w-16 h-16 bg-red-400 rounded-full opacity-20"></div>
          </div>

          {/* Right Side - Content */}
          <div className="space-y-6">
            <p className="text-lg text-gray-600 leading-relaxed">
              {t('aboutDescription')}
            </p>
            <p className="text-lg text-gray-600 leading-relaxed">
              {currentLanguage === 'en' && "At AfroBelleza, we believe that every hairstyle tells a story. Our expert stylists are dedicated to creating beautiful braids and nail art that celebrate your unique beauty and cultural heritage."}
              {currentLanguage === 'fr' && "Chez AfroBelleza, nous croyons que chaque coiffure raconte une histoire. Nos stylistes experts se consacrent à créer de belles tresses et nail art qui célèbrent votre beauté unique et votre héritage culturel."}
              {currentLanguage === 'es' && "En AfroBelleza, creemos que cada peinado cuenta una historia. Nuestros estilistas expertos se dedican a crear hermosas trenzas y nail art que celebran tu belleza única y herencia cultural."}
            </p>
            <p className="text-lg text-gray-600 leading-relaxed">
              {currentLanguage === 'en' && "Using only premium products and time-honored techniques, we ensure that every client leaves feeling confident and beautiful."}
              {currentLanguage === 'fr' && "En utilisant uniquement des produits premium et des techniques éprouvées, nous nous assurons que chaque client repart en se sentant confiant et beau."}
              {currentLanguage === 'es' && "Utilizando solo productos premium y técnicas consagradas, nos aseguramos de que cada cliente se vaya sintiéndose seguro y hermoso."}
            </p>
          </div>
        </div>

        {/* Stats Section */}
        <div className="bg-gradient-to-r from-orange-500 via-red-500 to-pink-500 rounded-2xl p-8 mb-16">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center text-white">
            {stats.map((stat, index) => (
              <div key={index} className="group">
                <stat.icon className="w-12 h-12 mx-auto mb-4 group-hover:scale-110 transition-transform" />
                <div className="text-3xl font-bold mb-2">{stat.number}</div>
                <div className="text-sm opacity-90">{stat.label[currentLanguage]}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Values Section */}
        <div>
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">
            {currentLanguage === 'en' && 'Our Values'}
            {currentLanguage === 'fr' && 'Nos Valeurs'}
            {currentLanguage === 'es' && 'Nuestros Valores'}
          </h3>
          <div className="grid md:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <div key={index} className="text-center group">
                <div className="bg-gradient-to-br from-orange-100 to-red-100 rounded-2xl p-8 mb-4 group-hover:shadow-lg transition-shadow">
                  <value.icon className="w-12 h-12 text-orange-500 mx-auto mb-4 group-hover:scale-110 transition-transform" />
                  <h4 className="text-xl font-bold text-gray-900 mb-3">
                    {value.title[currentLanguage]}
                  </h4>
                  <p className="text-gray-600 leading-relaxed">
                    {value.description[currentLanguage]}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;