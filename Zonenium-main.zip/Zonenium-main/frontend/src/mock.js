// Mock data for AfroBelleza salon

export const translations = {
  en: {
    // Navigation
    home: "Home",
    services: "Services", 
    about: "About",
    gallery: "Gallery",
    testimonials: "Testimonials",
    contact: "Contact",
    bookNow: "Book Now",
    
    // Hero Section
    heroTitle: "AfroBelleza",
    heroSubtitle: "Luxury Hair & Nails Salon",
    heroDescription: "Celebrating Afro heritage with premium hair braiding and nail services. Experience elegance, tradition, and modern luxury.",
    
    // Services
    servicesTitle: "Our Services",
    servicesSubtitle: "Professional hair braiding and nail care services",
    
    // About
    aboutTitle: "About AfroBelleza",
    aboutDescription: "We are a premium salon specializing in Afro hair care and nail services, combining traditional techniques with modern luxury.",
    
    // Contact
    contactTitle: "Contact Us",
    phone: "Phone",
    email: "Email", 
    address: "Address",
    hours: "Hours",
    
    // Booking
    bookingTitle: "Book Appointment",
    selectService: "Select Service",
    selectDate: "Select Date",
    selectTime: "Select Time",
    name: "Full Name",
    emailPlaceholder: "Email Address",
    phonePlaceholder: "Phone Number",
    submit: "Book Appointment",
    
    // Gallery
    galleryTitle: "Our Work",
    gallerySubtitle: "Browse our latest hair braiding and nail art",
    
    // Testimonials
    testimonialsTitle: "What Our Clients Say"
  },
  fr: {
    // Navigation
    home: "Accueil",
    services: "Services",
    about: "À propos", 
    gallery: "Galerie",
    testimonials: "Témoignages",
    contact: "Contact",
    bookNow: "Réserver",
    
    // Hero Section
    heroTitle: "AfroBelleza",
    heroSubtitle: "Salon de Coiffure & Ongles de Luxe",
    heroDescription: "Célébrer l'héritage afro avec des services de tressage et d'ongles premium. Découvrez l'élégance, la tradition et le luxe moderne.",
    
    // Services
    servicesTitle: "Nos Services",
    servicesSubtitle: "Services professionnels de tressage et de soins des ongles",
    
    // About
    aboutTitle: "À propos d'AfroBelleza",
    aboutDescription: "Nous sommes un salon premium spécialisé dans les soins capillaires afro et les services d'ongles, combinant techniques traditionnelles et luxe moderne.",
    
    // Contact
    contactTitle: "Nous Contacter",
    phone: "Téléphone",
    email: "Email",
    address: "Adresse", 
    hours: "Horaires",
    
    // Booking
    bookingTitle: "Prendre Rendez-vous",
    selectService: "Choisir le Service",
    selectDate: "Choisir la Date",
    selectTime: "Choisir l'Heure",
    name: "Nom Complet",
    emailPlaceholder: "Adresse Email",
    phonePlaceholder: "Numéro de Téléphone",
    submit: "Réserver",
    
    // Gallery
    galleryTitle: "Notre Travail",
    gallerySubtitle: "Découvrez nos derniers tressages et nail art",
    
    // Testimonials
    testimonialsTitle: "Ce que disent nos Clients"
  },
  es: {
    // Navigation
    home: "Inicio",
    services: "Servicios",
    about: "Acerca de",
    gallery: "Galería", 
    testimonials: "Testimonios",
    contact: "Contacto",
    bookNow: "Reservar",
    
    // Hero Section
    heroTitle: "AfroBelleza",
    heroSubtitle: "Salón de Cabello y Uñas de Lujo",
    heroDescription: "Celebrando la herencia afro con servicios premium de trenzado y uñas. Experimenta elegancia, tradición y lujo moderno.",
    
    // Services
    servicesTitle: "Nuestros Servicios", 
    servicesSubtitle: "Servicios profesionales de trenzado y cuidado de uñas",
    
    // About
    aboutTitle: "Acerca de AfroBelleza",
    aboutDescription: "Somos un salón premium especializado en cuidado capilar afro y servicios de uñas, combinando técnicas tradicionales con lujo moderno.",
    
    // Contact
    contactTitle: "Contáctanos",
    phone: "Teléfono",
    email: "Email",
    address: "Dirección",
    hours: "Horarios",
    
    // Booking
    bookingTitle: "Reservar Cita",
    selectService: "Seleccionar Servicio",
    selectDate: "Seleccionar Fecha", 
    selectTime: "Seleccionar Hora",
    name: "Nombre Completo",
    emailPlaceholder: "Correo Electrónico",
    phonePlaceholder: "Número de Teléfono",
    submit: "Reservar Cita",
    
    // Gallery
    galleryTitle: "Nuestro Trabajo",
    gallerySubtitle: "Explora nuestros últimos trenzados y nail art",
    
    // Testimonials  
    testimonialsTitle: "Lo que dicen nuestros Clientes"
  }
};

export const services = [
  {
    id: 1,
    name: {
      en: "Braid Male",
      fr: "Tresses Homme", 
      es: "Trenzas Hombre"
    },
    description: {
      en: "Professional braiding services for men",
      fr: "Services de tressage professionnel pour hommes",
      es: "Servicios profesionales de trenzado para hombres"
    },
    price: 85,
    duration: "2-3 hours",
    image: "/api/placeholder/300/200"
  },
  {
    id: 2,
    name: {
      en: "Braid Women", 
      fr: "Tresses Femme",
      es: "Trenzas Mujer"
    },
    description: {
      en: "Elegant braiding styles for women",
      fr: "Styles de tressage élégants pour femmes", 
      es: "Estilos elegantes de trenzado para mujeres"
    },
    price: 120,
    duration: "3-4 hours",
    image: "/api/placeholder/300/200"
  },
  {
    id: 3,
    name: {
      en: "Braid Kids",
      fr: "Tresses Enfant",
      es: "Trenzas Niños"
    },
    description: {
      en: "Fun and protective braids for children",
      fr: "Tresses amusantes et protectrices pour enfants",
      es: "Trenzas divertidas y protectoras para niños"
    },
    price: 65,
    duration: "1-2 hours", 
    image: "/api/placeholder/300/200"
  },
  {
    id: 4,
    name: {
      en: "Twist",
      fr: "Torsades",
      es: "Giros"
    },
    description: {
      en: "Modern twist hairstyles",
      fr: "Coiffures torsadées modernes",
      es: "Peinados modernos con giros"
    },
    price: 95,
    duration: "2-3 hours",
    image: "/api/placeholder/300/200"
  },
  {
    id: 5,
    name: {
      en: "Manicure",
      fr: "Manucure", 
      es: "Manicura"
    },
    description: {
      en: "Professional nail care and design",
      fr: "Soins et design d'ongles professionnels",
      es: "Cuidado profesional y diseño de uñas"
    },
    price: 45,
    duration: "1 hour",
    image: "/api/placeholder/300/200"
  },
  {
    id: 6,
    name: {
      en: "Pedicure",
      fr: "Pédicure",
      es: "Pedicura" 
    },
    description: {
      en: "Relaxing foot care treatment",
      fr: "Soin relaxant des pieds",
      es: "Tratamiento relajante de cuidado de pies"
    },
    price: 55,
    duration: "1.5 hours",
    image: "/api/placeholder/300/200"
  }
];

export const testimonials = [
  {
    id: 1,
    name: "Amara Johnson",
    service: "Braid Women",
    rating: 5,
    comment: {
      en: "Absolutely stunning work! The braids lasted for weeks and looked perfect.",
      fr: "Travail absolument magnifique ! Les tresses ont duré des semaines et étaient parfaites.",
      es: "¡Trabajo absolutamente increíble! Las trenzas duraron semanas y se veían perfectas."
    },
    image: "/api/placeholder/60/60"
  },
  {
    id: 2, 
    name: "Marcus Williams",
    service: "Braid Male",
    rating: 5,
    comment: {
      en: "Professional service and amazing results. Highly recommend!",
      fr: "Service professionnel et résultats incroyables. Je recommande vivement !",
      es: "Servicio profesional y resultados increíbles. ¡Muy recomendado!"
    },
    image: "/api/placeholder/60/60"
  },
  {
    id: 3,
    name: "Sofia Rodriguez", 
    service: "Manicure",
    rating: 5,
    comment: {
      en: "Beautiful nail art and excellent customer service!",
      fr: "Magnifique nail art et excellent service client !",
      es: "¡Hermoso nail art y excelente servicio al cliente!"
    },
    image: "/api/placeholder/60/60"
  }
];

export const galleryImages = [
  {
    id: 1,
    category: "braids",
    title: "Box Braids",
    image: "/api/placeholder/400/300"
  },
  {
    id: 2,
    category: "braids", 
    title: "Cornrows",
    image: "/api/placeholder/400/300"
  },
  {
    id: 3,
    category: "twist",
    title: "Senegalese Twist",
    image: "/api/placeholder/400/300"
  },
  {
    id: 4,
    category: "nails",
    title: "French Manicure",
    image: "/api/placeholder/400/300"
  },
  {
    id: 5,
    category: "nails",
    title: "Nail Art Design",
    image: "/api/placeholder/400/300"
  },
  {
    id: 6,
    category: "braids",
    title: "Ghana Braids", 
    image: "/api/placeholder/400/300"
  }
];

export const contactInfo = {
  phone: "+1 (555) 123-4567",
  email: "info@afrobelleza.com",
  address: "123 Beauty Avenue, New York, NY 10001",
  hours: {
    en: "Mon-Sat: 9AM-7PM, Sun: 10AM-5PM",
    fr: "Lun-Sam: 9h-19h, Dim: 10h-17h", 
    es: "Lun-Sáb: 9AM-7PM, Dom: 10AM-5PM"
  }
};

export const timeSlots = [
  "9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM",
  "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM"
];