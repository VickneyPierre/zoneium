import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API_BASE = `${BACKEND_URL}/api`;

// Create axios instance with default config
const apiClient = axios.create({
  baseURL: API_BASE,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor for logging
apiClient.interceptors.request.use(
  (config) => {
    console.log(`API Request: ${config.method?.toUpperCase()} ${config.url}`);
    return config;
  },
  (error) => {
    console.error('API Request Error:', error);
    return Promise.reject(error);
  }
);

// Response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => {
    console.log(`API Response: ${response.status} ${response.config.url}`);
    return response;
  },
  (error) => {
    console.error('API Response Error:', error?.response?.status, error?.response?.data || error.message);
    return Promise.reject(error);
  }
);

// Services API
export const servicesAPI = {
  getAll: () => apiClient.get('/services'),
  getById: (id) => apiClient.get(`/services/${id}`),
};

// Appointments API
export const appointmentsAPI = {
  create: (data) => apiClient.post('/appointments', data),
  getAll: (status = null) => {
    const params = status ? { status } : {};
    return apiClient.get('/appointments', { params });
  },
  getById: (id) => apiClient.get(`/appointments/${id}`),
  updateStatus: (id, status) => 
    apiClient.put(`/appointments/${id}/status`, null, { 
      params: { status } 
    }),
};

// Contact API
export const contactAPI = {
  submit: (data) => apiClient.post('/contact', data),
  getAll: (status = null) => {
    const params = status ? { status } : {};
    return apiClient.get('/contact', { params });
  },
};

// Testimonials API
export const testimonialsAPI = {
  getAll: () => apiClient.get('/testimonials'),
};

// Gallery API
export const galleryAPI = {
  getAll: (category = null) => {
    const params = category ? { category } : {};
    return apiClient.get('/gallery', { params });
  },
  getByCategory: (category) => apiClient.get('/gallery', { 
    params: { category } 
  }),
};

// Time slots API
export const timeSlotsAPI = {
  getAvailability: (date, serviceId = null) => {
    const params = { date };
    if (serviceId) params.service = serviceId;
    return apiClient.get('/timeslots', { params });
  },
};

// Error handler utility
export const handleAPIError = (error, defaultMessage = 'An error occurred') => {
  if (error.response) {
    // Server responded with error status
    return error.response.data?.detail || error.response.data?.message || defaultMessage;
  } else if (error.request) {
    // Request made but no response received
    return 'Network error. Please check your connection.';
  } else {
    // Something else happened
    return error.message || defaultMessage;
  }
};

// Export the configured axios client for custom requests
export { apiClient };
export default apiClient;