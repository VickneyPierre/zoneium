#!/usr/bin/env python3
"""
AfroBelleza Backend API Test Suite
Tests all backend endpoints for the hair salon booking system
"""

import requests
import json
import sys
from datetime import datetime, timedelta
import os
from pathlib import Path

# Load environment variables to get the backend URL
def load_env_file(file_path):
    """Load environment variables from .env file"""
    env_vars = {}
    if os.path.exists(file_path):
        with open(file_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    env_vars[key] = value.strip('"')
    return env_vars

# Get backend URL from frontend .env file
frontend_env = load_env_file('/app/frontend/.env')
BACKEND_URL = frontend_env.get('REACT_APP_BACKEND_URL', 'http://localhost:8001')
API_BASE_URL = f"{BACKEND_URL}/api"

print(f"Testing backend API at: {API_BASE_URL}")

class APITester:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        })
        self.test_results = []
        self.service_ids = []
        self.appointment_ids = []
        
    def log_test(self, test_name, success, message="", response_data=None):
        """Log test results"""
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} {test_name}: {message}")
        self.test_results.append({
            'test': test_name,
            'success': success,
            'message': message,
            'response_data': response_data
        })
        
    def test_health_check(self):
        """Test API health check endpoint"""
        try:
            response = self.session.get(f"{API_BASE_URL}/")
            if response.status_code == 200:
                data = response.json()
                if data.get('status') == 'healthy':
                    self.log_test("Health Check", True, "API is healthy")
                    return True
                else:
                    self.log_test("Health Check", False, f"Unexpected response: {data}")
            else:
                self.log_test("Health Check", False, f"Status code: {response.status_code}")
        except Exception as e:
            self.log_test("Health Check", False, f"Connection error: {str(e)}")
        return False
        
    def test_services_api(self):
        """Test Services API endpoints"""
        print("\n=== Testing Services API ===")
        
        # Test GET /api/services
        try:
            response = self.session.get(f"{API_BASE_URL}/services")
            if response.status_code == 200:
                services = response.json()
                if isinstance(services, list) and len(services) > 0:
                    self.log_test("GET /services", True, f"Retrieved {len(services)} services")
                    
                    # Store service IDs for later tests
                    self.service_ids = [service['id'] for service in services]
                    
                    # Verify multilingual content
                    first_service = services[0]
                    if 'name' in first_service and isinstance(first_service['name'], dict):
                        languages = ['en', 'fr', 'es']
                        has_all_languages = all(lang in first_service['name'] for lang in languages)
                        if has_all_languages:
                            self.log_test("Services Multilingual Content", True, "All languages present")
                        else:
                            self.log_test("Services Multilingual Content", False, "Missing language translations")
                    
                    # Verify required fields
                    required_fields = ['id', 'name', 'description', 'price', 'duration', 'category']
                    has_required_fields = all(field in first_service for field in required_fields)
                    if has_required_fields:
                        self.log_test("Services Required Fields", True, "All required fields present")
                    else:
                        missing_fields = [field for field in required_fields if field not in first_service]
                        self.log_test("Services Required Fields", False, f"Missing fields: {missing_fields}")
                        
                else:
                    self.log_test("GET /services", False, "No services returned or invalid format")
            else:
                self.log_test("GET /services", False, f"Status code: {response.status_code}")
        except Exception as e:
            self.log_test("GET /services", False, f"Error: {str(e)}")
            
        # Test GET /api/services/{id}
        if self.service_ids:
            try:
                service_id = self.service_ids[0]
                response = self.session.get(f"{API_BASE_URL}/services/{service_id}")
                if response.status_code == 200:
                    service = response.json()
                    if service.get('id') == service_id:
                        self.log_test("GET /services/{id}", True, f"Retrieved service: {service.get('name', {}).get('en', 'Unknown')}")
                    else:
                        self.log_test("GET /services/{id}", False, "Service ID mismatch")
                else:
                    self.log_test("GET /services/{id}", False, f"Status code: {response.status_code}")
            except Exception as e:
                self.log_test("GET /services/{id}", False, f"Error: {str(e)}")
                
        # Test invalid service ID
        try:
            response = self.session.get(f"{API_BASE_URL}/services/invalid_id")
            if response.status_code == 400:
                self.log_test("GET /services/invalid_id", True, "Properly handled invalid ID")
            else:
                self.log_test("GET /services/invalid_id", False, f"Expected 400, got {response.status_code}")
        except Exception as e:
            self.log_test("GET /services/invalid_id", False, f"Error: {str(e)}")
            
    def test_appointments_api(self):
        """Test Appointments API endpoints"""
        print("\n=== Testing Appointments API ===")
        
        if not self.service_ids:
            self.log_test("Appointments API", False, "No service IDs available for testing")
            return
            
        # Test POST /api/appointments (create appointment)
        tomorrow = (datetime.now() + timedelta(days=1)).strftime('%Y-%m-%d')
        
        # Get available time slots first
        try:
            timeslots_response = self.session.get(f"{API_BASE_URL}/timeslots?date={tomorrow}")
            available_times = []
            if timeslots_response.status_code == 200:
                timeslots_data = timeslots_response.json()
                available_times = timeslots_data.get('available_times', [])
        except:
            available_times = ["9:00 AM"]  # fallback
            
        appointment_data = {
            "service": self.service_ids[0],
            "date": tomorrow,
            "time": available_times[0] if available_times else "9:00 AM",
            "name": "Isabella Martinez",
            "email": "isabella.martinez@email.com",
            "phone": "+1-555-0123"
        }
        
        try:
            response = self.session.post(f"{API_BASE_URL}/appointments", json=appointment_data)
            if response.status_code == 200:
                appointment = response.json()
                if appointment.get('id'):
                    self.appointment_ids.append(appointment['id'])
                    self.log_test("POST /appointments", True, f"Created appointment for {appointment.get('customer_name')}")
                    
                    # Verify appointment data
                    expected_fields = ['id', 'service_id', 'service_name', 'customer_name', 'customer_email', 'date', 'time', 'status']
                    has_fields = all(field in appointment for field in expected_fields)
                    if has_fields:
                        self.log_test("Appointment Data Validation", True, "All required fields present")
                    else:
                        missing = [field for field in expected_fields if field not in appointment]
                        self.log_test("Appointment Data Validation", False, f"Missing fields: {missing}")
                else:
                    self.log_test("POST /appointments", False, "No appointment ID returned")
            else:
                self.log_test("POST /appointments", False, f"Status code: {response.status_code}, Response: {response.text}")
        except Exception as e:
            self.log_test("POST /appointments", False, f"Error: {str(e)}")
            
        # Test GET /api/appointments
        try:
            response = self.session.get(f"{API_BASE_URL}/appointments")
            if response.status_code == 200:
                appointments = response.json()
                if isinstance(appointments, list):
                    self.log_test("GET /appointments", True, f"Retrieved {len(appointments)} appointments")
                else:
                    self.log_test("GET /appointments", False, "Invalid response format")
            else:
                self.log_test("GET /appointments", False, f"Status code: {response.status_code}")
        except Exception as e:
            self.log_test("GET /appointments", False, f"Error: {str(e)}")
            
        # Test GET /api/appointments/{id}
        if self.appointment_ids:
            try:
                appointment_id = self.appointment_ids[0]
                response = self.session.get(f"{API_BASE_URL}/appointments/{appointment_id}")
                if response.status_code == 200:
                    appointment = response.json()
                    if appointment.get('id') == appointment_id:
                        self.log_test("GET /appointments/{id}", True, f"Retrieved appointment for {appointment.get('customer_name')}")
                    else:
                        self.log_test("GET /appointments/{id}", False, "Appointment ID mismatch")
                else:
                    self.log_test("GET /appointments/{id}", False, f"Status code: {response.status_code}")
            except Exception as e:
                self.log_test("GET /appointments/{id}", False, f"Error: {str(e)}")
                
        # Test appointment status update
        if self.appointment_ids:
            try:
                appointment_id = self.appointment_ids[0]
                response = self.session.put(f"{API_BASE_URL}/appointments/{appointment_id}/status?status=confirmed")
                if response.status_code == 200:
                    result = response.json()
                    if result.get('status') == 'confirmed':
                        self.log_test("PUT /appointments/{id}/status", True, "Status updated successfully")
                    else:
                        self.log_test("PUT /appointments/{id}/status", False, "Status not updated properly")
                else:
                    self.log_test("PUT /appointments/{id}/status", False, f"Status code: {response.status_code}")
            except Exception as e:
                self.log_test("PUT /appointments/{id}/status", False, f"Error: {str(e)}")
                
        # Test invalid appointment creation (duplicate time slot)
        try:
            response = self.session.post(f"{API_BASE_URL}/appointments", json=appointment_data)
            if response.status_code == 400:
                self.log_test("Duplicate Time Slot Validation", True, "Properly rejected duplicate booking")
            else:
                self.log_test("Duplicate Time Slot Validation", False, f"Expected 400, got {response.status_code}")
        except Exception as e:
            self.log_test("Duplicate Time Slot Validation", False, f"Error: {str(e)}")
            
    def test_timeslots_api(self):
        """Test Time Slots API"""
        print("\n=== Testing Time Slots API ===")
        
        tomorrow = (datetime.now() + timedelta(days=1)).strftime('%Y-%m-%d')
        
        try:
            response = self.session.get(f"{API_BASE_URL}/timeslots?date={tomorrow}")
            if response.status_code == 200:
                timeslots = response.json()
                required_fields = ['date', 'available_times', 'booked_times']
                has_fields = all(field in timeslots for field in required_fields)
                
                if has_fields:
                    available_count = len(timeslots.get('available_times', []))
                    booked_count = len(timeslots.get('booked_times', []))
                    self.log_test("GET /timeslots", True, f"Available: {available_count}, Booked: {booked_count}")
                    
                    # Verify that booked times are not in available times
                    available_times = set(timeslots.get('available_times', []))
                    booked_times = set(timeslots.get('booked_times', []))
                    overlap = available_times.intersection(booked_times)
                    
                    if not overlap:
                        self.log_test("Time Slot Logic", True, "No overlap between available and booked times")
                    else:
                        self.log_test("Time Slot Logic", False, f"Overlap found: {overlap}")
                else:
                    missing = [field for field in required_fields if field not in timeslots]
                    self.log_test("GET /timeslots", False, f"Missing fields: {missing}")
            else:
                self.log_test("GET /timeslots", False, f"Status code: {response.status_code}")
        except Exception as e:
            self.log_test("GET /timeslots", False, f"Error: {str(e)}")
            
        # Test with service parameter
        if self.service_ids:
            try:
                service_id = self.service_ids[0]
                response = self.session.get(f"{API_BASE_URL}/timeslots?date={tomorrow}&service={service_id}")
                if response.status_code == 200:
                    self.log_test("GET /timeslots with service", True, "Service parameter accepted")
                else:
                    self.log_test("GET /timeslots with service", False, f"Status code: {response.status_code}")
            except Exception as e:
                self.log_test("GET /timeslots with service", False, f"Error: {str(e)}")
                
    def test_contact_api(self):
        """Test Contact API endpoints"""
        print("\n=== Testing Contact API ===")
        
        # Test POST /api/contact
        contact_data = {
            "name": "Carmen Rodriguez",
            "email": "carmen.rodriguez@email.com",
            "message": "I would like to book an appointment for box braids. What are your available times next week?"
        }
        
        try:
            response = self.session.post(f"{API_BASE_URL}/contact", json=contact_data)
            if response.status_code == 200:
                contact_message = response.json()
                if contact_message.get('id'):
                    self.log_test("POST /contact", True, f"Contact message created from {contact_message.get('name')}")
                    
                    # Verify contact message data
                    expected_fields = ['id', 'name', 'email', 'message', 'status', 'created_at']
                    has_fields = all(field in contact_message for field in expected_fields)
                    if has_fields:
                        self.log_test("Contact Message Data", True, "All required fields present")
                    else:
                        missing = [field for field in expected_fields if field not in contact_message]
                        self.log_test("Contact Message Data", False, f"Missing fields: {missing}")
                else:
                    self.log_test("POST /contact", False, "No message ID returned")
            else:
                self.log_test("POST /contact", False, f"Status code: {response.status_code}")
        except Exception as e:
            self.log_test("POST /contact", False, f"Error: {str(e)}")
            
        # Test GET /api/contact
        try:
            response = self.session.get(f"{API_BASE_URL}/contact")
            if response.status_code == 200:
                messages = response.json()
                if isinstance(messages, list):
                    self.log_test("GET /contact", True, f"Retrieved {len(messages)} contact messages")
                else:
                    self.log_test("GET /contact", False, "Invalid response format")
            else:
                self.log_test("GET /contact", False, f"Status code: {response.status_code}")
        except Exception as e:
            self.log_test("GET /contact", False, f"Error: {str(e)}")
            
    def test_testimonials_api(self):
        """Test Testimonials API"""
        print("\n=== Testing Testimonials API ===")
        
        try:
            response = self.session.get(f"{API_BASE_URL}/testimonials")
            if response.status_code == 200:
                testimonials = response.json()
                if isinstance(testimonials, list) and len(testimonials) > 0:
                    self.log_test("GET /testimonials", True, f"Retrieved {len(testimonials)} testimonials")
                    
                    # Verify testimonial structure
                    first_testimonial = testimonials[0]
                    required_fields = ['id', 'name', 'service', 'rating', 'comment']
                    has_fields = all(field in first_testimonial for field in required_fields)
                    
                    if has_fields:
                        self.log_test("Testimonial Structure", True, "All required fields present")
                        
                        # Verify multilingual comments
                        comment = first_testimonial.get('comment', {})
                        if isinstance(comment, dict):
                            languages = ['en', 'fr', 'es']
                            has_all_languages = all(lang in comment for lang in languages)
                            if has_all_languages:
                                self.log_test("Testimonial Multilingual", True, "All languages present")
                            else:
                                self.log_test("Testimonial Multilingual", False, "Missing language translations")
                        else:
                            self.log_test("Testimonial Multilingual", False, "Comment is not multilingual object")
                    else:
                        missing = [field for field in required_fields if field not in first_testimonial]
                        self.log_test("Testimonial Structure", False, f"Missing fields: {missing}")
                else:
                    self.log_test("GET /testimonials", False, "No testimonials returned or invalid format")
            else:
                self.log_test("GET /testimonials", False, f"Status code: {response.status_code}")
        except Exception as e:
            self.log_test("GET /testimonials", False, f"Error: {str(e)}")
            
    def test_gallery_api(self):
        """Test Gallery API"""
        print("\n=== Testing Gallery API ===")
        
        # Test GET /api/gallery (all images)
        try:
            response = self.session.get(f"{API_BASE_URL}/gallery")
            if response.status_code == 200:
                gallery = response.json()
                if isinstance(gallery, list) and len(gallery) > 0:
                    self.log_test("GET /gallery", True, f"Retrieved {len(gallery)} gallery images")
                    
                    # Verify gallery image structure
                    first_image = gallery[0]
                    required_fields = ['id', 'title', 'category', 'image']
                    has_fields = all(field in first_image for field in required_fields)
                    
                    if has_fields:
                        self.log_test("Gallery Image Structure", True, "All required fields present")
                    else:
                        missing = [field for field in required_fields if field not in first_image]
                        self.log_test("Gallery Image Structure", False, f"Missing fields: {missing}")
                else:
                    self.log_test("GET /gallery", False, "No gallery images returned or invalid format")
            else:
                self.log_test("GET /gallery", False, f"Status code: {response.status_code}")
        except Exception as e:
            self.log_test("GET /gallery", False, f"Error: {str(e)}")
            
        # Test category filtering
        categories = ['braids', 'twist', 'nails']
        for category in categories:
            try:
                response = self.session.get(f"{API_BASE_URL}/gallery?category={category}")
                if response.status_code == 200:
                    gallery = response.json()
                    if isinstance(gallery, list):
                        # Verify all images belong to the requested category
                        if gallery:
                            all_correct_category = all(img.get('category') == category for img in gallery)
                            if all_correct_category:
                                self.log_test(f"Gallery Filter ({category})", True, f"Retrieved {len(gallery)} {category} images")
                            else:
                                self.log_test(f"Gallery Filter ({category})", False, "Some images have wrong category")
                        else:
                            self.log_test(f"Gallery Filter ({category})", True, f"No {category} images found (valid)")
                    else:
                        self.log_test(f"Gallery Filter ({category})", False, "Invalid response format")
                else:
                    self.log_test(f"Gallery Filter ({category})", False, f"Status code: {response.status_code}")
            except Exception as e:
                self.log_test(f"Gallery Filter ({category})", False, f"Error: {str(e)}")
                
    def run_all_tests(self):
        """Run all API tests"""
        print("🚀 Starting AfroBelleza Backend API Tests")
        print("=" * 50)
        
        # Health check first
        if not self.test_health_check():
            print("❌ Health check failed. Backend may not be running.")
            return False
            
        # Run all API tests
        self.test_services_api()
        self.test_appointments_api()
        self.test_timeslots_api()
        self.test_contact_api()
        self.test_testimonials_api()
        self.test_gallery_api()
        
        # Summary
        print("\n" + "=" * 50)
        print("📊 TEST SUMMARY")
        print("=" * 50)
        
        total_tests = len(self.test_results)
        passed_tests = sum(1 for result in self.test_results if result['success'])
        failed_tests = total_tests - passed_tests
        
        print(f"Total Tests: {total_tests}")
        print(f"✅ Passed: {passed_tests}")
        print(f"❌ Failed: {failed_tests}")
        print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
        
        if failed_tests > 0:
            print("\n🔍 FAILED TESTS:")
            for result in self.test_results:
                if not result['success']:
                    print(f"  • {result['test']}: {result['message']}")
                    
        return failed_tests == 0

if __name__ == "__main__":
    tester = APITester()
    success = tester.run_all_tests()
    sys.exit(0 if success else 1)