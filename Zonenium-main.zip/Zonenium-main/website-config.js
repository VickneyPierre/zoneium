// AfroBelleza Website Configuration
// Edit this file to change prices, contact info, and content anytime!

module.exports = {
  // BUSINESS CONTACT INFORMATION
  contact: {
    phone: "+52 962 447 0847",
    whatsapp: "+52 962-447-0847", 
    email: "afrobelleza@qualityservice.com",
    address: "San Augustín SN, Los Naranjos, Las Palmeras, Chis, 30785. Casa amarilla, reja café. Frente al kinder Rosario Roldan.",
    
    // Social Media (change handles here)
    social: {
      instagram: "Afrobelleza7",
      facebook: "@AfroBelleza", 
      tiktok: "AfroBelleza"
    },
    
    // Business Hours
    hours: {
      en: "Mon-Sat: 9AM-7PM, Sun: 10AM-5PM",
      fr: "Lun-Sam: 9h-19h, Dim: 10h-17h", 
      es: "Lun-Sáb: 9AM-7PM, Dom: 10AM-5PM"
    }
  },

  // SERVICE PRICES - CHANGE THESE ANYTIME!
  services: {
    braidMale: {
      price: 85, // pesos
      name: {
        en: "Braid Male",
        fr: "Tresses Homme", 
        es: "Trenzas Hombre"
      }
    },
    braidWomen: {
      price: 120, // pesos
      name: {
        en: "Braid Women", 
        fr: "Tresses Femme",
        es: "Trenzas Mujer"
      }
    },
    braidKids: {
      price: 65, // pesos
      name: {
        en: "Braid Kids",
        fr: "Tresses Enfant",
        es: "Trenzas Niños"
      }
    },
    twist: {
      price: 95, // pesos
      name: {
        en: "Twist",
        fr: "Torsades",
        es: "Giros"
      }
    },
    manicure: {
      price: 200, // pesos - UPDATED!
      name: {
        en: "Manicure (Simple)",
        fr: "Manucure (Simple)", 
        es: "Manicura (Simple)"
      }
    },
    pedicure: {
      price: 200, // pesos - UPDATED!
      name: {
        en: "Pedicure (Simple)",
        fr: "Pédicure (Simple)",
        es: "Pedicura (Simple)"
      }
    }
  },

  // WEBSITE TEXT CONTENT
  content: {
    heroTitle: "AfroBelleza",
    heroSubtitle: {
      en: "Luxury Hair & Nails Salon",
      fr: "Salon de Coiffure & Ongles de Luxe",
      es: "Salón de Cabello y Uñas de Lujo"
    },
    heroDescription: {
      en: "Celebrating Afro heritage with premium hair braiding and nail services. Experience elegance, tradition, and modern luxury.",
      fr: "Célébrer l'héritage afro avec des services de tressage et d'ongles premium. Découvrez l'élégance, la tradition et le luxe moderne.",
      es: "Celebrando la herencia afro con servicios premium de trenzado y uñas. Experimenta elegancia, tradición y lujo moderno."
    }
  }
};

/*
==============================================
HOW TO CHANGE PRICES & CONTENT:
==============================================

1. TO CHANGE PRICES:
   - Edit the "price" numbers above (in pesos)
   - Save this file
   - Restart the website

2. TO CHANGE CONTACT INFO:
   - Edit phone, email, address above
   - Save this file  
   - Restart the website

3. TO CHANGE SOCIAL MEDIA:
   - Edit instagram, facebook, tiktok handles
   - Save this file
   - Restart the website

4. RESTART WEBSITE COMMANDS:
   Run in terminal:
   - sudo supervisorctl restart backend
   - sudo supervisorctl restart frontend

==============================================
*/