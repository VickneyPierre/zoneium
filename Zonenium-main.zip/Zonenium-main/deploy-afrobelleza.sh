#!/bin/bash

# 🎉 AfroBelleza VIP Salon - One-Click Deployment Script
# This script will deploy your website automatically!

echo "🌟 ===== LAUNCHING AFROBELLEZA.VIP SALON ===== 🌟"
echo ""
echo "🎯 Preparing your beautiful salon website for launch..."
echo ""

# Navigate to website files
cd /app/afrobelleza-website-files/

# Install deployment tool
echo "📦 Installing deployment tools..."
npm install -g surge

# Deploy to surge.sh (instant hosting)
echo "🚀 Deploying your website..."
echo ""
echo "🎉 Your AfroBelleza salon will be live at:"
echo "   👉 https://afrobelleza-vip.surge.sh"
echo ""
echo "💡 Just press ENTER when asked for domain name"
echo "💡 Press ENTER when asked for email (or enter yours)"
echo ""

# Deploy the website
surge . afrobelleza-vip.surge.sh

echo ""
echo "🎉 ===== DEPLOYMENT COMPLETE! ===== 🎉"
echo ""
echo "✅ Your AfroBelleza salon is now LIVE at:"
echo "   🌐 https://afrobelleza-vip.surge.sh"
echo ""
echo "🔗 Next steps:"
echo "   1. Visit your live website above ☝️"
echo "   2. Connect your VIP domain (afrobelleza.vip)"
echo "   3. Share with customers!"
echo ""
echo "🌟 Your luxury salon is now online! 🌟"