from fastapi import FastAPI, APIRouter, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from contextlib import asynccontextmanager
import os
import logging
from pathlib import Path
from dotenv import load_dotenv

# Import models and database
from models import *
from database import Database

# Load environment variables
ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Global database instance
database = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    global database
    try:
        mongo_url = os.environ['MONGO_URL']
        db_name = os.environ['DB_NAME']
        client = AsyncIOMotorClient(mongo_url)
        database = Database(client, db_name)
        
        # Initialize sample data
        await database.init_sample_data()
        logger.info("Database connected and initialized successfully")
        
        yield
    except Exception as e:
        logger.error(f"Failed to connect to database: {e}")
        raise
    finally:
        # Shutdown
        if database:
            database.client.close()
            logger.info("Database connection closed")

# Create FastAPI app
app = FastAPI(lifespan=lifespan, title="AfroBelleza API", version="1.0.0")

# Create API router
api_router = APIRouter(prefix="/api")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Health check endpoint
@api_router.get("/")
async def root():
    return {"message": "AfroBelleza API is running", "status": "healthy"}

# Services endpoints
@api_router.get("/services", response_model=List[ServiceResponse])
async def get_services():
    """Get all active services"""
    try:
        services = await database.get_services()
        logger.info(f"Retrieved {len(services)} services")
        return services
    except Exception as e:
        logger.error(f"Error retrieving services: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@api_router.get("/services/{service_id}", response_model=ServiceResponse)
async def get_service(service_id: str):
    """Get a specific service by ID"""
    try:
        service = await database.get_service_by_id(service_id)
        if not service:
            raise HTTPException(status_code=404, detail="Service not found")
        return service
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid service ID")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving service {service_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# Testimonials endpoints
@api_router.get("/testimonials", response_model=List[TestimonialResponse])
async def get_testimonials():
    """Get all approved testimonials"""
    try:
        testimonials = await database.get_testimonials()
        logger.info(f"Retrieved {len(testimonials)} testimonials")
        return testimonials
    except Exception as e:
        logger.error(f"Error retrieving testimonials: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# Gallery endpoints
@api_router.get("/gallery", response_model=List[GalleryImageResponse])
async def get_gallery(category: str = Query(None, description="Filter by category")):
    """Get gallery images, optionally filtered by category"""
    try:
        images = await database.get_gallery_images(category)
        logger.info(f"Retrieved {len(images)} gallery images" + (f" for category '{category}'" if category else ""))
        return images
    except Exception as e:
        logger.error(f"Error retrieving gallery images: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# Appointments endpoints
@api_router.post("/appointments", response_model=AppointmentResponse)
async def create_appointment(appointment: AppointmentCreate):
    """Create a new appointment"""
    try:
        created_appointment = await database.create_appointment(appointment)
        logger.info(f"Created appointment for {appointment.name} on {appointment.date} at {appointment.time}")
        return created_appointment
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating appointment: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@api_router.get("/appointments", response_model=List[AppointmentResponse])
async def get_appointments(status: str = Query(None, description="Filter by status")):
    """Get appointments, optionally filtered by status"""
    try:
        appointments = await database.get_appointments(status)
        logger.info(f"Retrieved {len(appointments)} appointments" + (f" with status '{status}'" if status else ""))
        return appointments
    except Exception as e:
        logger.error(f"Error retrieving appointments: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@api_router.get("/appointments/{appointment_id}", response_model=AppointmentResponse)
async def get_appointment(appointment_id: str):
    """Get a specific appointment by ID"""
    try:
        appointment = await database.get_appointment_by_id(appointment_id)
        if not appointment:
            raise HTTPException(status_code=404, detail="Appointment not found")
        return appointment
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid appointment ID")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving appointment {appointment_id}: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@api_router.put("/appointments/{appointment_id}/status")
async def update_appointment_status(appointment_id: str, status: str = Query(..., description="New status")):
    """Update appointment status"""
    valid_statuses = ["pending", "confirmed", "completed", "cancelled"]
    if status not in valid_statuses:
        raise HTTPException(status_code=400, detail=f"Invalid status. Must be one of: {valid_statuses}")
    
    try:
        updated = await database.update_appointment_status(appointment_id, status)
        if not updated:
            raise HTTPException(status_code=404, detail="Appointment not found")
        logger.info(f"Updated appointment {appointment_id} status to {status}")
        return {"message": "Appointment status updated successfully", "status": status}
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid appointment ID")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating appointment status: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# Contact endpoints
@api_router.post("/contact", response_model=ContactMessageResponse)
async def create_contact_message(message: ContactMessageCreate):
    """Submit a contact form message"""
    try:
        created_message = await database.create_contact_message(message)
        logger.info(f"Created contact message from {message.name} ({message.email})")
        return created_message
    except Exception as e:
        logger.error(f"Error creating contact message: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@api_router.get("/contact", response_model=List[ContactMessageResponse])
async def get_contact_messages(status: str = Query(None, description="Filter by status")):
    """Get contact messages, optionally filtered by status"""
    try:
        messages = await database.get_contact_messages(status)
        logger.info(f"Retrieved {len(messages)} contact messages" + (f" with status '{status}'" if status else ""))
        return messages
    except Exception as e:
        logger.error(f"Error retrieving contact messages: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# Time slots endpoint
@api_router.get("/timeslots", response_model=TimeSlotAvailability)
async def get_available_time_slots(
    date: str = Query(..., description="Date in YYYY-MM-DD format"),
    service: str = Query(None, description="Service ID (optional)")
):
    """Get available time slots for a specific date"""
    try:
        availability = await database.get_available_time_slots(date, service)
        logger.info(f"Retrieved availability for {date}: {len(availability.available_times)} available slots")
        return availability
    except Exception as e:
        logger.error(f"Error retrieving time slots for {date}: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# Include the API router
app.include_router(api_router)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)