from motor.motor_asyncio import AsyncIOMotorClient
from models import *
import os
from datetime import datetime
from bson import ObjectId
import logging

logger = logging.getLogger(__name__)

# Database instance - will be initialized in server.py
db = None

class Database:
    def __init__(self, client, db_name):
        self.client = client
        self.db = client[db_name]
        
    # Services CRUD
    async def get_services(self, active_only: bool = True):
        query = {"active": True} if active_only else {}
        services = await self.db.services.find(query).to_list(100)
        return [ServiceResponse(**self._convert_objectid(service)) for service in services]
    
    async def get_service_by_id(self, service_id: str):
        service = await self.db.services.find_one({"_id": ObjectId(service_id)})
        if service:
            return ServiceResponse(**self._convert_objectid(service))
        return None
    
    async def create_service(self, service: ServiceCreate):
        service_dict = service.dict()
        service_dict["created_at"] = datetime.utcnow()
        service_dict["updated_at"] = datetime.utcnow()
        service_dict["active"] = True
        service_dict["image"] = "/api/placeholder/300/200"
        
        result = await self.db.services.insert_one(service_dict)
        created_service = await self.get_service_by_id(str(result.inserted_id))
        return created_service
    
    # Testimonials CRUD
    async def get_testimonials(self, approved_only: bool = True):
        query = {"approved": True} if approved_only else {}
        testimonials = await self.db.testimonials.find(query).to_list(100)
        return [TestimonialResponse(**self._convert_objectid(testimonial)) for testimonial in testimonials]
    
    async def create_testimonial(self, testimonial: TestimonialCreate):
        testimonial_dict = testimonial.dict()
        testimonial_dict["created_at"] = datetime.utcnow()
        testimonial_dict["updated_at"] = datetime.utcnow()
        testimonial_dict["approved"] = True
        testimonial_dict["image"] = "/api/placeholder/60/60"
        
        result = await self.db.testimonials.insert_one(testimonial_dict)
        return str(result.inserted_id)
    
    # Gallery CRUD
    async def get_gallery_images(self, category: str = None):
        query = {"category": category} if category else {}
        images = await self.db.gallery.find(query).to_list(100)
        return [GalleryImageResponse(**self._convert_objectid(image)) for image in images]
    
    async def create_gallery_image(self, image: GalleryImageCreate):
        image_dict = image.dict()
        image_dict["created_at"] = datetime.utcnow()
        image_dict["updated_at"] = datetime.utcnow()
        image_dict["image"] = "/api/placeholder/400/300"
        
        result = await self.db.gallery.insert_one(image_dict)
        return str(result.inserted_id)
    
    # Appointments CRUD
    async def create_appointment(self, appointment: AppointmentCreate):
        # Get service details
        service = await self.get_service_by_id(appointment.service)
        if not service:
            raise ValueError("Service not found")
        
        # Check if time slot is available
        is_available = await self.is_time_slot_available(appointment.date, appointment.time)
        if not is_available:
            raise ValueError("Time slot not available")
        
        appointment_dict = {
            "service_id": appointment.service,
            "service_name": service.name.en,  # Default to English
            "service_price": service.price,
            "date": appointment.date,
            "time": appointment.time,
            "duration": service.duration,
            "customer_name": appointment.name,
            "customer_email": appointment.email,
            "customer_phone": appointment.phone,
            "status": "pending",
            "notes": "",
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        }
        
        result = await self.db.appointments.insert_one(appointment_dict)
        created_appointment = await self.db.appointments.find_one({"_id": result.inserted_id})
        return AppointmentResponse(**self._convert_objectid(created_appointment))
    
    async def get_appointments(self, status: str = None):
        query = {"status": status} if status else {}
        appointments = await self.db.appointments.find(query).sort("created_at", -1).to_list(100)
        return [AppointmentResponse(**self._convert_objectid(appointment)) for appointment in appointments]
    
    async def get_appointment_by_id(self, appointment_id: str):
        appointment = await self.db.appointments.find_one({"_id": ObjectId(appointment_id)})
        if appointment:
            return AppointmentResponse(**self._convert_objectid(appointment))
        return None
    
    async def update_appointment_status(self, appointment_id: str, status: str):
        result = await self.db.appointments.update_one(
            {"_id": ObjectId(appointment_id)},
            {"$set": {"status": status, "updated_at": datetime.utcnow()}}
        )
        return result.modified_count > 0
    
    # Contact Messages CRUD
    async def create_contact_message(self, message: ContactMessageCreate):
        message_dict = message.dict()
        message_dict["status"] = "new"
        message_dict["response"] = ""
        message_dict["created_at"] = datetime.utcnow()
        message_dict["updated_at"] = datetime.utcnow()
        
        result = await self.db.contacts.insert_one(message_dict)
        created_message = await self.db.contacts.find_one({"_id": result.inserted_id})
        return ContactMessageResponse(**self._convert_objectid(created_message))
    
    async def get_contact_messages(self, status: str = None):
        query = {"status": status} if status else {}
        messages = await self.db.contacts.find(query).sort("created_at", -1).to_list(100)
        return [ContactMessageResponse(**self._convert_objectid(message)) for message in messages]
    
    # Time slot availability
    async def is_time_slot_available(self, date: str, time: str):
        # Check if there's already an appointment at this time
        existing_appointment = await self.db.appointments.find_one({
            "date": date,
            "time": time,
            "status": {"$in": ["pending", "confirmed"]}
        })
        return existing_appointment is None
    
    async def get_available_time_slots(self, date: str, service_id: str = None):
        # Get all possible time slots
        default_times = [
            "9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM",
            "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM"
        ]
        
        # Get booked times for this date
        booked_appointments = await self.db.appointments.find({
            "date": date,
            "status": {"$in": ["pending", "confirmed"]}
        }).to_list(100)
        
        booked_times = [appointment["time"] for appointment in booked_appointments]
        available_times = [time for time in default_times if time not in booked_times]
        
        return TimeSlotAvailability(
            date=date,
            available_times=available_times,
            booked_times=booked_times
        )
    
    # Utility methods
    def _convert_objectid(self, document):
        """Convert ObjectId to string for API responses"""
        if document and "_id" in document:
            document["id"] = str(document["_id"])
            del document["_id"]
        return document
    
    # Initialize sample data
    async def init_sample_data(self):
        """Initialize database with sample data if empty"""
        try:
            # Check if services already exist
            services_count = await self.db.services.count_documents({})
            if services_count > 0:
                logger.info("Sample data already exists, skipping initialization")
                return
            
            # Sample services data
            sample_services = [
                {
                    "name": {
                        "en": "Braid Male",
                        "fr": "Tresses Homme", 
                        "es": "Trenzas Hombre"
                    },
                    "description": {
                        "en": "Professional braiding services for men",
                        "fr": "Services de tressage professionnel pour hommes",
                        "es": "Servicios profesionales de trenzado para hombres"
                    },
                    "price": 85,
                    "duration": "2-3 hours",
                    "category": "braids",
                    "image": "/api/placeholder/300/200",
                    "active": True,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                },
                {
                    "name": {
                        "en": "Braid Women", 
                        "fr": "Tresses Femme",
                        "es": "Trenzas Mujer"
                    },
                    "description": {
                        "en": "Elegant braiding styles for women",
                        "fr": "Styles de tressage élégants pour femmes", 
                        "es": "Estilos elegantes de trenzado para mujeres"
                    },
                    "price": 120,
                    "duration": "3-4 hours",
                    "category": "braids",
                    "image": "/api/placeholder/300/200",
                    "active": True,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                },
                {
                    "name": {
                        "en": "Braid Kids",
                        "fr": "Tresses Enfant",
                        "es": "Trenzas Niños"
                    },
                    "description": {
                        "en": "Fun and protective braids for children",
                        "fr": "Tresses amusantes et protectrices pour enfants",
                        "es": "Trenzas divertidas y protectoras para niños"
                    },
                    "price": 65,
                    "duration": "1-2 hours", 
                    "category": "braids",
                    "image": "/api/placeholder/300/200",
                    "active": True,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                },
                {
                    "name": {
                        "en": "Twist",
                        "fr": "Torsades",
                        "es": "Giros"
                    },
                    "description": {
                        "en": "Modern twist hairstyles",
                        "fr": "Coiffures torsadées modernes",
                        "es": "Peinados modernos con giros"
                    },
                    "price": 95,
                    "duration": "2-3 hours",
                    "category": "braids",
                    "image": "/api/placeholder/300/200",
                    "active": True,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                },
                {
                    "name": {
                        "en": "Manicure",
                        "fr": "Manucure", 
                        "es": "Manicura"
                    },
                    "description": {
                        "en": "Professional nail care and design (simple)",
                        "fr": "Soins et design d'ongles professionnels (simple)",
                        "es": "Cuidado profesional y diseño de uñas (simple)"
                    },
                    "price": 200,
                    "duration": "1 hour",
                    "category": "nails",
                    "image": "/api/placeholder/300/200",
                    "active": True,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                },
                {
                    "name": {
                        "en": "Pedicure",
                        "fr": "Pédicure",
                        "es": "Pedicura" 
                    },
                    "description": {
                        "en": "Relaxing foot care treatment (simple)",
                        "fr": "Soin relaxant des pieds (simple)",
                        "es": "Tratamiento relajante de cuidado de pies (simple)"
                    },
                    "price": 200,
                    "duration": "1.5 hours",
                    "category": "nails",
                    "image": "/api/placeholder/300/200",
                    "active": True,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                }
            ]
            
            await self.db.services.insert_many(sample_services)
            logger.info("Sample services data initialized successfully")
            
            # Sample testimonials
            sample_testimonials = [
                {
                    "name": "Amara Johnson",
                    "service": "Braid Women",
                    "rating": 5,
                    "comment": {
                        "en": "Absolutely stunning work! The braids lasted for weeks and looked perfect.",
                        "fr": "Travail absolument magnifique ! Les tresses ont duré des semaines et étaient parfaites.",
                        "es": "¡Trabajo absolutamente increíble! Las trenzas duraron semanas y se veían perfectas."
                    },
                    "image": "/api/placeholder/60/60",
                    "approved": True,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                },
                {
                    "name": "Marcus Williams",
                    "service": "Braid Male",
                    "rating": 5,
                    "comment": {
                        "en": "Professional service and amazing results. Highly recommend!",
                        "fr": "Service professionnel et résultats incroyables. Je recommande vivement !",
                        "es": "Servicio profesional y resultados increíbles. ¡Muy recomendado!"
                    },
                    "image": "/api/placeholder/60/60",
                    "approved": True,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                },
                {
                    "name": "Sofia Rodriguez", 
                    "service": "Manicure",
                    "rating": 5,
                    "comment": {
                        "en": "Beautiful nail art and excellent customer service!",
                        "fr": "Magnifique nail art et excellent service client !",
                        "es": "¡Hermoso nail art y excelente servicio al cliente!"
                    },
                    "image": "/api/placeholder/60/60",
                    "approved": True,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                }
            ]
            
            await self.db.testimonials.insert_many(sample_testimonials)
            logger.info("Sample testimonials data initialized successfully")
            
            # Sample gallery images
            sample_gallery = [
                {
                    "title": "Box Braids",
                    "category": "braids",
                    "image": "/api/placeholder/400/300",
                    "description": "Beautiful box braids style",
                    "featured": True,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                },
                {
                    "title": "Cornrows",
                    "category": "braids",
                    "image": "/api/placeholder/400/300",
                    "description": "Classic cornrows pattern",
                    "featured": False,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                },
                {
                    "title": "Senegalese Twist",
                    "category": "twist",
                    "image": "/api/placeholder/400/300",
                    "description": "Elegant Senegalese twist style",
                    "featured": False,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                },
                {
                    "title": "French Manicure",
                    "category": "nails",
                    "image": "/api/placeholder/400/300",
                    "description": "Classic French manicure",
                    "featured": False,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                },
                {
                    "title": "Nail Art Design",
                    "category": "nails",
                    "image": "/api/placeholder/400/300",
                    "description": "Custom nail art design",
                    "featured": True,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                },
                {
                    "title": "Ghana Braids",
                    "category": "braids",
                    "image": "/api/placeholder/400/300",
                    "description": "Traditional Ghana braids",
                    "featured": False,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                }
            ]
            
            await self.db.gallery.insert_many(sample_gallery)
            logger.info("Sample gallery data initialized successfully")
            
        except Exception as e:
            logger.error(f"Error initializing sample data: {e}")
            raise

# Global database instance
database = None