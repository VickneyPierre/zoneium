from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional, Dict, Any
from datetime import datetime
from bson import ObjectId
import uuid

# Custom ObjectId type for Pydantic v2
class PyObjectId(ObjectId):
    @classmethod
    def __get_validators__(cls):
        yield cls.validate

    @classmethod
    def validate(cls, v):
        if not ObjectId.is_valid(v):
            raise ValueError("Invalid ObjectId")
        return ObjectId(v)

    @classmethod
    def __get_pydantic_json_schema__(cls, field_schema):
        field_schema.update(type="string")
        return field_schema

# Base model with common fields
class BaseDocument(BaseModel):
    id: PyObjectId = Field(default_factory=PyObjectId, alias="_id")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    class Config:
        allow_population_by_field_name = True
        arbitrary_types_allowed = True
        json_encoders = {ObjectId: str}

# Multilingual text model
class MultilingualText(BaseModel):
    en: str
    fr: str
    es: str

# Service Models
class Service(BaseDocument):
    name: MultilingualText
    description: MultilingualText
    price: int
    duration: str
    category: str  # 'braids' | 'nails'
    image: str = "/api/placeholder/300/200"
    active: bool = True

class ServiceCreate(BaseModel):
    name: MultilingualText
    description: MultilingualText
    price: int
    duration: str
    category: str

class ServiceResponse(BaseModel):
    id: str
    name: MultilingualText
    description: MultilingualText
    price: int
    duration: str
    category: str
    image: str
    active: bool

# Testimonial Models
class Testimonial(BaseDocument):
    name: str
    service: str
    rating: int = Field(ge=1, le=5)
    comment: MultilingualText
    image: str = "/api/placeholder/60/60"
    approved: bool = True

class TestimonialCreate(BaseModel):
    name: str
    service: str
    rating: int = Field(ge=1, le=5)
    comment: MultilingualText

class TestimonialResponse(BaseModel):
    id: str
    name: str
    service: str
    rating: int
    comment: MultilingualText
    image: str

# Gallery Models
class GalleryImage(BaseDocument):
    title: str
    category: str  # 'braids', 'twist', 'nails'
    image: str = "/api/placeholder/400/300"
    description: Optional[str] = ""
    featured: bool = False

class GalleryImageCreate(BaseModel):
    title: str
    category: str
    description: Optional[str] = ""
    featured: bool = False

class GalleryImageResponse(BaseModel):
    id: str
    title: str
    category: str
    image: str
    description: Optional[str]
    featured: bool

# Appointment Models
class Appointment(BaseDocument):
    service_id: str
    service_name: str
    service_price: int
    date: str  # YYYY-MM-DD format
    time: str  # "10:00 AM" format
    duration: str
    customer_name: str
    customer_email: EmailStr
    customer_phone: str
    status: str = "pending"  # 'pending', 'confirmed', 'completed', 'cancelled'
    notes: Optional[str] = ""

class AppointmentCreate(BaseModel):
    service: str  # service ID
    date: str
    time: str
    name: str
    email: EmailStr
    phone: str

class AppointmentResponse(BaseModel):
    id: str
    service_id: str
    service_name: str
    service_price: int
    date: str
    time: str
    duration: str
    customer_name: str
    customer_email: str
    customer_phone: str
    status: str
    created_at: datetime

# Contact Models
class ContactMessage(BaseDocument):
    name: str
    email: EmailStr
    message: str
    status: str = "new"  # 'new', 'read', 'replied'
    response: Optional[str] = ""

class ContactMessageCreate(BaseModel):
    name: str
    email: EmailStr
    message: str

class ContactMessageResponse(BaseModel):
    id: str
    name: str
    email: str
    message: str
    status: str
    created_at: datetime

# Settings Models
class Setting(BaseDocument):
    key: str
    value: Dict[str, Any]

class SettingCreate(BaseModel):
    key: str
    value: Dict[str, Any]

# Time slot models
class TimeSlotAvailability(BaseModel):
    date: str
    available_times: List[str]
    booked_times: List[str]

class BusinessHours(BaseModel):
    monday: List[str] = ["9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM"]
    tuesday: List[str] = ["9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM"]
    wednesday: List[str] = ["9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM"]
    thursday: List[str] = ["9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM"]
    friday: List[str] = ["9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM"]
    saturday: List[str] = ["9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM", "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM"]
    sunday: List[str] = []  # Closed on Sunday