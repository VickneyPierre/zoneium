# AfroBelleza Backend API Contracts

## Overview
This document outlines the API contracts for transitioning AfroBelleza from mock data to a fully functional backend with MongoDB storage.

## Current Mock Data (to be replaced)

### 1. Services (`services` array in mock.js)
```javascript
// Current mock structure:
{
  id: number,
  name: { en: string, fr: string, es: string },
  description: { en: string, fr: string, es: string },
  price: number,
  duration: string,
  image: string
}
```

### 2. Testimonials (`testimonials` array in mock.js)
```javascript
// Current mock structure:
{
  id: number,
  name: string,
  service: string,
  rating: number,
  comment: { en: string, fr: string, es: string },
  image: string
}
```

### 3. Gallery Images (`galleryImages` array in mock.js)
```javascript
// Current mock structure:
{
  id: number,
  category: string,
  title: string,
  image: string
}
```

### 4. Appointments (currently mock form submission)
```javascript
// Current booking form data:
{
  service: string,
  date: string,
  time: string,
  name: string,
  email: string,
  phone: string
}
```

### 5. Contact Messages (currently mock form submission)
```javascript
// Current contact form data:
{
  name: string,
  email: string,
  message: string
}
```

## Backend API Endpoints to Implement

### 1. Services API
- **GET /api/services** - Retrieve all services
- **GET /api/services/:id** - Retrieve specific service
- Response format matches current mock structure

### 2. Testimonials API
- **GET /api/testimonials** - Retrieve all testimonials
- **GET /api/testimonials/:id** - Retrieve specific testimonial
- Response format matches current mock structure

### 3. Gallery API
- **GET /api/gallery** - Retrieve all gallery images
- **GET /api/gallery?category={category}** - Filter by category
- Response format matches current mock structure

### 4. Appointments API
- **POST /api/appointments** - Create new appointment
- **GET /api/appointments** - Retrieve appointments (admin)
- **GET /api/appointments/:id** - Retrieve specific appointment
- **PUT /api/appointments/:id** - Update appointment status
- **DELETE /api/appointments/:id** - Cancel appointment

### 5. Contact Messages API
- **POST /api/contact** - Submit contact form
- **GET /api/contact** - Retrieve messages (admin)
- **GET /api/contact/:id** - Retrieve specific message
- **PUT /api/contact/:id/status** - Mark as read/replied

### 6. Time Slots API
- **GET /api/timeslots?date={date}&service={serviceId}** - Get available times
- **GET /api/timeslots/availability** - Get general availability

## MongoDB Collections

### 1. services
```javascript
{
  _id: ObjectId,
  name: {
    en: String,
    fr: String,
    es: String
  },
  description: {
    en: String,
    fr: String,
    es: String
  },
  price: Number,
  duration: String,
  category: String, // 'braids' | 'nails'
  image: String,
  active: Boolean,
  createdAt: Date,
  updatedAt: Date
}
```

### 2. testimonials
```javascript
{
  _id: ObjectId,
  name: String,
  service: String,
  rating: Number,
  comment: {
    en: String,
    fr: String,
    es: String
  },
  image: String,
  approved: Boolean,
  createdAt: Date,
  updatedAt: Date
}
```

### 3. gallery
```javascript
{
  _id: ObjectId,
  title: String,
  category: String,
  image: String,
  description: String,
  featured: Boolean,
  createdAt: Date,
  updatedAt: Date
}
```

### 4. appointments
```javascript
{
  _id: ObjectId,
  serviceId: ObjectId,
  serviceName: String,
  servicePrice: Number,
  date: Date,
  time: String,
  duration: String,
  customerName: String,
  customerEmail: String,
  customerPhone: String,
  status: String, // 'pending', 'confirmed', 'completed', 'cancelled'
  notes: String,
  createdAt: Date,
  updatedAt: Date
}
```

### 5. contacts
```javascript
{
  _id: ObjectId,
  name: String,
  email: String,
  message: String,
  status: String, // 'new', 'read', 'replied'
  response: String,
  createdAt: Date,
  updatedAt: Date
}
```

### 6. settings
```javascript
{
  _id: ObjectId,
  key: String, // 'business_hours', 'holidays', 'contact_info'
  value: Mixed,
  createdAt: Date,
  updatedAt: Date
}
```

## Frontend Integration Changes

### 1. Remove Mock Data Imports
Replace these imports in components:
```javascript
// Remove:
import { services, testimonials, galleryImages, contactInfo, timeSlots } from '../mock';

// Replace with API calls using axios
```

### 2. API Service Layer
Create `/frontend/src/services/api.js`:
```javascript
const API_BASE = process.env.REACT_APP_BACKEND_URL + '/api';

export const servicesAPI = {
  getAll: () => axios.get(`${API_BASE}/services`),
  getById: (id) => axios.get(`${API_BASE}/services/${id}`)
};

export const appointmentsAPI = {
  create: (data) => axios.post(`${API_BASE}/appointments`, data),
  getAvailability: (date, serviceId) => 
    axios.get(`${API_BASE}/timeslots?date=${date}&service=${serviceId}`)
};

export const contactAPI = {
  submit: (data) => axios.post(`${API_BASE}/contact`, data)
};

export const testimonialsAPI = {
  getAll: () => axios.get(`${API_BASE}/testimonials`)
};

export const galleryAPI = {
  getAll: () => axios.get(`${API_BASE}/gallery`),
  getByCategory: (category) => axios.get(`${API_BASE}/gallery?category=${category}`)
};
```

### 3. Component Updates Required

#### Services.js
- Replace `services` import with `servicesAPI.getAll()`
- Add loading states
- Handle API errors

#### Testimonials.js
- Replace `testimonials` import with `testimonialsAPI.getAll()`
- Add loading states

#### Gallery.js
- Replace `galleryImages` import with `galleryAPI.getAll()`
- Add category filtering via API

#### Booking.js
- Replace mock form submission with `appointmentsAPI.create()`
- Add real-time availability checking
- Add booking confirmation

#### Contact.js
- Replace mock form submission with `contactAPI.submit()`
- Add success/error handling

## Implementation Priority

### Phase 1: Core Backend Setup
1. Set up MongoDB models
2. Implement Services API
3. Implement Appointments API
4. Implement Contact API

### Phase 2: Frontend Integration
1. Create API service layer
2. Update Booking component
3. Update Contact component
4. Update Services component

### Phase 3: Advanced Features
1. Implement Testimonials API
2. Implement Gallery API
3. Add availability checking
4. Add email notifications

### Phase 4: Admin Features (Optional)
1. Admin dashboard for appointments
2. Admin interface for services management
3. Admin interface for testimonials approval

## Environment Variables Required

### Backend (.env)
```
MONGO_URL=mongodb://localhost:27017/afrobelleza
DB_NAME=afrobelleza
JWT_SECRET=your_jwt_secret_here
EMAIL_SERVICE_API_KEY=for_notifications (optional)
```

### Frontend (.env)
```
REACT_APP_BACKEND_URL=http://localhost:8001 (already configured)
```

## Testing Strategy
1. Test all API endpoints with sample data
2. Test form submissions and data persistence
3. Test multilingual content serving
4. Test appointment booking flow end-to-end
5. Test mobile responsiveness with real data

## Notes
- All text content supports 3 languages (en, fr, es)
- Appointment times are in salon's local timezone
- Image URLs will remain placeholder until real images are provided
- Business hours and holidays can be configured via settings collection
- Email notifications for appointments can be added later